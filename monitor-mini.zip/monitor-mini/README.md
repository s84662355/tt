# monitor-client 应用
## 生产环境
```shell
go build -tags "pro" -ldflags="-H windowsgui -X main.version=version" -o bin/pro/CSmonitor.exe  
```

## 预发布环境
```shell
go build -tags "uat" -ldflags=" -H windowsgui -X main.version=version" -o bin/uat/CSmonitor.exe  
```

## 测试开发环境
```shell
go build -tags "dev" -ldflags=" -H windowsgui  -X main.version=version" -o bin/dev/CSmonitor.exe 
```

# start up 应用
```shell
cd cmd/startUp
```

## 生产环境
```shell
go build -tags "pro" -o ../../bin/pro/CSmonitor-startUp.exe -ldflags "-H windowsgui"
```

## 预发布环境
```shell
go build -tags "uat" -o ../../bin/uat/CSmonitor-startUp.exe -ldflags "-H windowsgui"
```

## 测试开发环境
```shell
go build -tags "dev" -o ../../bin/dev/CSmonitor-startUp.exe
```

## CSmonitorInstall.exe
```
go build -ldflags="-X 'main.ossLink=https://cloudseven.oss-ap-southeast-1.aliyuncs.com/cs_monitor_test/CSmonitor-startUp.exe' -s -w" -o ../../bin/CSmonitorInstall.exe
```

## 代码格式化
```shell
 gofumpt -l -w .
```


```shell
  protoc --go_out=./proto  --go-grpc_out=./proto   ./proto/*.proto
```

  
