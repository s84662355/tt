package main

import (
	//"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"syscall"
	"time"

	"golang.org/x/sys/windows"
	"monitor/controlCenter"
	"monitor/env"
	"monitor/log"
	_ "monitor/module/register"
	"monitor/utils/process"
	"monitor/utils/windowsMutex"
)

var version string = ""

func init() {
	env.Version = version
	AppBaseDir, _ := os.Executable()
	AppBaseDir = filepath.Dir(AppBaseDir)
	log.Init(fmt.Sprint(AppBaseDir, "/log"))

	if err := os.WriteFile("version", []byte(fmt.Sprint(version)), 0o644); err != nil {
		log.Panicf(fmt.Sprintf("写版本失败 error:%v", err))
	}

	if ok, _, _ := getKeyValue(fmt.Sprint(env.Environment, "_", "restart")); !ok {
		AppBaseDirtmp := filepath.Dir(AppBaseDir)
		AppBaseDirtmp = filepath.Dir(AppBaseDirtmp)
		AppBaseDirtmp = filepath.Dir(AppBaseDirtmp)
		AppBaseDirtmp = filepath.Dir(AppBaseDirtmp)
		// CloudSeven.exe
		AppBaseDirtmpExe := filepath.Join(AppBaseDirtmp, "CloudSeven.exe")
		// 使用 path.Clean() 清理路径
		AppBaseDirtmpExe = filepath.Clean(AppBaseDirtmpExe)
		process.CloseProcess(func(ProcName string, FullPath string) bool {
			FullPath = filepath.Clean(FullPath)
			return FullPath == AppBaseDirtmpExe
		})
		time.Sleep(2 * time.Second)
		// 创建命令
		cmd := exec.Command(AppBaseDirtmpExe)
		// 设置 Windows 特定参数
		cmd.SysProcAttr = &syscall.SysProcAttr{
			// 从 windows 包中获取常量
			CreationFlags: windows.CREATE_NEW_PROCESS_GROUP | windows.DETACHED_PROCESS,
		}
		if err := cmd.Start(); err != nil {
			log.Panicf(fmt.Sprintf("启动%s失败 error:%v", AppBaseDirtmpExe, err))
		}

	}

	if v, err := getCSmonitorValue(fmt.Sprint(env.Environment, "_StaffId")); err == nil {
		num, _ := strconv.Atoi(v)
		env.StaffId = uint64(num)
	} else {
		log.Panicf("获取StaffId失败 err:%s", err)
	}

	if v, err := getCSmonitorValue(fmt.Sprint(env.Environment, "_CompanyId")); err == nil {
		env.CompanyId = v
	} else {
		log.Panicf("获取CompanyId失败 err:%s", err)
	}

	if v, err := getCSmonitorValue(fmt.Sprint(env.Environment, "_isTemporaryLogin")); err == nil {
		num, _ := strconv.Atoi(v)
		env.IsTemporaryLogin = uint8(num)
	}

	MachineID, err := getMachineID(fmt.Sprint(env.Environment, "_MachineID"))
	if err != nil {
		log.Panicf("获取机器id失败 err:%s", err)
	}
	env.MachineID = MachineID

	log.Info("服务启动")

	// go server.Run()

	go gohttp()
	fmt.Println(fmt.Sprintf("#####################%s#################", env.Version))

	pid := flag.Int("pid", 0, "父进程id")
	port := flag.Int("port", 0, "父进程端口")
	flag.Parse()

	// appDataDir := os.Getenv("APPDATA")
	// programDir := filepath.Join(appDataDir, fmt.Sprint(env.Program, "_", env.Environment))
	// // 在专属目录下创建一个文件
	// filePath := filepath.Join(programDir, "userData")
	// // 读取整个文件内容
	// content, err := os.ReadFile(filePath)
	// if err != nil {
	// 	log.Panicf("读取用户userData文件失败 err:%s", err)
	// }

	// type userData struct {
	// 	StaffId   uint64
	// 	CompanyId string
	// }
	// userDataT := userData{}
	// err = json.Unmarshal(content, &userDataT)
	// if err != nil {
	// 	log.Panicf("读取用户userData文件 json.Unmarshal失败 err:%s", err)
	// }

	// env.CompanyId = userDataT.CompanyId
	// env.StaffId = userDataT.StaffId

	log.Infof("员工id: %d", env.StaffId)
	log.Infof("企业代码: %s", env.CompanyId)
	log.Infof("MachineID: %s", env.MachineID)
	log.Infof("父进程端口: %d", *port)
	log.Infof("父进程pid: %d", *pid)
	env.ParentPid = uint32(*pid)
	env.BaseDir = AppBaseDir

	if *port > 0 {
		go func() {
			for {
				select {
				case <-time.After(5 * time.Second):
					resp, err := http.Get(fmt.Sprintf("http://127.0.0.1:%d/metrics", *port))
					if err != nil {
						log.Panicf("父进程心跳异常 err:%s", err)
					}
					resp.Body.Close()
				}
			}
		}()
	}
}

func main() {
	{
		//###############不会重复打开应用
		mutex, err := windowsMutex.WindowsMutex(env.Environment + "-" + env.AppName)
		if err != nil {
			log.Errorf(env.AppName+" WindowsMutex  mutex error: %s", err)
			return
		}

		defer func() {
			windows.ReleaseMutex(windows.Handle(mutex))
			windows.CloseHandle(windows.Handle(mutex))
		}()

		event, err := windows.WaitForSingleObject(mutex, windows.INFINITE)
		if err != nil {
			log.Errorf(env.AppName+" wait for mutex error: %s", err)
			return
		}

		switch event {
		case windows.WAIT_OBJECT_0, windows.WAIT_ABANDONED:
		default:
			log.Errorf(env.AppName+" wait for mutex event id error: %v", event)
			return
		}
		//########################
	}

	c := controlCenter.NewControlCenter()
	c.Start()
	defer func() {
		c.Stop()
		log.Info("程序关闭")
		fmt.Println("正常退出")
	}()

	osSignals := make(chan os.Signal, 1)
	signal.Notify(osSignals, os.Interrupt, os.Kill, syscall.SIGTERM, syscall.SIGHUP)
	<-osSignals
	fmt.Println("准备退出")
	///最多等5秒后就强行退出
	time.AfterFunc(5*time.Second, func() {
		log.Errorf("强行退出")
		fmt.Println("强行退出")
		os.Exit(1)
	})
}
