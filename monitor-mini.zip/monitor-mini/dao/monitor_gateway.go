package dao

import (
	"context"
	"fmt"
	"net"

	"monitor/api"
	"monitor/env"
	"monitor/module/process"
	utilsIp "monitor/utils/ip"
)

func GetMonitorGateway(
	ctx context.Context,
	ip, BaseboardId, InnerIp string,
	StaffId uint64,
	account string,
	Port int,
) (ScreenRecordHost, address string, port int, err error) {
	req := &api.MonitorGateWayReq{
		MonitorIp:   ip,
		BaseboardId: BaseboardId,
		InnerIp:     InnerIp,
	}

	if cpuName, errr := process.GetCpuModelName(ctx); errr != nil {
		err = fmt.Errorf("GetCpuModelName GetMonitorGateway => GetCpuModelName err: %w", errr)
		// return
	} else {
		req.CpuInfo = cpuName
	}

	if vm, errr := process.GetVmTotal(ctx); errr != nil {
		err = fmt.Errorf("GetVmTotal GetMonitorGateway => GetVmTotal err: %w", errr)
		// return
	} else {
		req.VmTotal = vm
	}

	if DiskTotal, errr := process.GetDiskTotal(ctx); errr != nil {
		err = fmt.Errorf("GetDiskTotal GetMonitorGateway => GetDiskTotal err: %w", errr)
		// return
	} else {
		req.DiskTotal = DiskTotal
	}

	if OsVersion, errr := process.GetWindowsVersion(ctx); errr != nil {
		err = fmt.Errorf("GetWindowsVersion GetMonitorGateway =>  GetWindowsVersion err: %w", errr)
		// return
	} else {
		req.OsVersion = OsVersion
	}

	err = nil

	req.StaffId = StaffId
	req.Account = account
	req.Port = Port
	if env.IsTemporaryLogin == 1 {
		req.IsTmpLogin = true
	}

	if resp, errr := api.GetCsMonitorGateway(req); errr != nil {
		err = fmt.Errorf("GetCsMonitorGateway GetMonitorGateway 请求服务端  err: %w", errr)
		return
	} else {
		address = resp.Ip
		port = resp.Port
		ScreenRecordHost = resp.ScreenRecordHost

		// 如果不是ip
		if !utilsIp.IsValidIP(address) {
			ips, errr := net.LookupIP(address)
			if errr != nil {
				err = fmt.Errorf("GetMonitorGateway  LookupIP %s err: %w", address, errr)
				return
			}

			if len(ips) == 0 {
				err = fmt.Errorf("GetMonitorGateway  ips count == 0 ")
				return
			}
			address = ips[0].String()

		}
	}
	return
}
