package dao

import (
	"context"
	"testing"

	uIp "monitor/utils/ip"
)

// go test -run TestGetMonitorGateway -v  -tags "dev"
func TestGetMonitorGateway(t *testing.T) {
	ipAdapterInfo, err := uIp.DefaultNIC()
	if err != nil {
		t.Error("GetMonitorGateway DefaultNIC err: ", err)
		return
	}

	t.Log("GetMonitorGateway:", ipAdapterInfo.IpAddress)

	ip, err := uIp.GetIpFromCache(context.Background())
	if err != nil {
		t.Error("GetMonitorGateway ip err:", err)
		return
	}

	t.Log("GetIpFromCache:", ip)

	address, port, err := GetMonitorGateway(context.Background(), ip, ipAdapterInfo.MacAddress, ipAdapterInfo.IpAddress, 21, "sdfsdfs", 15)
	if err != nil {
		t.Error("GetMonitorGateway http err:", err)
		return
	}

	t.Log("ip ,port:", address, port)
}
