package log

import (
	"fmt"
	"runtime/debug"
)

func Info(p ...any) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprint(p...)
	zaploger.Info(detail)
}

func Warn(p ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprint(p...)
	zaploger.Warn(detail)
}

func Error(p ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprint(p...)
	zaploger.Error(detail)
}

func Debug(p ...interface{}) {
	if zaploger == nil {
		return
	}
	///zaploger.Debug(fmt.Sprint(p...))
}

func DPanic(p ...interface{}) {
	if zaploger == nil {
		return
	}

	detail := fmt.Sprint(p...)
	zaploger.DPanic(detail)
}

func Panic(p ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprint(p...)
	zaploger.Panic(detail)
}

func Fatal(p ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprint(p...)
	zaploger.Fatal(detail)
}

// /会抛出异常
func Recover(p ...interface{}) {
	if zaploger == nil {
		return
	}
	err := recover()
	if err != nil {
		detail := fmt.Sprint(p...) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack())
		zaploger.Fatal(detail)
		// zaploger.Fatal((fmt.Sprint(p...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack()))
	}
}

// /不会抛出异常
func DRecover(p ...interface{}) {
	if zaploger == nil {
		return
	}
	err := recover()
	if err != nil {

		detail := fmt.Sprint(p...) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack())
		zaploger.DPanic(detail)

		///	zaploger.DPanic((fmt.Sprint(p...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack()))
	}
}

func Infof(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}

	detail := fmt.Sprintf(format, args...)
	zaploger.Info(detail)

	// zaploger.Info(fmt.Sprintf(format, args...))
}

func Warnf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprintf(format, args...)
	zaploger.Warn(detail)

	// zaploger.Warn(fmt.Sprintf(format, args...))
}

func Errorf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}

	detail := fmt.Sprintf(format, args...)
	zaploger.Error(detail)

	// zaploger.Error(fmt.Sprintf(format, args...))
}

func Debugf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}

	// zaploger.Debug(fmt.Sprintf(format, args...))
}

func DPanicf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprintf(format, args...)
	zaploger.DPanic(detail)

	// zaploger.DPanic(fmt.Sprintf(format, args...))
}

func Panicf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}

	detail := fmt.Sprintf(format, args...)
	zaploger.Fatal(detail)

	// zaploger.Fatal(fmt.Sprintf(format, args...))
}

func Fatalf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}
	detail := fmt.Sprintf(format, args...)
	zaploger.Fatal(detail)

	// zaploger.Fatal(fmt.Sprintf(format, args...))
}

// /会抛出异常
func Recoverf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}
	err := recover()
	if err != nil {
		detail := (fmt.Sprintf(format, args...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack())
		zaploger.Fatal(detail)
		//	zaploger.Fatal((fmt.Sprintf(format, args...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack()))
	}
}

// /不会抛出异常
func DRecoverf(format string, args ...interface{}) {
	if zaploger == nil {
		return
	}
	err := recover()
	if err != nil {

		detail := (fmt.Sprintf(format, args...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack())
		zaploger.DPanic(detail)

		// zaploger.DPanic((fmt.Sprintf(format, args...)) + fmt.Sprint(" error: ", err) + " debug.Stack: " + string(debug.Stack()))
	}
}
