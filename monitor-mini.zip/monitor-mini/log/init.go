package log

import (
	"io"
	"time"

	rotatelogs "github.com/lestrrat-go/file-rotatelogs"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	// /	"gopkg.in/natefinch/lumberjack.v2"
)

var encoder zapcore.Encoder

var infoLevel, warnLevel,
	errorLevel,
	debugLevel,
	dPanicLevel,
	panicLevel,
	fatalLevel zap.LevelEnablerFunc

var zaploger *zap.Logger

func Init(filepath string) {
	// 设置一些基本日志格式 具体含义还比较好理解，直接看zap源码也不难懂
	encoderConfig := zapcore.EncoderConfig{
		MessageKey: "msg",
		LevelKey:   "level",
		// EncodeLevel: zapcore.CapitalColorLevelEncoder,
		EncodeLevel: zapcore.CapitalLevelEncoder,

		CallerKey: "caller",
		TimeKey:   "ts",
		EncodeTime: func(t time.Time, enc zapcore.PrimitiveArrayEncoder) {
			enc.AppendString(t.Format("2006-01-02 15:04:05"))
		},
		LineEnding: "",

		//	EncodeCaller: zapcore.ShortCallerEncoder,
		EncodeCaller: callerEncodeCaller,
		EncodeDuration: func(d time.Duration, enc zapcore.PrimitiveArrayEncoder) {
			enc.AppendInt64(int64(d) / 1000000)
		},
	}

	encoder = zapcore.NewJSONEncoder(encoderConfig)

	infoLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.InfoLevel
	})
	warnLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.WarnLevel
	})
	errorLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.ErrorLevel
	})

	debugLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.DebugLevel
	})

	dPanicLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.DPanicLevel
	})

	panicLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.PanicLevel
	})

	fatalLevel = zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl == zapcore.FatalLevel
	})

	// 获取 info、warn日志文件的io.Writer 抽象 getWriter() 在下方实现
	infoWriter := getWriter(filepath + "/info")
	warnWriter := getWriter(filepath + "/warn")
	errorWriter := getWriter(filepath + "/error")
	debugWriter := getWriter(filepath + "/debug")
	dPanicWriter := getWriter(filepath + "/dPanic")
	panicWriter := getWriter(filepath + "/panic")
	fatalWriter := getWriter(filepath + "/fatal")

	// 最后创建具体的Logger
	core := zapcore.NewTee(

		zapcore.NewCore(encoder, zapcore.AddSync(infoWriter), infoLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(warnWriter), warnLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(errorWriter), errorLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(debugWriter), debugLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(dPanicWriter), dPanicLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(panicWriter), panicLevel),
		zapcore.NewCore(encoder, zapcore.AddSync(fatalWriter), fatalLevel),

		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), infoLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), warnLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), errorLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), debugLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), dPanicLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), panicLevel),
		// zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), fatalLevel),
	)

	zaploger = zap.New(core, zap.AddCaller())
}

func getWriter(filename string) io.Writer {
	hook, err := rotatelogs.New(
		filename+"_%Y-%m-%d.log", // 没有使用go风格反人类的format格式
		rotatelogs.WithLinkName(filename),
		//	rotatelogs.WithMaxAge(time.Hour*24*3),
		rotatelogs.WithRotationTime(time.Hour*24),
		rotatelogs.WithRotationSize(30*1024*1024),
		rotatelogs.WithRotationCount(5),
	)
	if err != nil {
		panic(err)
	}

	// 2. 配置按大小轮转（lumberjack）
	// sizeRotateWriter := &lumberjack.Logger{
	// 	Filename:   filename, // 实际写入的文件（由 rotatelogs 管理软链接）
	// 	MaxSize:    10,       // 单个文件最大100MB
	// 	MaxBackups: 2,        // 同一天最多保留10个备份
	// 	MaxAge:     3,        // 保留30天（与 rotatelogs 一致）

	// }

	// 3. 组合两个Writer：先按天轮转，再按大小轮转
	multiWriter := zapcore.NewMultiWriteSyncer(
		zapcore.AddSync(hook),
	//	zapcore.AddSync(sizeRotateWriter),
	)

	return multiWriter
}
