//go:build uat

package log

import (
	"go.uber.org/zap/zapcore"
)

var callerEncodeCaller = func(caller zapcore.EntryCaller, enc zapcore.PrimitiveArrayEncoder) {
	enc.AppendString("")
}
