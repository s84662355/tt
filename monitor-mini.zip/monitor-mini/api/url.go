package api

import (
	. "monitor/env"
)

const (
	prefix                = "/api"
	CsMonitorGatewayUrl   = Host + prefix + "/external/csMonitorGateway"   ///获取网关入口
	CsMonitorVersionUrl   = Host + prefix + "/external/csMonitorVersion"   ///获取版本更新包
	CsMonitorCommitLogUrl = Host + prefix + "/external/csDeskLog"          // 提交日志
	CsMonitorVirtualIp    = Host + prefix + "/external/csMonitorVirtualIp" // 获取虚拟ip

)
