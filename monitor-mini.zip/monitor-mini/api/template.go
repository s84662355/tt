package api

type Response[T any] struct {
	Code    int    `json:"code"`
	Msg     string `json:"msg"`
	Success bool   `json:"success"`
	Data    T      `json:"data"`
}

type MonitorGateWayReq struct {
	MonitorIp   string `json:"monitorIp"` // IP
	InnerIp     string `json:"innerIp"`
	BaseboardId string `json:"baseboardId"` // 主板序列号(190652502800677)
	CpuInfo     string `json:"cpuInfo"`     // cpu型号(Intel(R) Core(TM) i7-9700 CPU @ 3.00GHz @ 3000)
	VmTotal     uint64 `json:"vmTotal"`     // 内存总大小
	DiskTotal   uint64 `json:"diskTotal"`   // 磁盘总大小
	OsVersion   string `json:"osVersion"`   // 系统版本(Microsoft Windows 11 Pro 10.0.22621.4317 Build 22621.4317)
	CpuCount    int    `json:"cpuCount"`    // cpu核心数
	StaffId     uint64 `json:"staffId"`     // 员工id
	Account     string `json:"account"`     // 服务器账号
	Port        int    `json:"port"`
	IsTmpLogin  bool   `json:"isTmpLogin"`
}

type MonitorGateWayResp struct {
	Ip               string `json:"ip"` // IP
	Port             int    `json:"port"`
	ScreenRecordHost string `json:"screenRecordHost"`
}

type MonitorVersionResp struct {
	DownloadLink string `json:"download_link"`
	Version      string `json:"version"`
}

type MonitorLog struct {
	StaffId   uint64 `json:"staff_id"`
	ProcessId int    `json:"process_id"`
	Timestamp int64  `json:"timestamp"`
	AppId     string `json:"app_id"`
	Version   string `json:"version"`
	Ip        string `json:"ip"`
	LogLevel  string `json:"log_level"`
	LogDetail string `json:"log_detail"`
}

type MonitorVirtualIpResp struct {
	VirtualIp      string `json:"virtualIp"`
	ForwardIp      string `json:"forwardIp"`
	NetworkSegment string `json:"network_segment"`
}
