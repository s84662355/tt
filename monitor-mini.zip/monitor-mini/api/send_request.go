package api

import (
	"runtime"
)

// /获取网关ip
func GetCsMonitorGateway(req *MonitorGateWayReq) (*MonitorGateWayResp, error) {
	req.CpuCount = runtime.NumCPU()
	monitorGateWayResp := &MonitorGateWayResp{}
	err := postRequest[*MonitorGateWayResp](CsMonitorGatewayUrl, req, monitorGateWayResp)
	if err != nil {
		return nil, err
	}
	return monitorGateWayResp, nil
}

func GetCsMonitorVersion() (*MonitorVersionResp, error) {
	monitorVersionResp := &MonitorVersionResp{}
	err := postRequest[*MonitorVersionResp](CsMonitorVersionUrl, map[string]struct{}{}, monitorVersionResp)
	if err != nil {
		return nil, err
	}
	return monitorVersionResp, nil
}

func CommitCsMonitorLog(req []*MonitorLog) error {
	return postRequest[struct{}](CsMonitorCommitLogUrl, req, struct{}{})
}

func MonitorVirtualIp(baseboardId string, isTmpLogin bool) (*MonitorVirtualIpResp, error) {
	monitorVirtualIpResp := &MonitorVirtualIpResp{}
	err := postRequest[*MonitorVirtualIpResp](CsMonitorVirtualIp, map[string]interface{}{
		"baseboardId": baseboardId,
		"isTmpLogin":  isTmpLogin,
	}, monitorVirtualIpResp)
	if err != nil {
		return nil, err
	}
	return monitorVirtualIpResp, nil
}
