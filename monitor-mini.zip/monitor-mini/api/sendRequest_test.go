package api

// go test -v -tags "dev"
import (
	"runtime"
	"testing"
	"time"
)

func TestGetCsMonitorGateway(t *testing.T) {
	req := &MonitorGateWayReq{
		MonitorIp:   "158.36.45.8",
		BaseboardId: "9230483209",
		CpuInfo:     "abcdefg",
		VmTotal:     1024 * 1024,
		DiskTotal:   1024 * 1024,
		OsVersion:   "1.2.5",
		CpuCount:    runtime.NumCPU(),
	}

	rep, err := GetCsMonitorGateway(req)
	if err != nil {
		t.Error("get  网关 err: ", err)
		return
	}
	t.Log("rep:", rep)
}

func TestGetCsMonitorVersion(t *testing.T) {
	rep, err := GetCsMonitorVersion()
	if err != nil {
		t.Error("get 更新包 err: ", err)
		return
	}
	t.Log("rep:", rep)
}

func TestCommitCsMonitorLog(t *testing.T) {
	err := CommitCsMonitorLog([]*MonitorLog{
		{
			StaffId:   12233,
			Timestamp: time.Now().Unix(),
			AppId:     "cs_monitor",
			Version:   "2.23.43",
			LogLevel:  "info",
			LogDetail: "test",
		},
	})
	if err != nil {
		t.Error("CommitCsMonitorLog err: ", err)
		return
	}
}
