package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"time"
)

var (
	client        *http.Client
	Authorization AuthorizationData
	BlackList     []string
	CountryCode   string
	Ip            string
)

type AuthorizationData struct {
	AccessToken  string `json:"accessToken"`
	RefreshToken string `json:"refreshToken"`
	Url          string `json:"url"`
}

const (
	NoLoginCode     = 401 // 没有登录
	internalErrCode = "系统内部错误 Internal System Error"
	ResponseSuccess = 0
)

func init() {
	client = &http.Client{
		Timeout: time.Second * 20,
		Transport: &http.Transport{
			MaxConnsPerHost:       5,
			MaxIdleConnsPerHost:   10,
			MaxIdleConns:          20,
			IdleConnTimeout:       90 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: 3 * time.Second,
		},
	}
}

func getRequest[response any](remoteUrl string, values map[string]interface{}, respData response) *Error {
	uri, err := url.Parse(remoteUrl)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	if values != nil {
		queryValues := url.Values{}
		for k, v := range values {
			if v != nil {
				queryValues[k] = []string{fmt.Sprint(v)}
			}
		}
		uri.RawQuery = queryValues.Encode()
	}
	if req, err := http.NewRequest("GET", uri.String(), nil); err != nil {
		return &Error{
			Message: internalErrCode,
		}
	} else {
		return sendRequest(req, respData)
	}
}

func postRequest[response any](remoteUrl string, data interface{}, respData response) *Error {
	if body, err := json.Marshal(data); err != nil {
		return &Error{
			Message: internalErrCode,
		}
	} else {
		if req, err := http.NewRequest("POST", remoteUrl, bytes.NewBuffer(body)); err != nil {
			return &Error{
				Message: internalErrCode,
			}
		} else {
			req.Header.Set("Content-Type", "application/json; charset=UTF-8")
			return sendRequest(req, respData)
		}
	}
}

func sendRequest[response any](req *http.Request, respData response) *Error {
	// req.Header.Set("Authorization", authorization)
	if resp, err := client.Do(req); err != nil {
		return &Error{
			Message: fmt.Sprint(err),
		}
	} else {
		defer resp.Body.Close()
		if bodyBytes, err := ioutil.ReadAll(resp.Body); err != nil {
			return &Error{
				HttpStatus: resp.StatusCode,
				Message:    fmt.Sprint(err),
			}
		} else {
			if resp.StatusCode != http.StatusOK {
				return &Error{
					HttpStatus: resp.StatusCode,
					Message:    fmt.Sprint(err),
				}
			}
			respTemplate := Response[response]{
				Data: respData,
			}
			if err = json.Unmarshal(bodyBytes, &respTemplate); err != nil {
				return &Error{
					HttpStatus: resp.StatusCode,
					Message:    fmt.Sprint(err),
				}
			}

			if respTemplate.Code != ResponseSuccess {
				return &Error{
					HttpStatus: resp.StatusCode,
					Code:       respTemplate.Code,
					Message:    respTemplate.Msg,
				}
			}
			return nil
		}
	}
}

func uploadFile[response any](url string, file_path string, values map[string]interface{}, respData response) *Error {
	file, err := os.Open(file_path) // 打开文件
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	defer file.Close()
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", filepath.Base(file.Name()))
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	_, err = io.Copy(part, file)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	if values != nil {
		for k, v := range values {
			if v != nil {
				writer.WriteField(k, fmt.Sprint(v))
			}
		}
	}
	err = writer.Close()
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	req, err := http.NewRequest("POST", url, body)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())
	return sendRequest[response](req, respData)
}

func uploadFileByte[response any](url string, fileName string, fileByte []byte, values map[string]interface{}, respData response) *Error {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", fileName)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}

	_, err = part.Write(fileByte)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	if values != nil {
		for k, v := range values {
			if v != nil {
				writer.WriteField(k, fmt.Sprint(v))
			}
		}
	}
	err = writer.Close()
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	req, err := http.NewRequest("POST", url, body)
	if err != nil {
		return &Error{
			Message: internalErrCode,
		}
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())
	return sendRequest[response](req, respData)
}
