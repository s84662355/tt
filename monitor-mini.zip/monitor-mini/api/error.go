package api

import (
	"fmt"
)

// 定义一个自定义错误类型
type Error struct {
	HttpStatus int
	Code       int
	Message    string
	Data       interface{}
}

// 实现Error接口
func (ce Error) Error() string {
	return fmt.Sprintf("HttpStatus:%d Error Code: %d, Message: %s", ce.HttpStatus, ce.Code, ce.Message)
}
