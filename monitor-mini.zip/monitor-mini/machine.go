package main

import (
	"fmt"
	"math/rand"
	"time"

	"golang.org/x/sys/windows/registry"
)

const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

func init() {
	// 为随机数生成器设置种子，以确保每次运行时产生不同的结果
	rand.Seed(time.Now().UnixNano())
}

func generateRandomString(length int) string {
	charsetStr := fmt.Sprintf("%d%s%d", time.Now().UnixNano(), charset, time.Now().UnixNano())
	// 创建一个字符切片，用于存储随机字符
	result := make([]byte, length)
	for i := range result {
		// 遍历所需长度，从charset中随机选取字符并添加到result切片中
		result[i] = charsetStr[rand.Intn(len(charset))]
	}
	return string(result)
}

func getKeyValue(Key string) (bool, string, error) {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key
	valueData := generateRandomString(18)

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			// 如果键不存在，则创建它
			key, _, err = registry.CreateKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
			if err != nil {
				return false, "", err
			}
			defer key.Close()
			return false, "", err
		}
	}
	defer key.Close()

	// 尝试读取注册表值
	data, _, err := key.GetStringValue(valueName)
	if err != nil || data == "" {
		if err == registry.ErrNotExist || data == "" {
			// 如果值不存在，则写入它
			err = key.SetStringValue(valueName, valueData)
			if err != nil {
				return false, "", err
			}
			return false, valueData, nil
		} else {
			return false, "", err
		}
	} else {
		return true, data, nil
	}
}

func getDeskMachineID(Key string, value string) (string, error) {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key
	valueData := value

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			// 如果键不存在，则创建它
			key, _, err = registry.CreateKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
			if err != nil {
				fmt.Printf("创建注册表项失败: %v\n", err)
				return "", err
			}
			defer key.Close()
			fmt.Println("注册表项不存在，已成功创建。")
		} else {
			fmt.Printf("打开注册表项失败: %v\n", err)
			return "", err
		}
	}
	defer key.Close()

	// 尝试读取注册表值

	err = key.SetStringValue(valueName, valueData)
	if err != nil {
		fmt.Printf("写入注册表值失败: %v\n", err)
		return "", err
	}
	fmt.Println("注册表值不存在，已成功写入。")
	return valueData, nil
}

func getMachineID(Key string) (string, error) {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key
	valueData := generateRandomString(18)

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			// 如果键不存在，则创建它
			key, _, err = registry.CreateKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
			if err != nil {
				fmt.Printf("创建注册表项失败: %v\n", err)
				return "", err
			}
			defer key.Close()
			fmt.Println("注册表项不存在，已成功创建。")
		} else {
			fmt.Printf("打开注册表项失败: %v\n", err)
			return "", err
		}
	}
	defer key.Close()

	// 尝试读取注册表值
	data, _, err := key.GetStringValue(valueName)
	if err != nil || data == "" {
		if err == registry.ErrNotExist || data == "" {
			// 如果值不存在，则写入它
			err = key.SetStringValue(valueName, valueData)
			if err != nil {
				fmt.Printf("写入注册表值失败: %v\n", err)
				return "", err
			}
			fmt.Println("注册表值不存在，已成功写入。")
			return valueData, nil
		} else {
			fmt.Printf("读取注册表值失败: %v\n", err)
			return "", err
		}
	} else {
		fmt.Printf("成功读取注册表值: %s\n", data)
		return data, nil
	}
}

func getCSmonitorValue(Key string) (string, error) {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			defer key.Close()
			fmt.Println("注册表项不存在，已成功创建。")
			return "", fmt.Errorf("注册表项不存在，已成功创建。")
		} else {
			fmt.Printf("打开注册表项失败: %v\n", err)
			return "", err
		}
	}
	defer key.Close()

	// 尝试读取注册表值
	data, _, err := key.GetStringValue(valueName)
	if err != nil {
		fmt.Printf("读取注册表值失败: %v\n", err)
		return "", err
	} else {
		if data == "" {
			return "", fmt.Errorf("is empty")
		}
		fmt.Printf("成功读取注册表值: %s\n", data)
		return data, nil
	}
}
