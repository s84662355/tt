package ip

import (
	"fmt"
	"os"
	"strings"
	"syscall"
	"unsafe"
)

type IpAdapterInfo struct {
	AdapterName  string
	Description  string
	MacAddress   string
	IpAddress    string
	IpMask       string
	GatewayIp    string
	DHCPServerIp string
}

func getAdapterList() (*syscall.IpAdapterInfo, error) {
	b := make([]byte, 1000)
	l := uint32(len(b))
	a := (*syscall.IpAdapterInfo)(unsafe.Pointer(&b[0]))
	err := syscall.GetAdaptersInfo(a, &l)
	if err == syscall.ERROR_BUFFER_OVERFLOW {
		b = make([]byte, l)
		a = (*syscall.IpAdapterInfo)(unsafe.Pointer(&b[0]))
		err = syscall.GetAdaptersInfo(a, &l)
	}
	if err != nil {
		return nil, os.NewSyscallError("GetAdaptersInfo", err)
	}
	return a, nil
}

func LocalAddresses() ([]*IpAdapterInfo, error) {
	aList, err := getAdapterList()
	if err != nil {
		return nil, fmt.Errorf("LocalAddresses err:%w", err)
	}

	ipAdapterInfos := []*IpAdapterInfo{}
	for ai := aList; ai != nil; ai = ai.Next {
		ipAdapterInfo := &IpAdapterInfo{
			AdapterName: fmt.Sprintf("%s", ai.AdapterName),
			Description: fmt.Sprintf("%s", ai.Description),
		}

		macAddress := ""
		for i := 0; i < int(ai.AddressLength); i++ {
			if i == int((ai.AddressLength - 1)) {
				macAddress += fmt.Sprintf("%.2X", int(ai.Address[i]))
			} else {
				macAddress += fmt.Sprintf("%.2X-", int(ai.Address[i]))
			}
		}
		ipAdapterInfo.MacAddress = macAddress
		ipl := &ai.IpAddressList
		gwl := &ai.GatewayList
		dhcpl := &ai.DhcpServer

		ipAdapterInfo.IpAddress = fmt.Sprintf("%s", ipl.IpAddress)
		ipAdapterInfo.IpMask = fmt.Sprintf("%s", ipl.IpMask)
		ipAdapterInfo.GatewayIp = fmt.Sprintf("%s", gwl.IpAddress)
		ipAdapterInfo.DHCPServerIp = fmt.Sprintf("%s", dhcpl.IpAddress)

		ipAdapterInfo.IpAddress = strings.Replace(ipAdapterInfo.IpAddress, "{", "", -1)
		ipAdapterInfo.IpAddress = strings.Replace(ipAdapterInfo.IpAddress, "}", "", -1)
		ipAdapterInfo.IpAddress = strings.ReplaceAll(ipAdapterInfo.IpAddress, "\x00", "")

		ipAdapterInfo.IpMask = strings.Replace(ipAdapterInfo.IpMask, "{", "", -1)
		ipAdapterInfo.IpMask = strings.Replace(ipAdapterInfo.IpMask, "}", "", -1)
		ipAdapterInfo.IpMask = strings.ReplaceAll(ipAdapterInfo.IpMask, "\x00", "")

		ipAdapterInfo.GatewayIp = strings.Replace(ipAdapterInfo.GatewayIp, "{", "", -1)
		ipAdapterInfo.GatewayIp = strings.Replace(ipAdapterInfo.GatewayIp, "}", "", -1)
		ipAdapterInfo.GatewayIp = strings.ReplaceAll(ipAdapterInfo.GatewayIp, "\x00", "")

		ipAdapterInfo.DHCPServerIp = strings.Replace(ipAdapterInfo.DHCPServerIp, "{", "", -1)
		ipAdapterInfo.DHCPServerIp = strings.Replace(ipAdapterInfo.DHCPServerIp, "}", "", -1)
		ipAdapterInfo.DHCPServerIp = strings.ReplaceAll(ipAdapterInfo.DHCPServerIp, "\x00", "")

		ipAdapterInfo.MacAddress = strings.Replace(ipAdapterInfo.MacAddress, "{", "", -1)
		ipAdapterInfo.MacAddress = strings.Replace(ipAdapterInfo.MacAddress, "}", "", -1)
		ipAdapterInfo.MacAddress = strings.ReplaceAll(ipAdapterInfo.MacAddress, "\x00", "")

		ipAdapterInfo.AdapterName = strings.Replace(ipAdapterInfo.AdapterName, "{", "", -1)
		ipAdapterInfo.AdapterName = strings.Replace(ipAdapterInfo.AdapterName, "}", "", -1)
		ipAdapterInfo.AdapterName = strings.ReplaceAll(ipAdapterInfo.AdapterName, "\x00", "")

		ipAdapterInfo.Description = strings.Replace(ipAdapterInfo.Description, "{", "", -1)
		ipAdapterInfo.Description = strings.Replace(ipAdapterInfo.Description, "}", "", -1)
		ipAdapterInfo.Description = strings.ReplaceAll(ipAdapterInfo.Description, "\x00", "")

		ipAdapterInfos = append(ipAdapterInfos, ipAdapterInfo)

	}
	return ipAdapterInfos, nil
}

func DefaultNIC() (*IpAdapterInfo, error) {
	infos, err := LocalAddresses()
	if err != nil {
		return nil, fmt.Errorf("DefaultNIC err:%w", err)
	}
	for _, info := range infos {
		if info.IpAddress != "0.0.0.0" && info.GatewayIp != "0.0.0.0" {
			return info, nil
		}
	}
	return nil, fmt.Errorf("DefaultNIC err: %w", err)
}
