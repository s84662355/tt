package ip

import (
	"testing"
)

// go test -v -run TestLocalAddresses
func TestLocalAddresses(t *testing.T) {
	infos, err := LocalAddresses()
	if err != nil {
		t.Error("LocalAddresses err: ", err)
		return
	}
	for _, info := range infos {
		t.Log(info)
	}
}

// /go test -bench BenchmarkLocalAddresses    -count=1
func BenchmarkLocalAddresses(t *testing.B) {
	infos, err := LocalAddresses()
	if err != nil {
		t.Error("LocalAddresses err: ", err)
		return
	}
	for _, info := range infos {
		t.Log(info)
	}
}

// go test -v -run TestDefaultNIC
func TestDefaultNIC(t *testing.T) {
	info, err := DefaultNIC()
	if err != nil {
		t.Error("LocalAddresses err: ", err)
		return
	}

	t.Log(info)
}

// /go test -bench BenchmarkDefaultNIC    -count=1
func BenchmarkDefaultNIC(t *testing.B) {
	info, err := DefaultNIC()
	if err != nil {
		t.Error("LocalAddresses err: ", err)
		return
	}

	t.Log(info)
}
