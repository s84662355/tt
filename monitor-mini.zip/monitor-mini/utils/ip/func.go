package ip

import (
	"context"
	"fmt"
	"net"
	"time"

	"github.com/skys-mission/gout/go/pubnet/iplocation"
)

func GetIpFromCache(ctx context.Context) (ip string, err error) {
	ipRWMutex.Lock()
	defer ipRWMutex.Unlock()
	if ipCache == "" {
		ip, err = updateIpCache(ctx)
		if err != nil {
			err = fmt.Errorf("GetIpFromCache err: %w", err)
			return
		}
	} else {
		if time.Now().Unix() > ipCacheTimeOut {
			ip, err = updateIpCache(ctx)
			if err != nil {
				err = fmt.Errorf("GetIpFromCache err: %w", err)
			}
			return
		}
		ip = ipCache
		return
	}
	return
}

func updateIpCache(ctx context.Context) (ip string, err error) {
	//	ip, err = GetIplocation(ctx)
	ip, err = GetPublicIP(ctx)
	if err != nil {
		err = fmt.Errorf("updateIpCache err: %w", err)
		return
	}
	ipCache = ip
	ipCacheTimeOut = time.Now().Unix() + ipCacheTTl
	return
}

func GetIplocation(ctx context.Context) (ip string, err error) {
	result, err := iplocation.RequestGetIPAddress(ctx)
	if err != nil {
		err = fmt.Errorf("GetIplocation err: %w", err)
		return
	}
	if result.ResponseCode != iplocation.ResponseCodeOKForGetIPAddress {
		err = fmt.Errorf("GetIplocation  code: %v msg: %v", result.ResponseCode, result.ResponseMessage)
		return
	}
	ip = result.IP
	return
}

func IsValidIP(ip string) bool {
	if net.ParseIP(ip) == nil {
		return false
	}
	return true
}
