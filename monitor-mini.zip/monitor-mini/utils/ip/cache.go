package ip

import (
	"sync"

	"monitor/utils/atomicLock"
)

const (
	ipCacheTTl int64 = 60 * 20
)

// /本机公网ip
var (
	// ipRWMutex      sync.Mutex ///用互斥锁就OK了
	ipRWMutex      sync.Locker = atomicLock.NewSpinLock() ///用互斥锁就OK了
	ipCache        string
	ipCacheTimeOut int64
)
