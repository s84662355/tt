package ip

import (
	"context"
	"sync"
	"testing"
)

// go test -v -run TestGetPublicIP
func TestGetPublicIP(t *testing.T) {
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			ip, err := GetIpFromCache(context.Background())
			if err != nil {
				t.Error("get  public ip err: ", err)
				return
			}
			t.Log("ip:", ip)
		}()
	}
	wg.Wait()
}
