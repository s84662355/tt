package ip

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

func GetPublicIP(ctx context.Context) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	f := NewFirstResultGroup[string](ctx)

	f.Go(func(ctx context.Context) (string, bool) {
		data, err := GetIPFromIPify(ctx)
		return data, err == nil
	}, func(data string) {
		fmt.Println("没有被采用的结果", data)
	})

	f.Go(func(ctx context.Context) (string, bool) {
		data, err := GetIPFromIPInfo(ctx)
		return data, err == nil
	}, func(data string) {
		fmt.Println("没有被采用的结果", data)
	})

	f.Go(func(ctx context.Context) (string, bool) {
		data, err := GetIPFromIcanhazip(ctx)
		return data, err == nil
	}, func(data string) {
		fmt.Println("没有被采用的结果", data)
	})

	return f.GetResult()
}

type (
	A[T any] func(ctx context.Context) (T, bool) // 任务函数
	B[T any] func(t T)                           // 当任务执行成功但结果未被采纳时执行
)

type FirstResultGroup[T any] struct {
	has    atomic.Bool
	result T
	err    error
	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup
	doOne  sync.Once
}

func NewFirstResultGroup[T any](ctx context.Context) *FirstResultGroup[T] {
	f := &FirstResultGroup[T]{}
	f.ctx, f.cancel = context.WithCancel(ctx)
	return f
}

func (f *FirstResultGroup[T]) Go(a A[T], b B[T]) {
	f.wg.Add(1)
	go func() {
		defer f.wg.Done()
		r, ok := a(f.ctx)
		if ok {
			if f.has.CompareAndSwap(false, true) {
				f.result = r
				f.cancel()
			} else {
				if b != nil {
					b(r)
				}
			}
		}
	}()
}

func (f *FirstResultGroup[T]) GetResult() (T, error) {
	f.doOne.Do(func() {
		f.wg.Wait()
		if !f.has.Load() {
			f.err = fmt.Errorf("所有任务均失败")
		}
	})
	return f.result, f.err
}

// 模拟浏览器的请求头
func getBrowserHeaders() http.Header {
	headers := http.Header{}
	headers.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36")
	headers.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
	headers.Set("Accept-Language", "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2")
	headers.Set("Accept-Encoding", "gzip, deflate, br")
	headers.Set("Connection", "keep-alive")
	headers.Set("Upgrade-Insecure-Requests", "1")
	return headers
}

// GetIPFromIPify 通过ipify.org获取公网IP
func GetIPFromIPify(ctx context.Context) (string, error) {
	client := &http.Client{}
	defer client.CloseIdleConnections()
	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.ipify.org", nil)
	if err != nil {
		return "", err
	}

	// 设置浏览器请求头
	req.Header = getBrowserHeaders()

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	r := strings.ReplaceAll(strings.ReplaceAll(string(body), "\r", ""), "\n", "")
	r = findIP(r)
	if r == "" {
		return "", fmt.Errorf("提取ip失败")
	}

	return r, nil
}

// GetIPFromIPInfo 通过ipinfo.io获取公网IP
func GetIPFromIPInfo(ctx context.Context) (string, error) {
	client := &http.Client{}
	defer client.CloseIdleConnections()
	req, err := http.NewRequestWithContext(ctx, "GET", "https://ipinfo.io/ip", nil)
	if err != nil {
		return "", err
	}

	// 设置浏览器请求头
	req.Header = getBrowserHeaders()

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	r := strings.ReplaceAll(strings.ReplaceAll(string(body), "\r", ""), "\n", "")
	r = findIP(r)
	if r == "" {
		return "", fmt.Errorf("提取ip失败")
	}

	return r, nil
}

// GetIPFromIcanhazip 通过icanhazip.com获取公网IP
func GetIPFromIcanhazip(ctx context.Context) (string, error) {
	client := &http.Client{}
	defer client.CloseIdleConnections()
	req, err := http.NewRequestWithContext(ctx, "GET", "https://icanhazip.com", nil)
	if err != nil {
		return "", err
	}

	// 设置浏览器请求头
	req.Header = getBrowserHeaders()

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	r := strings.ReplaceAll(strings.ReplaceAll(string(body), "\r", ""), "\n", "")

	r = findIP(r)
	if r == "" {
		return "", fmt.Errorf("提取ip失败")
	}

	return r, nil
}

func findIP(s string) string {
	ipv4Arr := findIPv4(s)
	if len(ipv4Arr) > 0 {
		return ipv4Arr[0]
	}
	ipv6Arr := findIPv6(s)
	if len(ipv6Arr) > 0 {
		return ipv6Arr[0]
	}

	return ""
}

// 匹配字符串中的所有IPv4地址
func findIPv4(s string) []string {
	// IPv4正则：匹配4组0-255的数字，用.分隔
	ipv4Regex := `\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b`
	re := regexp.MustCompile(ipv4Regex)
	return re.FindAllString(s, -1)
}

// 匹配字符串中的所有IPv6地址
func findIPv6(s string) []string {
	// IPv6正则：支持8组16进制数及压缩格式(::)
	ipv6Regex := `\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b`
	re := regexp.MustCompile(ipv6Regex)
	return re.FindAllString(s, -1)
}
