package win

import (
	"syscall"
)

var (
	user32         = syscall.NewLazyDLL("user32.dll")
	SetWindowsHook = user32.NewProc("SetWindowsHookExW")
	UnhookWindows  = user32.NewProc("UnhookWindowsHookEx")
	CallNextHook   = user32.NewProc("CallNextHookEx")
	GetMessage     = user32.NewProc("GetMessageW")
	TranslateMsg   = user32.NewProc("TranslateMessage")
	DispatchMsg    = user32.NewProc("DispatchMessageW")
	PostMessageW   = user32.NewProc("PostMessageW")
)

const (
	WM_CLOSE = 0x0010 // 关闭窗口
)

// 鼠标钩子常量
const (
	WH_MOUSE_LL = 14 // 低级鼠标钩子（全局监听）
)

// 鼠标消息类型
const (
	WM_MOUSEMOVE   = 0x0200
	WM_LBUTTONDOWN = 0x0201
	WM_LBUTTONUP   = 0x0202
	WM_RBUTTONDOWN = 0x0204
	WM_RBUTTONUP   = 0x0205
	WM_MBUTTONDOWN = 0x0207
	WM_MBUTTONUP   = 0x0208
	WM_MOUSEWHEEL  = 0x020A
	WM_MOUSEHWHEEL = 0x020E
)

// 鼠标事件结构体
type POINT struct {
	X, Y int32
}

type MSLLHOOKSTRUCT struct {
	Point       POINT
	MouseData   uint32
	Flags       uint32
	Time        uint32
	DwExtraInfo uintptr
}

// 消息结构体
type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Point   POINT
}
