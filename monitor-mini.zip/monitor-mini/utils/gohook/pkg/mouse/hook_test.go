package mouse

import (
	"fmt"
	"os"
	"testing"
	"time"
)

// go test   -run TestHook -v
func TestHook(t *testing.T) {
	// for i := 0; i < 2000; i++ {
	// 	h := &hook{}
	// 	_, err := h.Install()
	// 	if err != nil {
	// 		fmt.Println(err)
	// 		return
	// 	}
	// 	// time.Sleep(3*time.Second)
	// 	h.Uninstall()
	// }
	h := &hook{}
	c, err := h.Install()
	if err != nil {
		fmt.Println(err)
		return
	}

	time.AfterFunc(5*time.Second, func() {
		h.Uninstall()
		time.Sleep(time.Second)
		os.Exit(1)
	})
	i := 0
	for {
		select {
		case <-c:

			i++
			if i > 20 {
			}
		}
	}
}
