package mouse

import (
	"fmt"
	"runtime"
	"sync"
	"sync/atomic"
	"syscall"
	"unsafe"

	"monitor/utils/gohook/pkg/types"
	"monitor/utils/gohook/pkg/win32"
	"monitor/utils/win"
)

func New() *hook {
	return &hook{}
}

type hook struct {
	lMu                  sync.Mutex
	hf                   types.HOOKPROC
	Pointer              uintptr
	isGoChan             atomic.Bool
	isInstall            atomic.Bool
	isRun                atomic.Bool
	msgChan              chan types.MouseEvent
	msgChanCloseOnceFunc func()
	done                 chan struct{}
	doneCloseFunc        func()
	errCh                chan struct{}
	err                  error
}

func (h *hook) Install() (<-chan types.MouseEvent, error) {
	h.lMu.Lock()
	defer h.lMu.Unlock()

	if !h.isInstall.CompareAndSwap(false, true) {
		return nil, fmt.Errorf("mouse having Install")
	}

	h.msgChan = make(chan types.MouseEvent, 8)
	h.msgChanCloseOnceFunc = sync.OnceFunc(func() {
		close(h.msgChan)
	})
	h.done = make(chan struct{})

	h.doneCloseFunc = sync.OnceFunc(func() {
		close(h.done)
	})

	h.hf = func(code int32, wParam, lParam uintptr) uintptr {
		if !h.isRun.Load() {
			win32.PostMessageW(0, 0, 0, 0)
		}

		if lParam != 0 {
			if h.isRun.Load() {
				select {
				case h.msgChan <- types.MouseEvent{
					Message:        types.Message(wParam),
					MSLLHOOKSTRUCT: *(*types.MSLLHOOKSTRUCT)(unsafe.Pointer(lParam)),
				}:
				default:
				}
			}
		}
		return win32.CallNextHookEx(0, code, wParam, lParam)
	}

	h.errCh = make(chan struct{})
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()

		defer h.msgChanCloseOnceFunc()

		hhk := win32.SetWindowsHookEx(
			types.WH_MOUSE_LL,
			syscall.NewCallback(h.hf),
			0,
			0)

		if hhk == 0 {
			h.err = fmt.Errorf("mouse: failed to install hook function")
			close(h.errCh)
			return
		}

		close(h.errCh)

		h.Pointer = hhk
		var msg *types.MSG
		defer win32.UnhookWindowsHookEx(h.Pointer)
		h.isRun.Swap(true)
		for h.isRun.Load() {
			if win32.GetMessage(&msg, 0, 0, 0) != 0 {

				win32.TranslateMessage(&msg)
				win32.DispatchMessage(&msg)
			}
		}
	}()

	<-h.errCh
	if h.err != nil {
		h.doneCloseFunc()
		for range h.msgChan {
		}
	}

	return h.msgChan, h.err
}

func (h *hook) Uninstall() error {
	h.lMu.Lock()
	defer h.lMu.Unlock()
	if !h.isInstall.Load() {
		return fmt.Errorf("not isInstall")
	}

	select {
	case <-h.done:
		return nil
	default:
	}

	h.isRun.Swap(false)

	h.doneCloseFunc()

	// 模拟一个鼠标事件
	i := win.MOUSE_INPUT{
		Type: win.INPUT_MOUSE,
		Mi: win.MOUSEINPUT{
			Dx:      1,
			Dy:      0,
			DwFlags: win.MOUSEEVENTF_MOVE,
		},
	}

	for win.SendInput(1, unsafe.Pointer(&i), int32(unsafe.Sizeof(i))) == 0 {
	}

	for range h.msgChan {
	}

	return nil
}
