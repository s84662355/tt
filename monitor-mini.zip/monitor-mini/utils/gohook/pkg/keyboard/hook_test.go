package keyboard

import (
	"fmt"
	"os"
	"testing"
	"time"
)

// go test   -run TestHook -v
func TestHook(t *testing.T) {
	h := &hook{}
	c, err := h.Install()
	if err != nil {
		fmt.Println(err)
		return
	}

	time.AfterFunc(5*time.Second, func() {
		h.Uninstall()
		time.Sleep(3 * time.Second)
		os.Exit(1)
	})
	i := 0
	defer func() {
		time.Sleep(10 * time.Second)
	}()
	for {
		select {
		case _, ok := <-c:
			if !ok {
				return
			}
			i++
			if i > 20 {
			}
		}
	}
}
