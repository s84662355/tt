//go:build windows
// +build windows

package win32

import (
	"syscall"
	"unsafe"

	"monitor/utils/gohook/pkg/types"
)

var (
	modUser32, _ = syscall.LoadDLL("user32.dll")

	procCallNextHookEx, _      = modUser32.FindProc("CallNextHookEx")
	procSetWindowsHookExW, _   = modUser32.FindProc("SetWindowsHookExW")
	procGetMessageW, _         = modUser32.FindProc("GetMessageW")
	procTranslateMessage, _    = modUser32.FindProc("TranslateMessage")
	procDispatchMessageW, _    = modUser32.FindProc("DispatchMessageW")
	procGetModuleHandleW, _    = modUser32.FindProc("GetModuleHandleW")
	procUnhookWindowsHookEx, _ = modUser32.FindProc("UnhookWindowsHookEx")
	procPeekMessageW, _        = modUser32.FindProc("PeekMessageW")
	procPostMessageW, _        = modUser32.FindProc("PostMessageW")
	procPostQuitMessage, _     = modUser32.FindProc("PostQuitMessage")
	prockeybdEvent, _          = modUser32.FindProc("keybd_event")
)

func CallNextHookEx(hhk uintptr, code int32, wParam, lParam uintptr) uintptr {
	r, _, _ := procCallNextHookEx.Call(hhk, uintptr(code), wParam, lParam)

	return r
}

func SetWindowsHookEx(idHook types.Hook, lpfn, hmod uintptr, dwThreadId uint32) uintptr {
	r, _, _ := procSetWindowsHookExW.Call(uintptr(idHook), lpfn, hmod, uintptr(dwThreadId))

	return r
}

func UnhookWindowsHookEx(hhk uintptr) bool {
	r, _, _ := procUnhookWindowsHookEx.Call(hhk)

	if r == 0 {
		return false
	}

	return true
}

func PeekMessageW(lpMsg **types.MSG, hWnd uintptr, wMsgFilterMin, wMsgFilterMax uint32) int32 {
	r, _, _ := procPeekMessageW.Call(
		uintptr(unsafe.Pointer(lpMsg)),
		hWnd,
		uintptr(wMsgFilterMin),
		uintptr(wMsgFilterMin))

	return int32(r)
}

func GetMessage(lpMsg **types.MSG, hWnd uintptr, wMsgFilterMin, wMsgFilterMax uint32) int32 {
	r, _, _ := procGetMessageW.Call(
		uintptr(unsafe.Pointer(lpMsg)),
		hWnd,
		uintptr(wMsgFilterMin),
		uintptr(wMsgFilterMin))

	return int32(r)
}

func PostMessageW(hWnd uintptr, msg uint32, wParam, lParam uintptr) int32 {
	r, _, _ := procPostMessageW.Call(
		hWnd,
		uintptr(msg),
		wParam,
		lParam,
	)

	return int32(r)
}

func TranslateMessage(lpMsg **types.MSG) int32 {
	r, _, _ := procTranslateMessage.Call(uintptr(unsafe.Pointer(lpMsg)))

	return int32(r)
}

func DispatchMessage(lpMsg **types.MSG) int32 {
	r, _, _ := procDispatchMessageW.Call(uintptr(unsafe.Pointer(lpMsg)))

	return int32(r)
}

func GetModuleHandle(lpModuleName uintptr) uintptr {
	r, _, _ := procSetWindowsHookExW.Call(lpModuleName)

	return r
}

func PostQuitMessage(exitCode int32) {
	procPostQuitMessage.Call(uintptr(exitCode))
}

func KeybdEvent(key, vkey uint8, flag uint64) {
	prockeybdEvent.Call(uintptr(key), uintptr(vkey), uintptr(flag), 0)
}
