package gohook

import (
	"testing"
	"time"

	"monitor/utils/gohook/pkg/keyboard"
	"monitor/utils/gohook/pkg/mouse"
)

// go test   -run TestHook -v
func TestHook(t *testing.T) {
	mouseh := mouse.New()
	mouseh.Install()
	defer mouseh.Uninstall()
	keyboardh := keyboard.New()
	keyboardh.Install()
	defer keyboardh.Uninstall()

	time.Sleep(5 * time.Second)
}
