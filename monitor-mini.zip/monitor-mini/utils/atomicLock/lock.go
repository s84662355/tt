package atomicLock

import (
	"runtime"
	"sync"
	"sync/atomic"
)

// /这个锁只适合 争夺的协程数量不多的场景
type AtomicLock atomic.Bool

const maxForCount = 16

func (s *AtomicLock) Lock() {
	count := 1

	for !(((*atomic.Bool)(s)).CompareAndSwap(false, true)) {
		for i := 0; i < count; i++ {
			runtime.Gosched()
		}
		if count < maxForCount {
			count <<= 1
		}
	}
}

func (s *AtomicLock) Unlock() {
	((*atomic.Bool)(s)).Store(false)
}

func NewSpinLock() sync.Locker {
	return new(AtomicLock)
}
