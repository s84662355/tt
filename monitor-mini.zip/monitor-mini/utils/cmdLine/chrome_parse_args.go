package cmdLine

import (
	"fmt"
	"strings"
)

func ChromeParseArgs(args []string) (Args map[string]string, err error) {
	return chromeParseArgs(args)
}

func chromeParseArgs(args []string) (Args map[string]string, err error) {
	defer func() {
		if er := recover(); er != nil {
			err = fmt.Errorf("chromeParseArgs recover %+v", er)
		}
	}()
	if len(args) == 0 {
		return nil, fmt.Errorf("empty argument array")
	}

	prefix := "-"

	Args = make(map[string]string)
	for len(args) > 0 {
		if strings.HasPrefix(args[0], prefix) {
			args[0] = strings.TrimLeft(args[0], prefix)
			if strings.Index(args[0], "=") > 0 {
				keyValue := strings.SplitN(args[0], "=", 2)
				keyValue[0] = strings.ToLower(keyValue[0])
				if len(keyValue) < 2 {
					if len(args) > 1 {
						args = args[1:]
					} else {
						args = args[:0]
					}
					continue

				}
				Args[keyValue[0]] = keyValue[1]
				if len(args) > 1 {
					args = args[1:]
				} else {
					args = args[:0]
				}
			} else {
				args[0] = strings.ToLower(args[0])
				Args[args[0]] = ""
				if len(args) > 1 {
					if !strings.HasPrefix(args[1], prefix) {
						Args[args[0]] = args[1]
						if len(args) > 2 {
							args = args[2:]
						} else {
							args = args[:0]
						}

					} else {
						args = args[1:]
					}
				} else {
					args = args[1:]
				}
			}
		} else {
			args[0] = strings.ToLower(args[0])
			Args[args[0]] = ""
			if len(args) > 1 {
				args = args[1:]
			} else {
				args = args[:0]
			}

		}
	}

	return
}
