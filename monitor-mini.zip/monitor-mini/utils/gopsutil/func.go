package gopsutil

import (
	"fmt"

	"github.com/shirou/gopsutil/host"
)

// 唯一标识符
func GetSerialNumber() (BaseboardId string, err error) {
	h, err := host.Info()
	if err != nil {
		err = fmt.Errorf("GetSerialNumber err: %w", err)
		return
	}
	BaseboardId = h.HostID
	return
}
