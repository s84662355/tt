package iphlpapi

import (
	"fmt"
	"sync/atomic"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

// GetTCPTable is ...
func GetTCPTable(buf []byte) ([]TCPRow, error) {
	b, err := GetExtendedTcpTable(0, windows.AF_INET, TCP_TABLE_OWNER_PID_CONNECTIONS /* TCP_TABLE_OWNER_PID_CONNECTIONS */, buf)
	if err != nil {
		return nil, err
	}
	t := (*TCPTable)(unsafe.Pointer(&b[0]))
	return unsafe.Slice((*TCPRow)(unsafe.Pointer(&t.Table)), t.Len), nil
}

// TCPTable is ...
type TCPTable struct {
	Len   uint32
	Table [1]TCPRow
}

// TCPRow is ...
type TCPRow struct {
	State      uint32
	LocalAddr  uint32
	LocalPort  uint32
	RemoteAddr uint32
	RemotePort uint32
	OwningPid  uint32
}

func GetTCPTableListener(buf []byte) ([]TCPRow, error) {
	b, err := GetExtendedTcpTable(0, windows.AF_INET, TCP_TABLE_OWNER_PID_LISTENER /* TCP_TABLE_OWNER_PID_LISTENER */, buf)
	if err != nil {
		return nil, err
	}
	t := (*TCPTable)(unsafe.Pointer(&b[0]))
	return unsafe.Slice((*TCPRow)(unsafe.Pointer(&t.Table)), t.Len), nil
}

// GetTCP6Table is ...
func GetTCP6Table(buf []byte) ([]TCP6Row, error) {
	b, err := GetExtendedTcpTable(0, windows.AF_INET6, 4 /* TCP_TABLE_OWNER_PID_CONNECTIONS */, buf)
	if err != nil {
		return nil, err
	}
	t := (*TCP6Table)(unsafe.Pointer(&b[0]))
	return unsafe.Slice((*TCP6Row)(unsafe.Pointer(&t.Table)), t.Len), nil
}

// TCP6Table is ...
type TCP6Table struct {
	Len   uint32
	Table [1]TCP6Row
}

// TCP6Row is ...
type TCP6Row struct {
	LocalAddr     [4]uint32
	LocalScopeId  uint32
	LocalPort     uint32
	RemoteAddr    [4]uint32
	RemoteScopeId uint32
	RemotePort    uint32
	State         uint32
	OwningPid     uint32
}

func GetExtendedTcpTableLen() uint32 {
	var dwSize uint32
	getExtendedTcpTable.Call(
		0,
		uintptr(unsafe.Pointer(&dwSize)),
		uintptr(0),
		uintptr(windows.AF_INET),
		uintptr(TCP_TABLE_OWNER_PID_CONNECTIONS),
		uintptr(uint32(0)),
	)

	return dwSize
}

func GetExtendedTcpTable(
	order uint32,
	ulAf uint32,
	tableClass uint32,
	buf []byte,
) ([]byte, error) {
	pTcpTable := &buf[0]
	dwSize := uint32(len(buf))

	// DWORD GetExtendedTcpTable(
	//  PVOID           pTcpTable,
	//  PDWORD          pdwSize,
	//  BOOL            bOrder,
	//  ULONG           ulAf,
	//  TCP_TABLE_CLASS TableClass,
	//  ULONG           Reserved
	// );
	// https://docs.microsoft.com/en-us/windows/win32/api/iphlpapi/nf-iphlpapi-getextendedtcptable

	r1, _, errno := syscall.Syscall6(
		getExtendedTcpTable.Addr(),
		6,
		uintptr(unsafe.Pointer(pTcpTable)),
		uintptr(unsafe.Pointer(&dwSize)),
		uintptr(order),
		uintptr(ulAf),
		uintptr(tableClass),
		uintptr(uint32(0)),
	)

	if r1 == windows.NO_ERROR {
		return buf, nil
	}

	return nil, errno

	// ret, _, errno := getExtendedTcpTable.Call(
	// 	uintptr(unsafe.Pointer(pTcpTable)),
	// 	uintptr(unsafe.Pointer(&dwSize)),
	// 	uintptr(order),
	// 	uintptr(ulAf),
	// 	uintptr(tableClass),
	// 	uintptr(uint32(0)),
	// )
	// if ret == windows.NO_ERROR {
	// 	return buf, nil
	// }
	// return nil, errno
}

// GetExtendedTcpTable is ...
// func GetExtendedTcpTable(order uint32, ulAf uint32, tableClass uint32, buf []byte) ([]byte, error) {
// 	pTcpTable := &buf[0]
// 	dwSize := uint32(len(buf))

// 	for {
// 		// DWORD GetExtendedTcpTable(
// 		//  PVOID           pTcpTable,
// 		//  PDWORD          pdwSize,
// 		//  BOOL            bOrder,
// 		//  ULONG           ulAf,
// 		//  TCP_TABLE_CLASS TableClass,
// 		//  ULONG           Reserved
// 		// );
// 		// https://docs.microsoft.com/en-us/windows/win32/api/iphlpapi/nf-iphlpapi-getextendedtcptable
// 		ret, _, errno := getExtendedTcpTable.Call(
// 			uintptr(unsafe.Pointer(pTcpTable)),
// 			uintptr(unsafe.Pointer(&dwSize)),
// 			uintptr(order),
// 			uintptr(ulAf),
// 			uintptr(tableClass),
// 			uintptr(uint32(0)),
// 		)
// 		if ret == windows.NO_ERROR {
// 			return buf, nil
// 		}
// 		if windows.Errno(ret) == windows.ERROR_INSUFFICIENT_BUFFER {
// 			buf = make([]byte, dwSize)
// 			pTcpTable = &buf[0]
// 			continue
// 		}
// 		return nil, errno
// 	}
// }

func GetTCPPidByte(
	LocalAddr string,
	LocalPort uint16,
	RemoteAddr string,
	RemotePort uint16,
	tcpTable []byte,
) (uint32, bool) {
	tcpRow, _ := GetTCPTable(tcpTable)
	for _, vvv := range tcpRow {
		if LocalAddr == uint32ToIP(vvv.LocalAddr).String() &&
			LocalPort == ntohs(vvv.LocalPort) &&
			RemoteAddr == uint32ToIP(vvv.RemoteAddr).String() &&
			RemotePort == ntohs(vvv.RemotePort) {
			return vvv.OwningPid, true
		}
	}
	return 0, false
}

func GetTCPPid(
	LocalAddr string,
	LocalPort uint16,
	RemoteAddr string,
	RemotePort uint16,
) (uint32, bool) {
	tcpTable := TCPTableBufPool.Get().([]byte)
	defer TCPTableBufPool.Put(tcpTable)
	tcpRow, _ := GetTCPTable(tcpTable)
	for _, vvv := range tcpRow {
		if LocalAddr == uint32ToIP(vvv.LocalAddr).String() &&
			LocalPort == ntohs(vvv.LocalPort) &&
			RemoteAddr == uint32ToIP(vvv.RemoteAddr).String() &&
			RemotePort == ntohs(vvv.RemotePort) {
			return vvv.OwningPid, true
		}
	}
	return 0, false
}

type GetTCPListenerPidFunc func(listenerIP string, listenerPort uint16) bool

func GetTCPListenerPidByte(tcpTable []byte, fn GetTCPListenerPidFunc) (uint32, bool) {
	tcpRow, _ := GetTCPTableListener(tcpTable)
	for _, vvv := range tcpRow {
		if fn(uint32ToIP(vvv.LocalAddr).String(), ntohs(vvv.LocalPort)) {
			return vvv.OwningPid, true
		}
	}
	return 0, false
}

func GetTCPListenerPid(fn GetTCPListenerPidFunc) (uint32, bool) {
	tcpTable := TCPTableBufPool.Get().([]byte)
	defer TCPTableBufPool.Put(tcpTable)
	tcpRow, _ := GetTCPTableListener(tcpTable)
	for _, vvv := range tcpRow {
		if fn(uint32ToIP(vvv.LocalAddr).String(), ntohs(vvv.LocalPort)) {
			return vvv.OwningPid, true
		}
	}
	return 0, false
}

type listenerInfo struct {
	LocalAddr string
	LocalPort uint16
}

var tcpListener atomic.Pointer[map[string]struct{}]

func CheckTCPListener(k string) bool {
	tt := tcpListener.Load()
	if tt != nil {
		return false
	}

	_, ok := (*tt)[k]

	return ok
}

func UpdateCheckTCPListener() {
	tcpTable := TCPTableBufPool.Get().([]byte)
	defer TCPTableBufPool.Put(tcpTable)
	tcpRow, _ := GetTCPTableListener(tcpTable)
	var ttt map[string]struct{} = map[string]struct{}{}
	for _, vvv := range tcpRow {
		ttt[fmt.Sprint(uint32ToIP(vvv.LocalAddr).String(), ntohs(vvv.LocalPort))] = struct{}{}
	}

	tcpListener.Store(&ttt)
}
