package iphlpapi

import (
	"unsafe"

	"golang.org/x/sys/windows"
)

// GetUDPTable is ...
func GetUDPTable(buf []byte) ([]UDPRow, error) {
	b, err := GetExtendedUdpTable(0, windows.AF_INET, 1 /* UDP_TABLE_OWNER_PID */, buf)
	if err != nil {
		return nil, err
	}
	t := (*UDPTable)(unsafe.Pointer(&b[0]))
	return unsafe.Slice((*UDPRow)(unsafe.Pointer(&t.Table)), t.Len), nil
}

// UDPTable is ...
type UDPTable struct {
	Len   uint32
	Table [1]UDPRow
}

// UDPRow is ...
type UDPRow struct {
	LocalAddr uint32
	LocalPort uint32
	OwningPid uint32
}

// GetUDP6Table is ...
func GetUDP6Table(buf []byte) ([]UDP6Row, error) {
	b, err := GetExtendedUdpTable(0, windows.AF_INET6, 1 /* UDP_TABLE_OWNER_PID */, buf)
	if err != nil {
		return nil, err
	}
	t := (*UDP6Table)(unsafe.Pointer(&b[0]))
	return unsafe.Slice((*UDP6Row)(unsafe.Pointer(&t.Table)), t.Len), nil
}

// UDP6Table is ...
type UDP6Table struct {
	Len   uint32
	Table [1]UDP6Row
}

// UDP6Row is ...
type UDP6Row struct {
	LocalAddr    [4]uint32
	LocalScopeId uint32
	LocalPort    uint32
	OwningPid    uint32
}

// GetExtendedUdpTable is ...
func GetExtendedUdpTable(order uint32, ulAf uint32, tableClass uint32, buf []byte) ([]byte, error) {
	pUdpTable := &buf[0]
	dwSize := uint32(len(buf))

	for {
		// DWORD GetExtendedUdpTable(
		//  PVOID           pUdpTable,
		//  PDWORD          pdwSize,
		//  BOOL            bOrder,
		//  ULONG           ulAf,
		//  UDP_TABLE_CLASS TableClass,
		//  ULONG           Reserved
		// );
		// https://docs.microsoft.com/en-us/windows/win32/api/iphlpapi/nf-iphlpapi-getextendedudptable
		ret, _, errno := getExtendedUdpTable.Call(
			uintptr(unsafe.Pointer(pUdpTable)),
			uintptr(unsafe.Pointer(&dwSize)),
			uintptr(order),
			uintptr(ulAf),
			uintptr(tableClass),
			uintptr(uint32(0)),
		)
		if ret == windows.NO_ERROR {
			return buf, nil
		}
		if windows.Errno(ret) == windows.ERROR_INSUFFICIENT_BUFFER {
			buf = make([]byte, dwSize)
			pUdpTable = &buf[0]
			continue
		}
		return nil, errno
	}
}
