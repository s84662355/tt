package iphlpapi

import (
	"encoding/binary"
	"net"
	"sync"

	"golang.org/x/sys/windows"
)

// /从0开始
const (
	TCP_TABLE_BASIC_LISTENER uint32 = iota
	TCP_TABLE_BASIC_CONNECTIONS
	TCP_TABLE_BASIC_ALL
	TCP_TABLE_OWNER_PID_LISTENER
	TCP_TABLE_OWNER_PID_CONNECTIONS
	TCP_TABLE_OWNER_PID_ALL
	TCP_TABLE_OWNER_MODULE_LISTENER
	TCP_TABLE_OWNER_MODULE_CONNECTIONS
	TCP_TABLE_OWNER_MODULE_ALL
)

const (
	MIB_TCP_STATE_CLOSED     uint32 = iota + 1 // 1 TCP 连接处于 CLOSED 状态，表示根本没有连接状态。
	MIB_TCP_STATE_LISTEN                       // 2 TCP 连接处于 LISTEN 状态，等待来自任何远程 TCP 和端口的连接请求。
	MIB_TCP_STATE_SYN_SENT                     // 3 在发送连接请求后，TCP 连接处于 SYN-SENT 状态，等待匹配的连接请求 (SYN 数据包) 。
	MIB_TCP_STATE_SYN_RCVD                     // 4  在收到并发送连接请求后，TCP 连接处于 SYN-RECEIVED 状态，等待确认连接请求确认 (SYN 数据包) 。
	MIB_TCP_STATE_ESTAB                        // 5 TCP 连接处于已建立状态，表示打开的连接，接收的数据可以传递给用户。 这是 TCP 连接的数据传输阶段的正常状态。
	MIB_TCP_STATE_FIN_WAIT1                    // 6 TCP 连接为 FIN-WAIT-1 状态，等待来自远程 TCP 的连接终止请求或之前发送的连接终止请求的确认。
	MIB_TCP_STATE_FIN_WAIT2                    // 7  TCP 连接为 FIN-WAIT-1 状态，等待来自远程 TCP 的连接终止请求。
	MIB_TCP_STATE_CLOSE_WAIT                   // 8 TCP 连接处于 CLOSE-WAIT 状态，等待来自本地用户的连接终止请求。
	MIB_TCP_STATE_CLOSING                      // 9  TCP 连接处于 CLOSING 状态，等待来自远程 TCP 的连接终止请求确认。
	MIB_TCP_STATE_LAST_ACK                     ///10  TCP 连接处于 LAST-ACK 状态，等待先前发送到远程 TCP (的连接终止请求的确认，其中包括) 的连接终止请求的确认。
	MIB_TCP_STATE_TIME_WAIT                    // 11  TCP 连接处于 TIME-WAIT 状态，等待足够的时间过后，以确保远程 TCP 收到其连接终止请求的确认。
	MIB_TCP_STATE_DELETE_TCB                   // 12 TCP 连接处于删除 TCB 状态，表示删除传输控制块 (TCB) ，该数据结构用于维护每个 TCP 条目的信息。
)

var (
	iphlpapi            = windows.MustLoadDLL("iphlpapi.dll")
	getExtendedTcpTable = iphlpapi.MustFindProc("GetExtendedTcpTable")
	getExtendedUdpTable = iphlpapi.MustFindProc("GetExtendedUdpTable")
	getBestInterfaceEx  = iphlpapi.MustFindProc("GetBestInterfaceEx")
	TCPTableBufPool     = sync.Pool{
		New: func() interface{} {
			return make([]byte, 32<<10)
		},
	}
)

func ntohs(net uint32) uint16 {
	return binary.LittleEndian.Uint16([]byte{byte(net >> 8), byte(net)})
}

func uint32ToIP(ip uint32) net.IP {
	bytes := make([]byte, 4)
	binary.LittleEndian.PutUint32(bytes, ip)
	return net.IP(bytes)
}

func Ntohs(net uint32) uint16 {
	return binary.LittleEndian.Uint16([]byte{byte(net >> 8), byte(net)})
}

func Uint32ToIP(ip uint32) net.IP {
	bytes := make([]byte, 4)
	binary.LittleEndian.PutUint32(bytes, ip)
	return net.IP(bytes)
}
