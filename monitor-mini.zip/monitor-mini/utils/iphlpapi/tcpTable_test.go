package iphlpapi

import (
	"fmt"
	"net/http"
	"testing"
	"time"
)

// go test -bench BenchmarkGetTCPTable    -count=1
func BenchmarkGetTCPTable(t *testing.B) {
	buf := make([]byte, 32<<10)

	for {
		for i := 0; i < 10000000; i++ {
			_, err := GetTCPTable(buf)
			if err != nil {
				t.Error("GetTCPTable err: ", err)
				return
			}
		}

		fmt.Println(1)
		time.Sleep(5 * time.Second)
	}

	// for _, vvv := range infos {
	// 	out := fmt.Sprintf("进程id:%d 本地ip:%s:%d  远端ip:%s:%d   \n", vvv.OwningPid, uint32ToIP(vvv.LocalAddr), ntohs(vvv.LocalPort), uint32ToIP(vvv.RemoteAddr), ntohs(vvv.RemotePort))
	// 	t.Log(out)
	// }
}

// go test -v -run TestGetTCPTableListener  -tags "dev"
func TestGetTCPTableListener(t *testing.T) {
	go func() {
		http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "hello world")
		})
		http.ListenAndServe(":8010", nil)
	}()

	time.Sleep(1 * time.Second)

	buf := make([]byte, 32<<10)
	infos, err := GetTCPTableListener(buf)
	if err != nil {
		t.Error("GetTCPTable err: ", err)
		return
	}

	for _, vvv := range infos {
		out := fmt.Sprintf("进程id:%d 本地ip:%s:%d  远端ip:%s:%d   \n", vvv.OwningPid, uint32ToIP(vvv.LocalAddr), ntohs(vvv.LocalPort), uint32ToIP(vvv.RemoteAddr), ntohs(vvv.RemotePort))
		t.Log(out)
	}
}

// go test -v -run TestGetTCPListeners  -tags "dev"
// func TestGetTCPListeners(t *testing.T) {
// 	go func() {
// 		http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
// 			fmt.Fprintf(w, "hello world")
// 		})
// 		http.ListenAndServe(":8010", nil)
// 	}()

// 	time.Sleep(1 * time.Second)

// 	infos := GetTCPListeners()
// 	for _, vvv := range infos {
// 		t.Log(vvv)
// 	}
// }
