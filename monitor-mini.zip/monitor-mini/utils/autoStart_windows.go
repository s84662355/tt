package utils

import (
	"errors"

	"golang.org/x/sys/windows/registry"
)

func SetAutoStartProgram(name, path string) error {
	key, exists, err := registry.CreateKey(registry.CURRENT_USER, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", registry.ALL_ACCESS)
	if err != nil {
		return err
	}

	defer key.Close()
	if !exists {
		return errors.New("设置注册表失败")
	}

	err = key.SetStringValue(name, `"`+path+`"`)
	if err != nil {
		return err
	}

	return nil
}

func ReadAutoStartProgram(name string) (string, error) {
	key, exists, err := registry.CreateKey(registry.CURRENT_USER, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", registry.ALL_ACCESS)
	if err != nil {
		return "", err
	}

	defer key.Close()
	if !exists {
		return "", errors.New("读取注册表失败")
	}

	v, _, err := key.GetStringValue(name)
	if err != nil {
		return "", err
	}

	return v, nil
}

func DeleteAutoStartProgram(name string) error {
	key, exists, err := registry.CreateKey(registry.CURRENT_USER, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", registry.ALL_ACCESS)
	if err != nil {
		return err
	}

	defer key.Close()
	if !exists {
		return errors.New("删除注册表失败")
	}

	_, _, err = key.GetStringValue(name)
	if err != nil {
		return nil
	}

	err = key.DeleteValue(name)
	if err != nil {
		return err
	}

	return nil
}
