package registry

import (
	"fmt"

	"golang.org/x/sys/windows/registry"
)

func GetRDPPort() (int, error) {
	// 打开注册表键
	key, err := registry.OpenKey(
		registry.LOCAL_MACHINE,
		`SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp`,
		registry.QUERY_VALUE,
	)
	if err != nil {
		return 0, fmt.Errorf("无法打开注册表键: %v", err)
	}
	defer key.Close()

	// 读取 PortNumber 值
	port, _, err := key.GetIntegerValue("PortNumber")
	if err != nil {
		return 0, fmt.Errorf("无法读取端口号: %v", err)
	}

	return int(port), nil
}
