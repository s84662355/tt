package registry

import (
	"fmt"

	"golang.org/x/sys/windows/registry"
)

// WriteRegistry 写入注册表项
func WriteRegistry(key registry.Key, subkey, valueName string, value interface{}, valueType uint32) error {
	k, err := registry.OpenKey(key, subkey, registry.WRITE)
	if err != nil {
		// 若打开失败则尝试创建
		k, _, err = registry.CreateKey(key, subkey, registry.WRITE)
		if err != nil {
			return fmt.Errorf("打开或创建注册表项失败: %v", err)
		}
	}
	defer k.Close()

	// 根据值类型使用不同的设置方法
	switch valueType {
	case registry.SZ, registry.EXPAND_SZ:
		strValue, ok := value.(string)
		if !ok {
			return fmt.Errorf("字符串类型需要string值")
		}
		if valueType == registry.EXPAND_SZ {
			return k.SetStringValue(valueName, strValue)
		}
		return k.SetStringValue(valueName, strValue)

	case registry.DWORD:
		dwordValue, ok := value.(uint32)
		if !ok {
			return fmt.Errorf("DWORD类型需要uint32值")
		}
		return k.SetDWordValue(valueName, dwordValue)

	case registry.QWORD:
		qwordValue, ok := value.(uint64)
		if !ok {
			return fmt.Errorf("QWORD类型需要uint64值")
		}
		return k.SetQWordValue(valueName, qwordValue)

	case registry.BINARY:
		binValue, ok := value.([]byte)
		if !ok {
			return fmt.Errorf("BINARY类型需要[]byte值")
		}
		return k.SetBinaryValue(valueName, binValue)

	case registry.MULTI_SZ:
		multiSzValue, ok := value.([]string)
		if !ok {
			return fmt.Errorf("MULTI_SZ类型需要[]string值")
		}
		return k.SetStringsValue(valueName, multiSzValue)

	default:
		return fmt.Errorf("不支持的注册表值类型: %d", valueType)
	}
}
