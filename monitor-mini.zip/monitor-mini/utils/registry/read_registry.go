package registry

import (
	"fmt"

	"golang.org/x/sys/windows/registry"
)

// ReadRegistry 读取注册表项
func ReadRegistry(key registry.Key, subkey, valueName string) (interface{}, error) {
	k, err := registry.OpenKey(key, subkey, registry.QUERY_VALUE)
	if err != nil {
		return nil, fmt.Errorf("打开注册表项时出错: %v", err)
	}
	defer k.Close()

	val, _, err := k.GetValue(valueName, nil)
	if err != nil {
		return nil, fmt.Errorf("读取注册表值时出错: %v", err)
	}
	return val, nil
}
