package protocol

import (
	"fmt"
)

type MsgId uint32

// 路由
const (
	MsgIdMonitorLogin                      MsgId = iota + 1 // 1监控登录
	MsgIdMonitorHeartbeat                                   // 2监控心跳
	MsgIdMonitorReportMachinePerformance                    // 3上报机器性能信息
	MsgIdMonitorReportAppPerformance                        // 4上报应用性能信息
	MsgIdMonitorAppDisable                                  // 5禁用应用
	MsgIdMonitorAppEnable                                   // 6放行应用
	MsgIdMonitorNotLoginIn                                  // 7未登录
	MsgIdMonitorAppClose                                    // 8关闭应用
	MsgIdMonitorReportMachineBrowserInfo                    // 9上报浏览器访问信息
	MsgIdMonitorWebDisable                                  // 10地址禁止访问
	MsgIdMonitorWebEnable                                   // 11地址允许访问
	MsgIdMonitorFlushBrowserInfo                            // 12刷新浏览器信息
	MsgIdMonitorGetBrowserInfo                              // 13获取浏览器信息
	MsgIdMonitorGetDisableApp                               // 14获取禁用应用
	MsgIdMonitorGetDisableDomain                            // 15获取禁用地址
	MsgIdMonitorReportAppTraffic                            // 16上报应用流量信息
	MsgIdMonitorReportActiveInfo                            // 17上报实例活跃信息
	MsgIdMonitorNetworkOpt                                  // 18实例网络操作；1：断网；2：联网
	MsgIdMonitorGetRelayServerInfo                          // 19 获取中继服务器信息
	MsgIdMonitorPushRelayServerInfo                         // 20 推送中继服务器信息
	MsgIdMonitorRepCsDeskPwdInfo                            // 21 上报csDesk账号密码信息
	MsgIdMonitorGetNetworkOpt                               // 22 获取实例是否断网
	MsgIdMonitorLimitNetSpeed                               // 23 限制实例网络
	MsgIdMonitorGetLimitNetSpeed                            // 24 获取实例网络限速
	MsgIdMonitorRefreshRelayServerInfo                      // 25 更新中继服务器信息
	MsgIdMonitorPushWatermarkInfo                           // 26 推送实例水印设置
	MsgIdMonitorGetWatermarkInfo                            // 27 获取实例水印设置
	MsgIdMonitorGetMonitorProjectInfo                       // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo                      // 29 推送当前坐席版本
	MsgIdMonitorReportDeviceRdpLoginStatus                  // 30上报设备rdp使用状态
	MsgIdMonitorReportDeviceBehaviorInfo                    // 31 上报设备行为截图
	MsgIdMonitorOptCollectBehaviorInfo                      // 32 是否采集设备行为截图 1: 采集；2: 不采集
	MsgIdMonitorGetCollectBehaviorInfo                      // 33 获取是否采集设备行为截图
	MsgIdMonitorPushViewOnlineInfo                          // 34 推送在线观看中继服务器信息
	MsgIdMonitorPushQuitReq                                 // 35 网关推送监控退出
	MsgIdMonitorRdpPushQuitReq                              // 36网关推送监控Rdp退出
	MsgIdMonitorReportAppDuration                           // 上报应用使用时长
	MsgIdMonitorGetScreenRecordOpt                          // 获取是否屏幕录制
	MsgIdMonitorPushScreenRecordOpt                         // 推送是否屏幕录制
)

const monitorMsgtemplate = "[Monitor服务端通讯协议]%s-------%d"

func (m MsgId) String() string {
	v := ""
	switch m {
	case 1:
		v = "MsgIdMonitorLogin,监控登录"
	case 2:
		v = "MsgIdMonitorHeartbeat,监控心跳"
	case 3:
		v = "MsgIdMonitorReportMachinePerformance,上报机器性能信息"
	case 4:
		v = "MsgIdMonitorReportAppPerformance,上报应用性能信息"
	case 5:
		v = "MsgIdMonitorAppDisable,禁用应用"
	case 6:
		v = "MsgIdMonitorAppEnable,放行应用"
	case 7:
		v = "MsgIdMonitorNotLoginIn,未登录"
	case 8:
		v = "MsgIdMonitorAppClose,关闭应用"
	case 9:
		v = "MsgIdMonitorReportMachineBrowserInfo,上报浏览器访问信息"
	case 10:
		v = "MsgIdMonitorWebDisable,地址禁止访问"
	case 11:
		v = "MsgIdMonitorWebEnable,地址允许访问"
	case 12:
		v = "MsgIdMonitorFlushBrowserInfo,刷新浏览器信息"
	case 13:
		v = "MsgIdMonitorGetBrowserInfo,获取浏览器信息"
	case 14:
		v = "MsgIdMonitorGetDisableApp,获取禁用应用"
	case 15:
		v = "MsgIdMonitorGetDisableDomain,获取禁用地址"
	case 16:
		v = "MsgIdMonitorReportAppTraffic,上报应用流量信息"
	case 17:
		v = "MsgIdMonitorReportActiveInfo,上报实例活跃信息"
	case 18:
		v = "MsgIdMonitorNetworkOpt,实例网络操作；1：断网；2：联网"
	case 19:
		v = "MsgIdMonitorGetRelayServerInfo,获取中继服务器信息"
	case 20:
		v = "MsgIdMonitorPushRelayServerInfo,推送中继服务器信息"
	case 21:
		v = "MsgIdMonitorRepCsDeskPwdInfo,上报csDesk账号密码信息"
	case 22:
		v = "MsgIdMonitorGetNetworkOpt,获取实例是否断网"
	case 23:
		v = "MsgIdMonitorLimitNetSpeed,限制实例网络"
	case 24:
		v = "MsgIdMonitorGetLimitNetSpeed,获取实例网络限速"
	case 25:
		v = "MsgIdMonitorRefreshRelayServerInfo,更新中继服务器信息"
	case 26:
		v = "MsgIdMonitorPushWatermarkInfo,推送实例水印设置"
	case 27:
		v = "MsgIdMonitorGetWatermarkInfo,获取实例水印设置"
	case 28:
		v = "MsgIdMonitorGetMonitorProjectInfo,获取当前坐席版本"
	case 29:
		v = "MsgIdMonitorPushMonitorProjectInfo,推送当前坐席版本"
	case 30:
		v = "MsgIdMonitorReportDeviceRdpLoginStatus,上报设备rdp使用状态"
	case 31:
		v = "MsgIdMonitorReportDeviceBehaviorInfo,上报设备行为截图"
	case 32:
		v = "MsgIdMonitorOptCollectBehaviorInfo,是否采集设备行为截图 1: 采集；2: 不采集"
	case 33:
		v = "MsgIdMonitorGetCollectBehaviorInfo,获取是否采集设备行为截图"
	case 34:
		v = "MsgIdMonitorPushViewOnlineInfo,推送在线观看中继服务器信息"
	case 35:
		v = "MsgIdMonitorPushQuitReq,网关推送监控退出"
	case 36:
		v = "MsgIdMonitorRdpPushQuitReq,网关推送监控Rdp退出"
	case 37:
		v = "MsgIdMonitorReportAppDuration,37上报应用使用时长"

	case 38:
		v = "MsgIdMonitorGetScreenRecordOpt,38获取监控公共信息"
	case 39:
		v = "MsgIdMonitorPushScreenRecordOpt,39推送监控公共信息"
	default:
		return fmt.Sprintf("[Monitor服务端通讯协议]未知消息类型-------%d", m)
	}
	return fmt.Sprintf(monitorMsgtemplate, v, m)
}

func GetProtocol() []MsgId {
	return []MsgId{
		MsgIdMonitorLogin,
		MsgIdMonitorHeartbeat,
		MsgIdMonitorReportMachinePerformance,
		MsgIdMonitorReportAppPerformance,
		MsgIdMonitorAppDisable,
		MsgIdMonitorAppEnable,
		MsgIdMonitorNotLoginIn,
		MsgIdMonitorAppClose,
		MsgIdMonitorReportMachineBrowserInfo,
		MsgIdMonitorWebDisable,
		MsgIdMonitorWebEnable,
		MsgIdMonitorFlushBrowserInfo,
		MsgIdMonitorGetBrowserInfo,
		MsgIdMonitorGetDisableApp,
		MsgIdMonitorGetDisableDomain,
		MsgIdMonitorReportAppTraffic,
		MsgIdMonitorReportActiveInfo,
		MsgIdMonitorNetworkOpt,
		MsgIdMonitorGetRelayServerInfo,
		MsgIdMonitorPushRelayServerInfo,
		MsgIdMonitorRepCsDeskPwdInfo,
		MsgIdMonitorGetNetworkOpt,
		MsgIdMonitorLimitNetSpeed,
		MsgIdMonitorGetLimitNetSpeed,
		MsgIdMonitorRefreshRelayServerInfo,
		MsgIdMonitorPushWatermarkInfo,          // 26 推送实例水印设置
		MsgIdMonitorGetWatermarkInfo,           // 27 获取实例水印设置
		MsgIdMonitorGetMonitorProjectInfo,      // 28 获取当前坐席版本
		MsgIdMonitorPushMonitorProjectInfo,     // 29 推送当前坐席版本
		MsgIdMonitorReportDeviceRdpLoginStatus, ///30上报设备rdp使用状态
		MsgIdMonitorReportDeviceBehaviorInfo,   // 31 上报设备行为截图
		MsgIdMonitorOptCollectBehaviorInfo,     // 32 是否采集设备行为截图 1: 采集；2: 不采集
		MsgIdMonitorGetCollectBehaviorInfo,     // 33 获取是否采集设备行为截图
		MsgIdMonitorPushViewOnlineInfo,         // 34 推送在线观看中继服务器信息
		MsgIdMonitorPushQuitReq,                // 35 网关推送监控退出
		MsgIdMonitorRdpPushQuitReq,             // 36 网关推送监控Rdp退出
		MsgIdMonitorReportAppDuration,          // 上报应用使用时长
		MsgIdMonitorGetScreenRecordOpt,         // 获取是否屏幕录制
		MsgIdMonitorPushScreenRecordOpt,        // 推送是否屏幕录制

	}
}
