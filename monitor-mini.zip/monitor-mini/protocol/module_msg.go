package protocol

import (
	"fmt"
)

type ModuleMsgId uint32

// 路由
const (
	ModuleMsgIdReportAppTraffic     ModuleMsgId = iota + 1 // 1进程流量
	ModuleMsgIdRunTProxyRdpClient                          // 2 启动透明代理rdp客户端
	ModuleMsgIdCloseTProxyRdpClient                        // 3 关闭透明代理rdp客户端
	ModuleMsgIdPushRdpClientStatus                         // 4  推送rdp客户端状态
)

var moduleMsgtemplate = "[Module模块数据交互协议]%s-------%d"

func (m ModuleMsgId) String() string {
	v := ""
	switch m {
	case 1:
		v = "ModuleMsgIdReportAppTraffic,进程流量"
	case 2:
		v = "ModuleMsgIdRunTProxyRdpClient,启动透明代理rdp客户端"
	case 3:
		v = "ModuleMsgIdCloseTProxyRdpClient,关闭透明代理rdp客户端"
	case 4:
		v = "ModuleMsgIdPushRdpClientStatus,推送rdp客户端状态"
	default:
		return fmt.Sprintf("[Module模块数据交互协议]未知消息类型-------%d", m)
	}

	return fmt.Sprintf(moduleMsgtemplate, v, m)
}
