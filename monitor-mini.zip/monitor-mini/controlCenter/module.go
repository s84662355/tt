package controlCenter

import (
	"errors"

	"google.golang.org/protobuf/proto"
	"monitor/controlCenter/common"
	"monitor/log"
	. "monitor/protocol"
)

// initModule 初始化控制中心的模块，将消息处理模块和模块消息处理映射进行初始化
func (C *controlCenter) initModule() {
	// 获取所有消息处理模块
	msgHandlerModules := common.GetMsgHandlerModules()
	// 初始化消息处理模块映射，用于存储与服务端通讯的消息处理 API
	C.msgHandlerModule = map[MsgId][]*ModuleMsgApi{}
	// 初始化模块消息处理映射，用于存储模块之间通讯的消息处理 API
	C.moduleMsgHandlerMap = map[ModuleMsgId][]*ModuleMsgApi{}

	// 用于存储每个模块对应的消息处理 API
	apiMap := map[string]*ModuleMsgApi{}
	// 遍历所有消息处理模块
	for name, module := range msgHandlerModules {
		// 为当前模块创建一个新的消息处理 API
		processModuleMsgApi := NewModuleMsgApi(C)
		// 将该 API 存入 apiMap 中
		apiMap[name] = processModuleMsgApi

		// 处理与服务端通讯的 Protobuf 消息
		{
			// 遍历当前模块定义的所有与服务端通讯的消息
			for _, msg := range module.Msgs {
				// 检查消息处理模块映射中是否已经存在该消息的处理 API
				if msgHandlers, ok := C.msgHandlerModule[msg]; !ok {
					// 若不存在，则创建一个新的 API 列表并添加当前 API
					C.msgHandlerModule[msg] = []*ModuleMsgApi{processModuleMsgApi}
				} else {
					// 若存在，则将当前 API 添加到已有的 API 列表中
					C.msgHandlerModule[msg] = append(msgHandlers, processModuleMsgApi)
				}
			}
		}

		// 处理模块之间的通讯消息
		{
			// 遍历当前模块定义的所有模块之间通讯的消息
			for _, msg := range module.ModuleMsgs {
				// 检查模块消息处理映射中是否已经存在该消息的处理 API
				if msgHandlers, ok := C.moduleMsgHandlerMap[msg]; !ok {
					// 若不存在，则创建一个新的 API 列表并添加当前 API
					C.moduleMsgHandlerMap[msg] = []*ModuleMsgApi{processModuleMsgApi}
				} else {
					// 若存在，则将当前 API 添加到已有的 API 列表中
					C.moduleMsgHandlerMap[msg] = append(msgHandlers, processModuleMsgApi)
				}
			}
		}
	}

	// 再次遍历所有消息处理模块，启动每个模块
	for name, module := range msgHandlerModules {
		// 调用 addModule 方法启动模块
		C.addModule(name, module.StartFn, apiMap[name])
	}
}

// addModule 向控制中心添加一个模块，并启动该模块的处理逻辑
func (C *controlCenter) addModule(name string, a common.ModuleStart, mapi *ModuleMsgApi) {
	// 使用错误组启动一个新的 goroutine 来运行模块
	C.wg.Go(func() error {
		// 启动消息处理 API
		mapi.start()
		// 确保在模块处理完成后关闭消息处理 API
		defer mapi.close()
		// 确保在发生 panic 时记录错误信息
		defer log.Recoverf("%s module ", name)

		// 记录模块启动信息
		log.Info(name, " module start")

		// 调用模块的启动函数
		err := a(mapi)
		if err != nil {
			// 若启动函数返回错误，记录错误信息并返回错误
			log.Errorf("%s module stop err = %v", name, err)
			return err
		}
		// 记录模块停止信息
		log.Info(name, " module stop")
		return nil
	})
}

// WriteProtoMessage 向服务端写入 Protobuf 消息，调用 writeMessage 方法完成实际的写入操作
func (C *controlCenter) WriteProtoMessage(route_msgId MsgId, data proto.Message) error {
	// 检查客户端连接状态
	if !C.isznetClientConnection.Load() {
		return errors.New("[客户端连接断开] 发送数据失败 send data lose ,isznetClientConnection false ")
	}
	return C.writeMessage(route_msgId, data)
}

// writeModuleMsgChan 向模块消息通道写入消息，将消息分发给所有处理该消息的模块消息 API
func (C *controlCenter) writeModuleMsgChan(RouteMsgId ModuleMsgId, data interface{}) {
	// 检查模块消息处理映射中是否存在该消息的处理 API
	if moduleMsgApis, ok := C.moduleMsgHandlerMap[RouteMsgId]; ok {
		// 遍历所有处理该消息的 API
		for _, moduleMsgApi := range moduleMsgApis {
			// 向每个 API 的模块消息通道写入消息
			moduleMsgApi.writeModuleMsgChan(&common.ModuleMsg{
				RouteMsgId: RouteMsgId,
				Data:       data,
			})
		}
	}
}
