package controlCenter

import (
	"context"
	"sync"
	"sync/atomic"

	"google.golang.org/protobuf/proto"
	"monitor/controlCenter/common"
	. "monitor/protocol"
	"monitor/utils/Queue"
)

// ModuleMsgApi 结构体用于管理模块消息的处理和分发
type ModuleMsgApi struct {
	// 指向控制中心的指针，用于调用控制中心的方法
	c *controlCenter
	// 上下文，用于控制模块消息处理的生命周期
	ctx context.Context
	// 原子布尔值，标记模块消息处理是否已启动
	isStart atomic.Bool
	// 模块启动函数
	fn common.ModuleStart
	// 用于存储 Protobuf 消息的队列
	nQueue Queue.Queue[*common.ModuleProtoMsg]
	// 用于存储模块间消息的队列
	moduleMsgQueue Queue.Queue[*common.ModuleMsg]
	// 用于发送 Protobuf 消息的通道
	mChan chan *common.ModuleProtoMsg
	// 用于发送模块间消息的通道
	moduleMsgChan chan *common.ModuleMsg
	// 用于取消上下文的函数
	cancal func()
	// 读取消息队列的函数，确保只执行一次
	readMsgQueue func()
}

// NewModuleMsgApi 创建一个新的 ModuleMsgApi 实例
func NewModuleMsgApi(c *controlCenter) *ModuleMsgApi {
	// 创建一个可取消的上下文，继承自控制中心的上下文
	ctx, cancal := context.WithCancel(c.ctx)
	// 创建 ModuleMsgApi 实例
	mm := &ModuleMsgApi{
		c:              c,
		mChan:          make(chan *common.ModuleProtoMsg),
		moduleMsgChan:  make(chan *common.ModuleMsg),
		nQueue:         Queue.NewNQueue[*common.ModuleProtoMsg](),
		moduleMsgQueue: Queue.NewNQueue[*common.ModuleMsg](),
		ctx:            ctx,
		cancal:         cancal,
	}

	// 确保 readMsgQueue 函数只执行一次
	mm.readMsgQueue = sync.OnceFunc(func() {
		// 标记模块消息处理已启动
		mm.isStart.Swap(true)
		// 启动一个 goroutine 处理 Protobuf 消息队列
		go func() {
			// 确保在 goroutine 结束时关闭 mChan 通道
			defer close(mm.mChan)
			// 从队列中出队消息并发送到 mChan 通道
			mm.nQueue.DequeueFunc(func(fff *common.ModuleProtoMsg, isClose bool) bool {
				if isClose {
					return false
				}

				select {
				// 若上下文被取消，停止处理消息
				case <-mm.ctx.Done():
					return false
				// 将消息发送到 mChan 通道
				case mm.mChan <- fff:
				}

				return true
			})
		}()

		// 启动一个 goroutine 处理模块间消息队列
		go func() {
			// 确保在 goroutine 结束时关闭 moduleMsgChan 通道
			defer close(mm.moduleMsgChan)
			// 从队列中出队消息并发送到 moduleMsgChan 通道
			mm.moduleMsgQueue.DequeueFunc(func(fff *common.ModuleMsg, isClose bool) bool {
				if isClose {
					return false
				}

				select {
				// 若上下文被取消，停止处理消息
				case <-mm.ctx.Done():
					return false
				// 将消息发送到 moduleMsgChan 通道
				case mm.moduleMsgChan <- fff:
				}

				return true
			})
		}()
	})

	return mm
}

// WriteProtoMessage 发送 Protobuf 消息，调用控制中心的 WriteProtoMessage 方法
func (m *ModuleMsgApi) WriteProtoMessage(route_msgId MsgId, data proto.Message) error {
	return m.c.WriteProtoMessage(route_msgId, data)
}

// WriteModuleMessage 发送数据给其他模块，调用控制中心的 writeModuleMsgChan 方法
func (m *ModuleMsgApi) WriteModuleMessage(route_msgId ModuleMsgId, data interface{}) {
	m.c.writeModuleMsgChan(route_msgId, data)
}

// GetMsg 获取 Protobuf 消息通道，用于接收 Protobuf 消息
func (m *ModuleMsgApi) GetMsg() <-chan *common.ModuleProtoMsg {
	return m.mChan
}

// GetModuleMsg 获取模块间消息通道，用于接收模块间消息
func (m *ModuleMsgApi) GetModuleMsg() <-chan *common.ModuleMsg {
	return m.moduleMsgChan
}

// writeMsgChan 将 Protobuf 消息写入队列
func (m *ModuleMsgApi) writeMsgChan(msg *common.ModuleProtoMsg) {
	select {
	// 若上下文被取消，不处理消息
	case <-m.ctx.Done():
		return
	default:
		// 将消息入队
		m.nQueue.Enqueue(msg)
	}
}

// writeModuleMsgChan 将模块间消息写入队列
func (m *ModuleMsgApi) writeModuleMsgChan(msg *common.ModuleMsg) {
	select {
	// 若上下文被取消，不处理消息
	case <-m.ctx.Done():
		return
	default:
		// 将消息入队
		m.moduleMsgQueue.Enqueue(msg)
	}
}

// start 启动模块消息处理，调用 readMsgQueue 函数并设置上下文取消后的回调
func (m *ModuleMsgApi) start() {
	// 启动消息队列处理
	m.readMsgQueue()

	// 上下文取消后的回调函数
	context.AfterFunc(m.ctx, sync.OnceFunc(func() {
		// 关闭 Protobuf 消息队列
		m.nQueue.Close()
		// 关闭模块间消息队列
		m.moduleMsgQueue.Close()
		// 标记模块消息处理已停止
		m.isStart.Swap(false)
	}))
}

// close 关闭模块消息处理，取消上下文并消耗通道中的消息
func (m *ModuleMsgApi) close() {
	// 尝试将模块消息处理的启动状态从 true 切换到 false
	if !m.isStart.CompareAndSwap(true, false) {
		return
	}

	// 取消上下文
	m.cancal()
	// 消耗 mChan 通道中的所有消息
	for range m.mChan {
	}
	// 消耗 moduleMsgChan 通道中的所有消息
	for range m.moduleMsgChan {
	}
}

// ExistsMonitorProjectTurnOn 检查指定监控项目是否开启
func (m *ModuleMsgApi) ExistsMonitorProjectTurnOn(id common.StrategyId) bool {
	// 从控制中心获取推送的监控项目信息
	i := m.c.pushMonitorProjectInfo.Load()
	if i != nil && i.IsEnable == 1 && i.MonitorProjectInfo != nil {
		// 检查指定 ID 的监控项目是否开启
		if v, ok := i.MonitorProjectInfo[int64(id)]; ok {
			return v == 1
		}
	}
	return false
}

// GetContext 获取模块消息处理的上下文
func (m *ModuleMsgApi) GetContext() context.Context {
	return m.ctx
}
