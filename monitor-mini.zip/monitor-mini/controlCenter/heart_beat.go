package controlCenter

import (
	"github.com/aceld/zinx/ziface"
	"google.golang.org/protobuf/proto"
	. "monitor/env"
	"monitor/log"
	"monitor/protobuf"
	uIp "monitor/utils/ip"
)

// heartBeatFunc 是 controlCenter 结构体的一个方法，用于生成心跳消息数据
// 该方法接收一个 ziface.IConnection 类型的参数，表示当前的网络连接
// 返回值为生成的心跳消息数据的字节切片，如果出现错误则返回 nil
func (C *controlCenter) heartBeatFunc(conn ziface.IConnection) []byte {
	// 调用 uIp 包中的 GetIpFromCache 函数，从缓存中获取本地公网 IP 地址
	// C.ctx 是上下文信息，用于传递请求范围的数据
	ip, err := uIp.GetIpFromCache(C.ctx)
	// 检查获取 IP 地址时是否出现错误
	if err != nil {
		// 如果出现错误，使用日志包的 Errorf 方法记录错误信息
		log.Errorf("[心跳-获取本地公网ip]   ip err:%s", err)
		// 出现错误则返回 nil
		return nil
	}

	// 调用 uIp 包中的 DefaultNIC 函数，获取默认网络接口卡的信息
	// 该信息包含主机的 MAC 地址和内网 IP 地址
	ipAdapterInfo, err := uIp.DefaultNIC()
	// 检查获取网络接口卡信息时是否出现错误
	if err != nil {
		// 如果出现错误，使用日志包的 Errorf 方法记录错误信息
		log.Errorf("[心跳-获取主机mac地址和内网ip]  ipAdapterInfo err:%s", err)
		// 出现错误则返回 nil
		return nil
	}

	// 创建一个 protobuf.MonitorHeartbeatRequest 类型的消息结构体
	// 并将获取到的 IP 地址、MAC 地址和版本号填充到结构体中
	data, err := proto.Marshal(&protobuf.MonitorHeartbeatRequest{
		MonitoryIp:  ip, // 本地公网 IP 地址
		BaseboardId: MachineID,
		InnerIp:     ipAdapterInfo.IpAddress, // 主机的内网 IP 地址
		Version:     Version,                 // 版本号，从环境包中获取
	})
	// 检查消息序列化时是否出现错误
	if err != nil {
		// 如果出现错误，使用日志包的 Errorf 方法记录错误信息
		log.Errorf("[心跳-网络心跳] heartbeat  proto  Marshal err:%s", err)
		// 出现错误则返回 nil
		return nil
	}

	// 如果没有出现错误，返回序列化后的消息数据字节切片
	return data
}
