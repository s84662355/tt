package controlCenter

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"

	"github.com/aceld/zinx/znet"
	"github.com/robfig/cron/v3"
	"golang.org/x/sync/errgroup"
	"monitor/log"
	"monitor/protobuf"
	. "monitor/protocol"
)

// NewControlCenter 是一个工厂函数，用于创建一个新的 controlCenter 实例
func NewControlCenter() *controlCenter {
	// 创建一个带有错误组的上下文
	wg, ctxt := errgroup.WithContext(context.Background())
	// 创建一个可取消的上下文
	ctxC, cancel := context.WithCancel(ctxt)
	// 创建 controlCenter 实例
	ccc := &controlCenter{
		ctx:    ctxC,
		cancel: cancel,
		wg:     wg,
	}
	// 创建一个新的 zinx 客户端
	client := znet.NewClient("", 0)
	// 将客户端转换为 znet.Client 类型并赋值给 controlCenter 实例
	ccc.znetClient = client.(*znet.Client)
	// 标记 znet 客户端连接状态为未连接
	ccc.isznetClientConnection.Swap(false)
	// 标记控制中心未启动
	ccc.isStart.Swap(false)
	// 初始化消息处理模块映射
	ccc.msgHandlerModule = map[MsgId][]*ModuleMsgApi{}

	// 创建一个用于通知 znet 客户端连接关闭的通道
	ccc.znetClientCone = make(chan struct{})
	return ccc
}

// controlCenter 结构体表示控制中心，负责管理网络连接、定时任务和消息处理等
type controlCenter struct {
	// 嵌入 znet 的基础路由，用于处理网络请求
	znet.BaseRouter
	// 上下文，用于控制请求的生命周期
	ctx context.Context
	// 错误组，用于管理多个 goroutine 的错误
	wg *errgroup.Group
	// zinx 客户端，用于与远程服务器建立连接
	znetClient *znet.Client
	// 原子布尔值，标记 znet 客户端是否已连接
	isznetClientConnection atomic.Bool
	// 原子布尔值，标记 znet 客户端是否曾经有过连接
	isznetClientHaveConnection atomic.Bool
	// 原子布尔值，标记控制中心是否已启动
	isStart atomic.Bool
	// 互斥锁，用于保护 znet 客户端的并发访问
	znetClientMutex sync.Mutex
	// 确保初始化操作只执行一次
	initOnce sync.Once
	// 用于取消上下文的函数
	cancel func()
	// 本地公网 IP 地址
	ip string
	// 序列号，通常为设备的 MAC 地址
	serialNumber string
	// 标记 znet 客户端连接状态的整数
	isZnetClientConnection int32
	// 内网 IP 地址
	innerIp string
	// 消息处理模块映射，根据消息 ID 存储对应的消息处理模块
	msgHandlerModule map[MsgId][]*ModuleMsgApi
	// 用于通知 znet 客户端连接关闭的通道
	znetClientCone chan struct{}
	// 模块消息处理映射，根据模块消息 ID 存储对应的消息处理模块
	moduleMsgHandlerMap map[ModuleMsgId][]*ModuleMsgApi
	// 定时任务管理器
	cronT *cron.Cron
	// 原子指针，指向推送监控项目信息的消息结构体
	pushMonitorProjectInfo atomic.Pointer[protobuf.PushMonitorProjectInfo]
}

// Start 方法用于启动控制中心，初始化网络客户端、定时任务和模块，并在关闭时进行清理操作
func (C *controlCenter) Start() {
	// 确保初始化操作只执行一次
	C.initOnce.Do(func() {
		// 确保在发生 panic 时能记录错误信息
		defer log.Recover()
		// 检查上下文是否已取消
		select {
		case <-C.ctx.Done():
			return
		default:
		}

		// 标记控制中心已启动
		C.isStart.Swap(true)

		// 启动一个 goroutine 初始化 znet 客户端
		d := make(chan struct{})
		go func() {
			defer close(d)
			C.initZnetClient()
		}()

		// 启动定时任务
		C.cronTask()
		// 初始化模块
		C.initModule()
		// 在上下文结束时执行清理操作
		context.AfterFunc(C.ctx, sync.OnceFunc(func() {
			// 等待所有 goroutine 完成并检查是否有错误
			if err := C.wg.Wait(); err != nil {
				// 若有错误，记录并终止程序
				log.Panicf("controlCenter  errgroup.Group err = %+v", err)
			}
			// 记录控制中心开始关闭的信息
			log.Info("controlCenter start close")
			// 标记 znet 客户端连接状态为未连接
			C.isznetClientConnection.Swap(false)
			// 确保在函数结束时关闭 znet 客户端连接关闭的通道
			defer close(C.znetClientCone)
			// 标记控制中心未启动
			C.isStart.Swap(false)
			// 输出程序关闭完成的信息
			fmt.Println("程序关闭完成")
			// 记录控制中心关闭完成的信息
			log.Info("controlCenter finish close")

			// 等待定时任务完全结束
			<-C.cronT.Stop().Done()
		}))
		<-d
	})
}

// Stop 方法用于停止控制中心，关闭 znet 客户端连接并取消上下文
func (C *controlCenter) Stop() {
	// 尝试将控制中心的启动状态从 true 切换到 false
	if !C.isStart.CompareAndSwap(true, false) {
		return
	}
	// 加锁以保护 znet 客户端的并发访问
	C.znetClientMutex.Lock()
	// 检查 znet 客户端连接是否存在且曾经有过连接
	if C.znetClient.Conn() != nil && C.isznetClientHaveConnection.Load() {
		// 停止 znet 客户端连接，可能会阻塞
		C.znetClient.Conn().Stop()
	}
	// 解锁
	C.znetClientMutex.Unlock()
	// 取消上下文
	C.cancel()

	// 消耗 znet 客户端连接关闭的通道中的所有元素
	for range C.znetClientCone {
	}
}
