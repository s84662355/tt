package common

import (
	"context"

	"google.golang.org/protobuf/proto"
	. "monitor/protocol"
)

// StrategyId 定义监控策略的 ID 类型，使用 uint8 类型
type StrategyId uint8

// 定义一系列监控策略的常量，每个常量对应一个唯一的策略 ID
const (
	// 员工活跃监控策略，ID 从 1 开始
	MonitorReportActiveInfoStrategy StrategyId = iota + 1 // 1
	// 设备性能监控策略
	MonitorReportMachinePerformanceStrategy // 2
	// 应用性能监控策略
	MonitorReportAppPerformanceStrategy // 3
	// 流量记录监控策略
	MonitorReportAppTrafficStrategy // 4
	// 网页记录监控策略
	MonitorReportMachineBrowserInfoStrategy // 5
	// 应用策略监控策略
	MonitorAppStrategy // 6
	// 网页策略监控策略
	MonitorWebStrategy // 7
	// 网络策略监控策略
	MonitorNetWorkStrategy // 8
	// 水印策略监控策略
	MonitorWatermarkStrategy // 9
	// 在线观看监控策略
	MonitorScreenOnLive // 10
	// 屏幕截图监控策略
	MonitorScreenshot // 11

)

// ModuleStart 定义模块启动函数的类型，该函数接收一个 ModuleApi 接口作为参数，并返回一个错误
type ModuleStart func(m ModuleApi) error

// ModuleApi 定义模块 API 的接口，包含一系列用于消息处理和监控项目检查的方法
type ModuleApi interface {
	// 发送 Protobuf 消息，参数 route_msgId 是消息 ID，data 是 Protobuf 消息数据
	WriteProtoMessage(route_msgId MsgId, data proto.Message) error
	// 获取 Protobuf 消息通道，用于接收 Protobuf 消息
	GetMsg() <-chan *ModuleProtoMsg
	// 获取模块的上下文，用于控制模块的生命周期
	GetContext() context.Context
	// 获取模块间消息通道，用于接收模块间消息
	GetModuleMsg() <-chan *ModuleMsg
	// 发送模块间消息，参数 route_msgId 是消息 ID，data 是消息数据
	WriteModuleMessage(route_msgId ModuleMsgId, data interface{})
	// 检查指定监控项目是否开启，参数 StrategyId 是监控策略的 ID
	ExistsMonitorProjectTurnOn(StrategyId) bool
}

// ModuleProtoMsg 结构体表示 Protobuf 消息，包含消息数据和消息 ID
type ModuleProtoMsg struct {
	// Protobuf 消息数据
	Data proto.Message
	// 消息 ID
	RouteMsgId MsgId
}

// ModuleMsg 结构体表示模块间消息，包含消息数据和消息 ID
type ModuleMsg struct {
	// 消息数据
	Data interface{}
	// 消息 ID
	RouteMsgId ModuleMsgId
}

// ModuleRegister 结构体用于注册模块，包含模块的启动函数、处理的消息 ID 列表和模块间消息 ID 列表
type ModuleRegister struct {
	// 模块的启动函数
	StartFn ModuleStart
	// 模块处理的消息 ID 列表
	Msgs []MsgId
	// 模块处理的模块间消息 ID 列表
	ModuleMsgs []ModuleMsgId
}
