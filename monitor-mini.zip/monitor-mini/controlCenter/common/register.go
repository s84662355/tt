package common

import (
	"maps"
)

// msgHandlerModules 是一个全局变量，用于存储已注册的模块
// 键为模块名称，值为指向 ModuleRegister 结构体的指针
var msgHandlerModules map[string]*ModuleRegister = map[string]*ModuleRegister{}

// RegisterMsgHandlerModule 用于向全局的 msgHandlerModules 映射中注册一个新的模块
// 参数 name 是模块的名称，用于唯一标识该模块
// 参数 module 是指向 ModuleRegister 结构体的指针，包含了模块的相关信息
func RegisterMsgHandlerModule(name string, module *ModuleRegister) {
	// 将模块添加到 msgHandlerModules 映射中，键为模块名称
	msgHandlerModules[name] = module
}

// GetMsgHandlerModules 用于获取已注册模块的副本
// 该函数返回一个新的映射，包含了 msgHandlerModules 中的所有键值对
// 使用 maps.Clone 函数可以避免外部代码直接修改原始的 msgHandlerModules 映射
func GetMsgHandlerModules() map[string]*ModuleRegister {
	return maps.Clone(msgHandlerModules)
}
