package controlCenter

import (
	"time"

	"github.com/robfig/cron/v3"
	. "monitor/protocol"
)

// cronTask 是 controlCenter 结构体的一个方法，用于创建和启动定时任务
func (C *controlCenter) cronTask() {
	// 创建一个新的 cron 实例，使用 cron.WithSeconds() 选项来支持秒级别的定时任务
	C.cronT = cron.New(cron.WithSeconds())
	// 启动 cron 实例，开始执行定时任务
	C.cronT.Start()

	// 使用 time.AfterFunc 函数，在 5 秒后执行一个匿名函数
	time.AfterFunc(15*time.Second, func() {
		// 调用 controlCenter 结构体的 WriteProtoMessage 方法，发送一个消息
		// MsgIdMonitorGetMonitorProjectInfo 是消息的 ID，nil 表示消息内容为空
		C.WriteProtoMessage(MsgIdMonitorGetMonitorProjectInfo, nil)
	})

	// 使用 cronT.Schedule 方法，安排一个定时任务，每 5 分钟执行一次
	// cron.Every(5*60*time.Second) 表示每 5 分钟执行一次
	// cron.FuncJob 用于将一个函数包装成 cron 任务
	C.cronT.Schedule(cron.Every(5*60*time.Second), cron.FuncJob(func() {
		// 同样调用 controlCenter 结构体的 WriteProtoMessage 方法，发送消息
		C.WriteProtoMessage(MsgIdMonitorGetMonitorProjectInfo, nil)
	}))
}
