package controlCenter

import (
	"context"
	"errors"
	"fmt"
	"os/user"
	"time"

	"github.com/aceld/zinx/ziface"
	"google.golang.org/protobuf/proto"
	"monitor/dao"
	"monitor/env"
	"monitor/log"
	"monitor/protocol"
	. "monitor/protocol"
	uIp "monitor/utils/ip"
	"monitor/utils/registry"
)

// initZnetClient 初始化 znet 客户端，包括启动心跳检测、设置连接回调函数、处理错误通道和启动客户端
func (C *controlCenter) initZnetClient() {
	// 加锁以确保线程安全，避免多个 goroutine 同时修改 znet 客户端
	C.znetClientMutex.Lock()
	// 启动心跳检测，设置心跳间隔为 8 秒
	C.znetClient.StartHeartBeatWithOption(8*time.Second, &ziface.HeartBeatOption{
		// 心跳消息生成函数
		MakeMsg: C.heartBeatFunc,
		// 远程连接不活跃时的回调函数，这里设为 nil
		OnRemoteNotAlive: nil,
		// 心跳消息处理路由
		Router: C,
		// 心跳消息的 ID
		HeartBeatMsgID: uint32(protocol.MsgIdMonitorHeartbeat),
	})

	// 设置连接建立时的回调函数
	C.znetClient.SetOnConnStart(C.doClientConnectedBegin)
	// 设置连接断开时的回调函数
	C.znetClient.SetOnConnStop(C.doClientConnectedLost)
	// 解锁
	C.znetClientMutex.Unlock()

	// 启动一个 goroutine 处理错误通道
	go func(ErrChan chan error) {
		// 确保在发生 panic 时能记录错误信息
		defer log.Recover("znet Client Chan recover err")
		for {
			select {
			case <-C.ctx.Done():
				return
			// 从错误通道接收错误信息
			case err, ok := <-ErrChan:
				if err != nil {
					// 记录错误信息
					log.Error("[连接失败] ErrChan   err: ", err)
				}
				if !ok {
					// 通道关闭，退出循环
					return
				}
			}
			// 标记客户端连接状态为断开
			C.isznetClientConnection.Swap(false)
			// 重启 znet 客户端
			C.restartZnetClient()
		}
	}(C.znetClient.GetErrChan())

	// 初始化 znet 路由
	C.initZnetRoute()
	// 再次设置服务端地址
	C.setServerAddress()
	// 加锁以确保线程安全
	C.znetClientMutex.Lock()
	// 确保在函数结束时解锁
	defer C.znetClientMutex.Unlock()
	// 启动 znet 客户端
	C.znetClient.Start()
}

// doClientConnectedBegin 客户端连接建立时的回调函数，处理登录和获取监控项目信息
func (C *controlCenter) doClientConnectedBegin(conn ziface.IConnection) {
	// 检查是否收到退出信号
	select {
	case <-C.ctx.Done():
		return
	default:
	}
	// 标记客户端有连接
	C.isznetClientHaveConnection.Swap(true)

	// 处理登录消息
	C.HandleLoginMsg()
	// 发送获取监控项目信息的消息
	C.WriteProtoMessage(MsgIdMonitorGetMonitorProjectInfo, nil)
}

// doClientConnectedLost 客户端连接断开时的回调函数，处理重连逻辑
func (C *controlCenter) doClientConnectedLost(conn ziface.IConnection) {
	// 标记客户端连接状态为断开
	C.isznetClientConnection.Swap(false)
	// 记录连接断开的错误信息
	log.Error("[客户端连接断开]   znetClientChan doClientConnectedLost  ")

	// 检查是否收到退出信号
	select {
	case <-C.ctx.Done():
		return
	default:
	}
	// 重启 znet 客户端
	C.restartZnetClient()
}

// restartZnetClient 重启 znet 客户端，在连接断开后进行重连尝试
func (C *controlCenter) restartZnetClient() {
	timeOutCtx, cancel := context.WithTimeout(C.ctx, 10*time.Second)
	defer cancel()
	select {
	case <-timeOutCtx.Done():
	// 检查上下文是否被取消
	case <-C.ctx.Done():
		return
	}

	// 设置服务端地址
	C.setServerAddress()
	// 加锁以确保线程安全
	C.znetClientMutex.Lock()
	// 重启 znet 客户端
	C.znetClient.Restart()
	// 解锁
	C.znetClientMutex.Unlock()
}

// writeMessage 将 protobuf 消息序列化并发送，处理连接检查和序列化错误
func (C *controlCenter) writeMessage(route_msgId protocol.MsgId, data proto.Message) error {
	// 将 protobuf 消息序列化
	marshal, err := proto.Marshal(data)
	if err != nil {
		return err
	}

	// 调用底层的 write 方法发送数据
	return C.write(route_msgId, marshal)
}

// write 发送消息到服务端，处理连接获取和发送错误
func (C *controlCenter) write(route_msgId protocol.MsgId, data []byte) error {
	// 加锁以确保线程安全
	C.znetClientMutex.Lock()
	// 确保在函数结束时解锁
	defer C.znetClientMutex.Unlock()

	// 获取客户端连接
	conn := C.znetClient.Conn()
	if conn == nil {
		return errors.New("[发送数据失败]  send data lose , C.znetClient.Conn() == nil")
	}

	// 发送消息
	err := conn.SendMsg(uint32(route_msgId), data)
	if err != nil {
		// 记录发送错误信息
		log.Errorf("[发送数据失败]  conn  SendMsg  err = %s", err)
	}
	return err
}

// //setServerAddress 设置 znet 客户端的服务端地址，根据 IP 和 MAC 地址获取网关信息
func (C *controlCenter) setServerAddress() {
	// 获取主机的 IP 适配器信息
	ipAdapterInfo, err := uIp.DefaultNIC()
	if err != nil {
		// 记录获取 IP 适配器信息的错误
		log.Error("[获取网关地址-获取主机mac地址和内网ip] setServerAddress serialNumber err:", err)
		return
	}

	// 从缓存中获取外网 IP 地址
	ip, err := uIp.GetIpFromCache(C.ctx)
	if err != nil {
		// 记录获取外网 IP 地址的错误
		log.Error("[获取网关地址-外网ip] setServerAddress serialNumber err:", err)
		return
	}

	currentUser, err := user.Current()
	if err != nil {
		log.Errorf("[设置服务端地址失败] user.Current 获取用户信息出错:%v", err)
		return
	}

	if currentUser == nil {
		log.Error("[设置服务端地址失败] user.Current 获取用户信息出错 currentUser = nil")
		return
	}

	port, err := registry.GetRDPPort()
	if err != nil {
		log.Errorf("[设置服务端地址失败] 获取rdp端口出错:%v", err)
	}

	///fmt.Println("-------------  ", currentUser.Username)
	// 从数据访问对象获取监控网关信息
	///address, port, err := dao.GetMonitorGateway(C.ctx, ip, ipAdapterInfo.MacAddress, ipAdapterInfo.IpAddress)
	_, address, port, err := dao.GetMonitorGateway(C.ctx, ip, fmt.Sprintf("%s-%s", env.CompanyId, env.MachineID), ipAdapterInfo.IpAddress, env.StaffId, currentUser.Username, port)
	if err != nil {
		// 记录获取监控网关信息的错误
		log.Errorf("[设置服务端地址失败] ControlCenter GetMonitorGateway ip:%+v ipAdapterInfo:%+v  err:%s", ip, ipAdapterInfo, err)
		return
	}
	// 加锁以确保线程安全
	C.znetClientMutex.Lock()
	// 设置 znet 客户端的 IP 地址
	C.znetClient.Ip = address
	// 设置 znet 客户端的端口号
	C.znetClient.Port = port
	// 解锁
	C.znetClientMutex.Unlock()
}

// func (C *controlCenter) setServerAddress() {
// 	C.znetClientMutex.Lock()
// 	// 设置 znet 客户端的 IP 地址
// 	C.znetClient.Ip = "172.16.20.30"
// 	// 设置 znet 客户端的端口号
// 	C.znetClient.Port = 9999
// 	// 解锁
// 	C.znetClientMutex.Unlock()
// }
