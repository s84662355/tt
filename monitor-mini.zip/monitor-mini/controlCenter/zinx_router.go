package controlCenter

import (
	"fmt"

	"github.com/aceld/zinx/ziface"
	"golang.org/x/sys/windows/registry"
	"monitor/log"
	. "monitor/protocol"

	"google.golang.org/protobuf/proto"
	"monitor/env"
	"monitor/protobuf"
)

// initZnetRoute 是 controlCenter 结构体的一个方法，用于初始化 znet 客户端的路由规则
func (C *controlCenter) initZnetRoute() {
	// 调用 GetProtocol 函数获取协议列表
	protocols := GetProtocol()

	// 遍历协议列表
	for _, p := range protocols {
		// 排除心跳消息的协议 ID
		if p != MsgIdMonitorHeartbeat {
			// 为 znet 客户端添加路由规则，将协议 ID 对应的请求路由到当前的 controlCenter 实例处理
			C.znetClient.AddRouter(uint32(p), C)
		}
	}

	C.znetClient.AddRouter(43, C)
}

// Handle 是 controlCenter 结构体的一个方法，用于处理接收到的网络请求
func (C *controlCenter) Handle(request ziface.IRequest) {
	// 从请求中获取消息 ID，并将其转换为 MsgId 类型
	msgID := MsgId(request.GetMsgID())

	// 除了心跳消息外，记录接收到的服务端消息的调试信息
	if msgID != MsgIdMonitorHeartbeat {
		log.Debugf("[接收服务端消息推送] recv from server : msgId=%s  request=%+v ", msgID, request)
	}

	// 根据不同的消息 ID 进行不同的处理
	switch msgID {
	case MsgIdMonitorLogin:
		// 处理登录消息，这里暂时为空，可根据需求添加具体逻辑
	case MsgIdMonitorHeartbeat:
		// 处理心跳消息，这里暂时为空，可根据需求添加具体逻辑
	case MsgIdMonitorReportMachinePerformance:
		// 处理上报机器性能消息，调用相应的处理函数
		C.HandlerReportMachinePerformance()
	case MsgIdMonitorReportAppPerformance:
		// 处理上报应用性能消息，调用相应的处理函数
		C.HandlerReportAppPerformance()
	case MsgIdMonitorAppClose:
		// 处理应用关闭消息，调用相应的处理函数，并传入请求对象
		C.HandlerAppClose(request)
	case MsgIdMonitorAppDisable:
		// 处理应用禁用消息，调用相应的处理函数，并传入请求对象
		C.HandleAppDisableMsg(request)
	case MsgIdMonitorAppEnable:
		// 处理应用启用消息，调用相应的处理函数，并传入请求对象
		C.HandleAppEnableMsg(request)
	case MsgIdMonitorNotLoginIn:
		// 处理未登录消息，调用相应的处理函数
		C.HandleLoginMsg()
	case MsgIdMonitorReportMachineBrowserInfo:
		// 处理上报浏览器访问信息消息，向消息通道写入消息
		C.writeMsgChan(MsgIdMonitorReportMachineBrowserInfo, nil)
	case MsgIdMonitorWebDisable:
		// 处理地址禁止访问消息，调用相应的处理函数，并传入请求对象
		C.HandlerWebDisable(request)
	case MsgIdMonitorWebEnable:
		// 处理地址允许访问消息，调用相应的处理函数，并传入请求对象
		C.HandlerWebEnable(request)
	case MsgIdMonitorFlushBrowserInfo:
		// 处理刷新浏览器信息消息，调用相应的处理函数，并传入请求对象
		C.HandlerFlushBrowserInfo(request)
	case MsgIdMonitorNetworkOpt:
		// 处理实例网络操作消息，调用相应的处理函数，并传入请求对象
		C.HandlerNetworkOpt(request)
	case MsgIdMonitorPushRelayServerInfo:
		// 处理推送中继服务器信息消息，调用相应的处理函数，并传入请求对象
		C.HandlerRelayServerInfo(request)
	case MsgIdMonitorLimitNetSpeed:
		// 处理限制实例网络消息，调用相应的处理函数，并传入请求对象
		C.HandlerLimitNetSpeed(request)
	case MsgIdMonitorRefreshRelayServerInfo:
		// 处理更新中继服务器信息消息，调用相应的处理函数，并传入请求对象
		C.HandlerRefreshRelayServerInfo(request)
	case MsgIdMonitorPushWatermarkInfo:
		// 处理推送实例水印设置消息，调用相应的处理函数，并传入请求对象
		C.HandlerMonitorPushWatermarkInfo(request)
	case MsgIdMonitorPushMonitorProjectInfo:
		// 处理推送当前坐席版本消息，调用相应的处理函数，并传入请求对象
		C.HandlerMsgIdMonitorPushMonitorProjectInfo(request)
	case MsgIdMonitorOptCollectBehaviorInfo: /// 32 是否采集设备行为截图 1: 采集；2: 不采集
		C.HandlerMsgIdMonitorOptCollectBehaviorInfo(request)
	case MsgIdMonitorPushViewOnlineInfo: // 34 推送在线观看中继服务器信息
		C.HandlerMsgIdMonitorPushViewOnlineInfo(request)

	case MsgIdMonitorPushQuitReq: // 35 网关推送监控退出
		log.Fatalf("接收到网关推送监控退出")
	case MsgIdMonitorRdpPushQuitReq: // 36 网关推送监控Rdp退出
		C.HandlerMsgIdMonitorRdpPushQuitReq(request)

	// case MsgIdMonitorReportAppDuration: // 37 上报应用使用时长
	//	C.HandlerMsgIdMonitorReportAppDuration(request)

	case MsgIdMonitorPushScreenRecordOpt:
		C.HandlerMsgIdMonitorPushScreenRecordOpt(request)
	case 43:

		clientRequest := &protobuf.PushMonitorOpt{}
		// 反序列化请求数据到消息结构体
		err := proto.Unmarshal(request.GetData(), clientRequest)
		if err != nil {
			// 若反序列化失败，记录错误日志并返回
			log.Errorf("[接收到网关推送监控操作] error:%+v", err)
			return
		}

		log.Infof("[接收到网关推送监控操作] data:%+v", clientRequest)
		// 1:删除设备-禁止上报 2:审批通过-更新非临时登录
		if clientRequest.OptType == 1 {
			if err := setKeyValue(fmt.Sprint(env.Environment, "_StaffId"), "0"); err == nil {
				env.StaffId = 0
			} else {
				log.Errorf("[接收到网关推送监控操作] error:%+v", err)
			}
		} else if clientRequest.OptType == 2 {
			if err := setKeyValue(fmt.Sprint(env.Environment, "_isTemporaryLogin"), "0"); err == nil {
				env.IsTemporaryLogin = 0
			} else {
				log.Errorf("[接收到网关推送监控操作] error:%+v", err)
			}
		}

		// 加锁以保护 znet 客户端的并发访问
		C.znetClientMutex.Lock()
		// 检查 znet 客户端连接是否存在且曾经有过连接
		if C.znetClient.Conn() != nil {
			// 停止 znet 客户端连接，可能会阻塞
			C.znetClient.Conn().Stop()
		}
		// 解锁
		C.znetClientMutex.Unlock()

	default:
		// 如果消息 ID 不在上述范围内，直接返回，不做处理
		return
	}
}

func setKeyValue(Key string, valueData string) error {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			// 如果键不存在，则创建它
			key, _, err = registry.CreateKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
			if err != nil {
				return err
			}
			defer key.Close()
			return err
		}
	}
	defer key.Close()

	if err := key.SetStringValue(valueName, valueData); err != nil {
		return err
	}
	return nil
}
