package controlCenter

import (
	"fmt"

	"github.com/aceld/zinx/ziface"
	"google.golang.org/protobuf/proto"
	"monitor/controlCenter/common"
	. "monitor/env"
	"monitor/log"
	"monitor/protobuf"
	. "monitor/protocol"
	uIp "monitor/utils/ip"
)

// HandleLoginMsg 处理登录消息
// 该函数会获取本地公网 IP、主机 MAC 地址和内外网 IP，然后发送登录请求
func (C *controlCenter) HandleLoginMsg() {
	// 从缓存中获取本地公网 IP
	ip, err := uIp.GetIpFromCache(C.ctx)
	if err != nil {
		// 若获取失败，记录错误日志并返回
		log.Error("[登陆-获取本地公网ip]   ip err:", err)

		// 加锁以保护 znet 客户端的并发访问
		C.znetClientMutex.Lock()
		// 检查 znet 客户端连接是否存在且曾经有过连接
		if C.znetClient.Conn() != nil {
			// 停止 znet 客户端连接，可能会阻塞
			C.znetClient.Conn().Stop()
		}
		// 解锁
		C.znetClientMutex.Unlock()

		return
	}

	// 获取主机的 MAC 地址和内外网 IP
	ipAdapterInfo, err := uIp.DefaultNIC()
	if err != nil {
		// 若获取失败，记录错误日志并返回
		log.Error("[登陆-获取主机mac地址和内外网ip]  ipAdapterInfo err:", err)
		// 加锁以保护 znet 客户端的并发访问
		C.znetClientMutex.Lock()
		// 检查 znet 客户端连接是否存在且曾经有过连接
		if C.znetClient.Conn() != nil {
			// 停止 znet 客户端连接，可能会阻塞
			C.znetClient.Conn().Stop()
		}
		// 解锁
		C.znetClientMutex.Unlock()
		return
	}
	// 构造登录请求消息并发送
	err = C.writeMessage(MsgIdMonitorLogin, &protobuf.MonitorLoginRequest{
		MonitoryIp:  ip,
		BaseboardId: fmt.Sprintf("%s-%s", CompanyId, MachineID),
		InnerIp:     ipAdapterInfo.IpAddress,
		Version:     Version,
	})
	if err != nil {
		// 若发送失败，记录错误日志
		log.Errorf("[登录] HandleLoginMsg writeMessage ip:%s BaseboardId:%s err:%s", ip, fmt.Sprintf("%s-%s", CompanyId, MachineID), err)
		return
	}
	log.Infof("[登录] 发送登录信息成功 %+v", &protobuf.MonitorLoginRequest{
		MonitoryIp:  ip,
		BaseboardId: fmt.Sprintf("%s-%s", CompanyId, MachineID),
		InnerIp:     ipAdapterInfo.IpAddress,
		Version:     Version,
	})
	// 标记客户端连接状态为已连接
	C.isznetClientConnection.Swap(true)
}

// HandleAppDisableMsg 处理禁用应用列表消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandleAppDisableMsg(request ziface.IRequest) {
	// 定义一个禁用应用请求的消息结构体
	clientRequest := &protobuf.DisableAppRequest{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[解析禁用应用列表数据] router Unmarshal MsgIdMonitorAppDisable err = %s", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[解析禁用应用列表数据] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorAppDisable, clientRequest)
}

// HandleAppEnableMsg 处理设置应用白名单消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandleAppEnableMsg(request ziface.IRequest) {
	// 定义一个启用应用请求的消息结构体
	clientRequest := &protobuf.EnableAppRequest{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[解析设置应用白名单数据] router Unmarshal MsgIdMonitorAppEnable err = %s", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[解析设置应用白名单数据] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorAppEnable, clientRequest)
}

// HandlerAppClose 处理关闭指定应用消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerAppClose(request ziface.IRequest) {
	// 定义一个关闭应用请求的消息结构体
	clientRequest := &protobuf.CloseAppRequest{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[解析关闭指定应用数据] router Unmarshal MsgIdMonitorAppClose err = %s", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[解析关闭指定应用数据] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorAppClose, clientRequest)
}

// HandlerWebDisable 处理禁用域名消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerWebDisable(request ziface.IRequest) {
	// 定义一个禁用域名请求的消息结构体
	clientRequest := &protobuf.DisableWebRequest{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[禁用域名] router Unmarshal MsgIdMonitorWebDisable err ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[禁用域名] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorWebDisable, clientRequest)
}

// HandlerWebEnable 处理开放域名消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerWebEnable(request ziface.IRequest) {
	// 定义一个开放域名请求的消息结构体
	clientRequest := &protobuf.EnableWebRequest{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[开放域名] router Unmarshal MsgIdMonitorWebEnable err ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[开放域名] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorWebEnable, clientRequest)
}

// HandlerFlushBrowserInfo 处理刷新采集浏览器名单消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerFlushBrowserInfo(request ziface.IRequest) {
	// 定义一个监控浏览器信息的消息结构体
	clientRequest := &protobuf.MonitorBrowserInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[刷新采集浏览器名单] router Unmarshal MsgIdMonitorFlushBrowserInfo err ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[刷新采集浏览器名单] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorFlushBrowserInfo, clientRequest)
}

// HandlerNetworkOpt 处理断网消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerNetworkOpt(request ziface.IRequest) {
	// 定义一个监控网络操作的消息结构体
	clientRequest := &protobuf.MonitorNetworkOpt{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Error("[断网] router Unmarshal MsgIdMonitorNetworkOpt err ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[断网] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorNetworkOpt, clientRequest)
}

// HandlerRelayServerInfo 处理中继服务器信息消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerRelayServerInfo(request ziface.IRequest) {
	// 定义一个推送坐席中继服务器信息的消息结构体
	clientRequest := &protobuf.PushCsDeskRelayServerInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[中继服务器信息] router Unmarshal MsgIdMonitorPushRelayServerInfo err = %+v ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[中继服务器信息] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorPushRelayServerInfo, clientRequest)
}

// HandlerLimitNetSpeed 处理限制实例网络消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerLimitNetSpeed(request ziface.IRequest) {
	// 定义一个限制网络速度的消息结构体
	clientRequest := &protobuf.LimitNetSpeed{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[限制实例网络] router Unmarshal MsgIdMonitorLimitNetSpeed err = %+v ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[限制实例网络] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorLimitNetSpeed, clientRequest)
}

// HandlerRefreshRelayServerInfo 处理更新中继服务器信息消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerRefreshRelayServerInfo(request ziface.IRequest) {
	// 定义一个刷新坐席中继服务器信息的消息结构体
	clientRequest := &protobuf.RefreshCsDeskRelayServerInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[更新中继服务器信息] router Unmarshal MsgIdMonitorRefreshRelayServerInfo err = %+v ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[更新中继服务器信息] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorRefreshRelayServerInfo, clientRequest)
}

// HandlerMonitorPushWatermarkInfo 处理水印配置信息消息
// 该函数会解析请求数据，若解析成功则记录信息并将消息发送到消息通道
func (C *controlCenter) HandlerMonitorPushWatermarkInfo(request ziface.IRequest) {
	// 记录请求信息
	log.Infof("[水印配置信息] Data = %+v", request)
	// 定义一个设备水印信息的消息结构体
	clientRequest := &protobuf.DeviceWatermarkInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[水印配置信息] router Unmarshal MsgIdMonitorPushWatermarkInfo err = %+v ", err)
		return
	}
	// 记录解析成功的信息
	log.Infof("[水印配置信息] Data = %+v", clientRequest)
	// 将消息发送到消息通道
	C.writeMsgChan(MsgIdMonitorPushWatermarkInfo, clientRequest)
}

// HandlerMsgIdMonitorPushMonitorProjectInfo 处理推送当前坐席版本消息
// 该函数会解析请求数据，若解析成功则将数据存储起来
func (C *controlCenter) HandlerMsgIdMonitorPushMonitorProjectInfo(request ziface.IRequest) {
	// 记录请求信息
	log.Infof("[推送当前坐席版本] Data = %+v", request)
	// 定义一个推送监控项目信息的消息结构体
	clientRequest := &protobuf.PushMonitorProjectInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[推送当前坐席版本] router Unmarshal MsgIdMonitorPushMonitorProjectInfo err = %+v ", err)
		return
	}
	log.Infof("[推送当前坐席版本] Data = %+v", clientRequest)
	// 将解析后的数据存储起来
	C.pushMonitorProjectInfo.Store(clientRequest)
}

func (C *controlCenter) HandlerMsgIdMonitorOptCollectBehaviorInfo(request ziface.IRequest) {
	// 记录请求信息
	log.Infof("[获取是否采集设备行为截图] Data = %+v", request)
	// 定义一个推送监控项目信息的消息结构体
	clientRequest := &protobuf.MonitorBehaviorOpt{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[获取是否采集设备行为截图] router Unmarshal MsgIdMonitorOptCollectBehaviorInfo err = %+v ", err)
		return
	}
	log.Infof("[获取是否采集设备行为截图] Data = %+v", clientRequest)
	// 将解析后的数据存储起来
	C.writeMsgChan(MsgIdMonitorOptCollectBehaviorInfo, clientRequest)
}

func (C *controlCenter) HandlerMsgIdMonitorPushViewOnlineInfo(request ziface.IRequest) {
	clientRequest := &protobuf.MonitorViewOnlineInfo{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[推送在线观看中继服务器信息] router Unmarshal MsgIdMonitorPushViewOnlineInfo err = %+v ", err)
		return
	}
	log.Infof("[推送在线观看中继服务器信息] Data = %+v", clientRequest)
	// 将解析后的数据存储起来
	C.writeMsgChan(MsgIdMonitorPushViewOnlineInfo, clientRequest)
}

func (C *controlCenter) HandlerMsgIdMonitorPushScreenRecordOpt(request ziface.IRequest) {
	clientRequest := &protobuf.ScreenRecordOpt{}
	// 反序列化请求数据到消息结构体
	err := proto.Unmarshal(request.GetData(), clientRequest)
	if err != nil {
		// 若反序列化失败，记录错误日志并返回
		log.Errorf("[推送在录制权限] router Unmarshal MsgIdMonitorPushScreenRecordOpt err = %+v ", err)
		return
	}
	log.Infof("[推送在录制权限] Data = %+v", clientRequest)
	// 将解析后的数据存储起来
	C.writeMsgChan(MsgIdMonitorPushScreenRecordOpt, clientRequest)
}

func (C *controlCenter) HandlerMsgIdMonitorRdpPushQuitReq(request ziface.IRequest) {
	log.Infof("[网关推送监控Rdp退出] Data = %+v", request)
	C.writeMsgChan(MsgIdMonitorRdpPushQuitReq, nil)
}

// func (C *controlCenter) HandlerMsgIdMonitorReportAppDuration(request ziface.IRequest) {
// 	log.Infof("[上报应用使用时长] Data = %+v", request)
// 	C.writeMsgChan(MsgIdMonitorReportAppDuration, nil)
// }

// HandlerReportAppPerformance 处理上报应用性能消息
// 该函数会将消息发送到消息通道
func (C *controlCenter) HandlerReportAppPerformance() {
	C.writeMsgChan(MsgIdMonitorReportAppPerformance, nil)
}

// HandlerReportMachinePerformance 处理上报机器性能消息
// 该函数会将消息发送到消息通道
func (C *controlCenter) HandlerReportMachinePerformance() {
	C.writeMsgChan(MsgIdMonitorReportMachinePerformance, nil)
}

// writeMsgChan 将消息写入消息通道
// 该函数会根据消息 ID 查找对应的消息处理模块，并将消息发送到这些模块的消息通道
func (C *controlCenter) writeMsgChan(RouteMsgId MsgId, clientRequest proto.Message) {
	// 检查消息处理模块中是否存在该消息 ID 对应的处理模块
	if moduleMsgApis, ok := C.msgHandlerModule[RouteMsgId]; ok {
		// 遍历所有处理模块
		for _, moduleMsgApi := range moduleMsgApis {
			// 构造一个模块 protobuf 消息结构体
			moduleMsgApi.writeMsgChan(&common.ModuleProtoMsg{
				RouteMsgId: RouteMsgId,
				Data:       clientRequest,
			})
		}
	}
}
