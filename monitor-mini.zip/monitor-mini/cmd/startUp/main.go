package main

import (
	"bufio"
	"context"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"golang.org/x/sys/windows"
	"monitor/api"
	. "monitor/env"
	"monitor/log"
	"monitor/utils/bigfiledownloader"
	"monitor/utils/windowsMutex"
	"monitor/utils/zip"

	_ "net/http/pprof"
)

func gohttp(ln net.Listener) {
	runtime.SetMutexProfileFraction(10) // 开启对锁调用的跟踪
	runtime.SetBlockProfileRate(10)     // 开启对阻塞操作的跟踪
	go func() {
		defer log.Recover("http")

		go func() {
			for {
				log.Info("端口:", ln.Addr().(*net.TCPAddr).Port)

				select {
				case <-time.After(time.Hour):
				}
			}
		}()

		http.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
			var memStats runtime.MemStats
			runtime.ReadMemStats(&memStats)

			result := fmt.Sprint("当前程序版本:", Version, "\n")
			result += fmt.Sprint("NumGoroutine:", runtime.NumGoroutine(), " 当前协程数\n")                          ///当前协程数
			result += fmt.Sprint("memStats.Alloc:", memStats.Alloc, "  目前由 Go 程序分配的字节数，不包括由垃圾回收器管理的内存。\n")     // 目前由 Go 程序分配的字节数，不包括由垃圾回收器管理的内存。
			result += fmt.Sprint("memStats.TotalAlloc:", memStats.TotalAlloc, " 自程序启动以来分配的总字节数，包括已经释放的内存。\n")  // 自程序启动以来分配的总字节数，包括已经释放的内存。
			result += fmt.Sprint("memStats.Sys:", memStats.Sys, " 总共从操作系统获得的内存字节数，包括已经被释放回系统的内存\n")            // 总共从操作系统获得的内存字节数，包括已经被释放回系统的内存。
			result += fmt.Sprint("memStats.Mallocs:", memStats.Mallocs, " 总共进行的内存分配次数。\n")                     // 总共进行的内存分配次数。
			result += fmt.Sprint("memStats.Frees:", memStats.Frees, " 总共进行的内存释放次数。\n")                         // 总共进行的内存释放次数。
			result += fmt.Sprint("memStats.HeapAlloc:", memStats.HeapAlloc, " 目前在堆上分配的字节数。\n")                 // 目前在堆上分配的字节数。
			result += fmt.Sprint("memStats.HeapSys:", memStats.HeapSys, " 总共从操作系统获得的堆内存字节数。\n")                // 总共从操作系统获得的堆内存字节数。
			result += fmt.Sprint("memStats.HeapIdle:", memStats.HeapIdle, " 目前未被使用，但已从系统保留的堆内存字节数。\n")         // 目前未被使用，但已从系统保留的堆内存字节数。
			result += fmt.Sprint("memStats.HeapInuse:", memStats.HeapInuse, " 目前在堆上使用的内存字节数。\n")               // 目前在堆上使用的内存字节数。
			result += fmt.Sprint("memStats.HeapReleased:", memStats.HeapReleased, " 已经返回给操作系统的堆内存字节数。\n")      // 已经返回给操作系统的堆内存字节数。
			result += fmt.Sprint("memStats.HeapObjects:", memStats.HeapObjects, " 目前在堆上的对象数。\n")               // 目前在堆上的对象数。
			result += fmt.Sprint("memStats.StackInuse:", memStats.StackInuse, " 目前在栈上使用的内存字节数。\n")             // 目前在栈上使用的内存字节数。
			result += fmt.Sprint("memStats.StackSys:", memStats.StackSys, " 为栈操作从操作系统获得的内存字节数。\n")             // 为栈操作从操作系统获得的内存字节数。
			result += fmt.Sprint("memStats.MSpanInuse:", memStats.MSpanInuse, " 目前在 MSpan 结构体上使用的内存字节数。\n")    ///目前在 MSpan 结构体上使用的内存字节数。
			result += fmt.Sprint("memStats.MSpanSys:", memStats.MSpanSys, " 为 MSpan 结构体从操作系统获得的内存字节数。\n")      // 为 MSpan 结构体从操作系统获得的内存字节数。
			result += fmt.Sprint("memStats.MCacheInuse:", memStats.MCacheInuse, " 目前在 MCache 结构体上使用的内存字节数。\n") ///目前在 MCache 结构体上使用的内存字节数。
			result += fmt.Sprint("memStats.MCacheSys:", memStats.MCacheSys, " 	为 MCache 结构体从操作系统获得的内存字节数。\n")  // MCacheSys: 为 MCache 结构体从操作系统获得的内存字节数。
			result += fmt.Sprint("memStats.BuckHashSys:", memStats.BuckHashSys, " 为桶哈希表从操作系统获得的内存字节数。\n")      ///BuckHashSys: 为桶哈希表从操作系统获得的内存字节数。
			result += fmt.Sprint("memStats.GCSys:", memStats.GCSys, " 为垃圾回收器从操作系统获得的内存字节数。\n")                 /// 为垃圾回收器从操作系统获得的内存字节数。
			result += fmt.Sprint("memStats.OtherSys:", memStats.OtherSys, " 为其他内存管理用途从操作系统获得的内存字节数。\n")        ///  为其他内存管理用途从操作系统获得的内存字节数。

			fmt.Fprintf(w, result)
		})

		panic(http.Serve(ln, nil))
	}()
}

func init() {
	AppBaseDir, _ := os.Executable()

	AppBaseDir = filepath.Dir(AppBaseDir)

	log.Init(fmt.Sprint(AppBaseDir, "/startUplog"))
}

func main() {
	ln, err := net.Listen("tcp", ":0")
	if err != nil {
		panic(err)
	}

	go gohttp(ln)

	AppBaseDir, err := os.Executable()
	if err != nil {
		return
	}

	superCtx := context.Background()
	AppBaseDir = filepath.Dir(AppBaseDir)

	//###############不会重复打开应用
	startUpName := Environment + "-start-up-" + AppName
	mutex, err := windowsMutex.WindowsMutex(startUpName)
	if err != nil {
		log.Error(startUpName+" WindowsMutex  mutex error: %s", err)
		return
	}
	defer func() {
		windows.ReleaseMutex(windows.Handle(mutex))
		windows.CloseHandle(windows.Handle(mutex))
	}()
	event, err := windows.WaitForSingleObject(mutex, windows.INFINITE)
	if err != nil {
		log.Error(startUpName+" wait for mutex error: %s", err)
		return
	}

	switch event {
	case windows.WAIT_OBJECT_0, windows.WAIT_ABANDONED:
	default:
		log.Error(startUpName+" wait for mutex event id error: %v", event)
		return
	}
	//########################

	ProgramName := AppName
	filePath := fmt.Sprint(AppBaseDir, "/", ProgramName)

	for {
		func() {
			monitorVersionResp, err := api.GetCsMonitorVersion()
			if err != nil {
				log.Errorf("[start up 脚本] 获取版本 err: %s", err)
				return
			}

			//////////////// 当程序不存在的时候，去下载
			if _, err := ifIsNotExistGotoDown(
				AppBaseDir,
				filePath,
				Program,
				monitorVersionResp.
					DownloadLink,
			); err != nil {
				log.Errorf("[start up 脚本]  err: %s", err)
				return
			}
			////////////////////

			ctx, cancal := context.WithCancel(superCtx)
			defer cancal()

			versionNow := ""
			timeout := time.Second * 60
			ticker := time.NewTicker(timeout)
			defer ticker.Stop()

			errChan, verChan := runProgram(ctx, filePath, ln.Addr().(*net.TCPAddr).Port)
			for {
				select {
				case <-ctx.Done():
					return
				case <-ticker.C: // 每分钟检测一下版本

					monitorVersionResp, err := api.GetCsMonitorVersion()
					if err != nil {

						log.Errorf("[start up 脚本] time After 获取版本 err: %s", err)
						ticker.Reset(timeout)
						break
					}

					if versionNow == monitorVersionResp.Version {
						ticker.Reset(timeout)
						break
					}

					programZip := AppBaseDir + "/" + Program + ".zip"
					if err := getAndReplaceProgram(
						AppBaseDir,
						monitorVersionResp.DownloadLink,
						programZip,
						filePath,
						cancal,
					); err != nil {
						log.Errorf("[start up 脚本] time After  err:=%s", err)
						ticker.Reset(timeout)
						break
					}
					return

				case err, ok := <-errChan: // 程序出错后重启
					cancal()
					if ok {
						log.Errorf("[start up 脚本]  程序出错 err:%s", err)
					}

					return
				case version, ok := <-verChan: ///获取运行程序的版本
					if ok {
						versionNow = version
						log.Infof("[start up 脚本] 程序版本为 : %s", version)
						fmt.Println(version)
						if version != monitorVersionResp.Version {
							log.Infof("[start up 脚本] 版本不对称 当成版本是%s 最新版本是%s", version, monitorVersionResp.Version)
							programZip := AppBaseDir + "/" + Program + ".zip"
							if err := getAndReplaceProgram(
								AppBaseDir,
								monitorVersionResp.DownloadLink,
								programZip,
								filePath,
								cancal,
							); err != nil {
								log.Errorf("[start up 脚本] 版本不对称 err:=%s", err)
								break
							}
							return
						}
					} else {
						return
					}

				}
			}
		}()

		time.Sleep(3 * time.Second)

	}
}

func checkFileExist(path string) (bool, error) {
	_, err := os.Stat(path)

	if err == nil {
		return true, nil
	}

	if os.IsNotExist(err) {
		return false, nil
	}

	return false, err
}

// /启动程序
// /启动程序
func runProgram(
	ctx context.Context,
	filePath string,
	port int,
) (<-chan error, <-chan string) {
	errChan := make(chan error, 1)
	verChan := make(chan string, 1)
	echo := exec.CommandContext(
		ctx,
		filePath,
		fmt.Sprint("--port=", port),
		fmt.Sprint("--pid=", fmt.Sprint(os.Getpid())),
	)

	pipe, err := echo.StdoutPipe() // 获取命令执行后的 pipe
	if err != nil {
		defer close(errChan)
		defer close(verChan)
		errChan <- fmt.Errorf("runProgram %s   err: %w", echo, err)
		return errChan, verChan
	}

	if err := echo.Start(); err != nil {
		defer close(errChan)
		defer close(verChan)
		errChan <- fmt.Errorf("runProgram %s   err: %w", echo, err)
		return errChan, verChan
	}

	go func() {
		defer close(errChan)
		err := echo.Wait()
		if err != nil {
			errChan <- fmt.Errorf("runProgram %s   err: %w", echo, err)
		}
	}()

	go func() {
		defer close(verChan)
		scanner := bufio.NewScanner(pipe)
		for scanner.Scan() { // 命令在执行的过程中, 实时地获取其输出
			data := string(scanner.Bytes()) // 防止乱码
			if !strings.Contains(data, "#####################") {
				continue
			}

			data = strings.Replace(data, "#", "", -1)
			Version := data

			select {
			case <-ctx.Done():
				return
			case verChan <- Version:

			}

		}
	}()

	return errChan, verChan
}

func downloadProgram(
	updateUrl string,
	updatePackage string,
) error {
	return bigfiledownloader.NewBigDownloader(
		3,
		func(c float64) {},
	).Download(
		context.Background(),
		updateUrl,
		updatePackage,
	)
}

func getAndReplaceProgram(
	AppBaseDir string,
	updateUrl string,
	programZip string,
	filePath string,
	cancal func(),
) error {
	os.Remove(programZip)
	if err := downloadProgram(updateUrl, programZip); err != nil {
		return fmt.Errorf("getAndReplaceProgram err:%w", err)
	}

	if cancal != nil {
		cancal()
		time.Sleep(5 * time.Second)
	}

	os.Remove(filePath)

	if err := zip.UnZip(AppBaseDir, programZip); err != nil {
		return fmt.Errorf("getAndReplaceProgram 解压更新包失败 err:%w", err)
	}
	return nil
}

func ifIsNotExistGotoDown(
	AppBaseDir string,
	filePath string,
	Program string,
	DownloadLink string,
) (bool, error) {
	programIsOk := true
	if ok, err := checkFileExist(filePath); err != nil {
		programIsOk = false
	} else {
		if !ok {
			programIsOk = false
		}
	}

	if !programIsOk {
		programZip := AppBaseDir + "/" + Program + ".zip"
		if err := getAndReplaceProgram(AppBaseDir, DownloadLink, programZip, filePath, nil); err != nil {
			return programIsOk, fmt.Errorf("ifIsNotExistGotoDown err:%w", err)
		}
	}

	return programIsOk, nil
}
