//go:build dev

package env

const (
	Host        = "https://front-react-007ipvps-safecloud.yeh.lu" ///测试用的
	Environment = "dev"
	AppName     = Program + ".exe"
)
