package env

var (
	ParentPid uint32 = 0
	BaseDir   string = ""
)

const (
	Program = "CSmonitor"
)

var (
	Version                 = ""
	CompanyId               = "" ///企业代码
	MachineID               = "" //
	StaffId          uint64 = 0
	IsTemporaryLogin uint8  = 0
)
