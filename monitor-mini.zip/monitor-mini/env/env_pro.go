//go:build pro

package env

const (
	Host        = "https://login.cloud007.com" ///生产
	Environment = "pro"
	AppName     = Program + ".exe"
)
