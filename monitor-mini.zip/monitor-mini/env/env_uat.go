//go:build uat

package env

const (
	Host        = "https://front-react-nt-cloud007-uat.yeh.lu" ///预发布
	Environment = "uat"
	AppName     = Program + ".exe"
)
