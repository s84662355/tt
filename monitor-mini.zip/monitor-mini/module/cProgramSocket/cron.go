package cProgramSocket

import (
	"time"

	"github.com/robfig/cron/v3"

	. "monitor/protocol"
)

// runCron 方法用于设置和启动定时任务
func (m *manager) runCron() {
	// 创建一个新的 cron 实例，并支持秒级调度
	m.cronT = cron.New(cron.WithSeconds())

	// 使用 time.AfterFunc 函数在 20 秒后执行一个匿名函数
	// 这个匿名函数的作用是向模块 API 发送获取中继服务器信息和水印信息的消息
	time.AfterFunc(10*time.Second, func() {
		// 发送获取中继服务器信息的消息，消息 ID 为 MsgIdMonitorGetRelayServerInfo，消息内容为空
		////		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetRelayServerInfo, nil)
		// 发送获取水印信息的消息，消息 ID 为 MsgIdMonitorGetWatermarkInfo，消息内容为空
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetWatermarkInfo, nil)
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetScreenRecordOpt, nil)
	})

	// 使用 cron 调度器，每 5 分钟（即 5 * 60 秒）执行一次匿名函数
	// 这个匿名函数的作用和上面 5 秒后执行的匿名函数类似，也是发送获取中继服务器信息和水印信息的消息
	m.cronT.Schedule(cron.Every(5*60*time.Second), cron.FuncJob(func() {
		///	m.moduleApi.WriteProtoMessage(MsgIdMonitorGetRelayServerInfo, nil)
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetWatermarkInfo, nil)
	}))

	// 使用 cron 调度器，每 10 秒执行一次匿名函数
	// 这个匿名函数调用了 m.sendCsDeskRelayServerInfoMessage 和 m.sendWatermarkDataMessage 方法
	// 推测这两个方法是用于发送桌面中继服务器信息和水印数据消息的
	m.cronT.Schedule(cron.Every(10*time.Second), cron.FuncJob(func() {
		////		m.sendCsDeskRelayServerInfoMessage()
		m.sendWatermarkDataMessage()
	}))

	m.cronT.Schedule(cron.Every(20*time.Second), cron.FuncJob(func() {
		m.setProcessActiveMessage(true)
	}))

	m.cronT.Schedule(cron.Every(3*60*time.Second), cron.FuncJob(func() {
		///	m.moduleApi.WriteProtoMessage(MsgIdMonitorGetRelayServerInfo, nil)
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetScreenRecordOpt, nil)
	}))

	// 启动 cron 调度器，开始执行已注册的定时任务
	m.cronT.Start()
}
