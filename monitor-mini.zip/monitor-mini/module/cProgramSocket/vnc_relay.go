package cProgramSocket

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"monitor/log"
	"monitor/module/cProgramSocket/vncRelayClient"
)

type VncPortData struct {
	VncPort uint16 `json:"vnc_port"`
	Code    string `json:"code"`
}

type vncPortContainer struct {
	port           uint16
	hasSetPort     atomic.Bool
	hasSetPortChan chan struct{}
	err            error
	doOne          sync.Once
	ctx            context.Context
}

func newVncPortContainer(ctx context.Context) *vncPortContainer {
	c := &vncPortContainer{
		hasSetPortChan: make(chan struct{}),
		ctx:            ctx,
	}
	return c
}

func (c *vncPortContainer) SetPort(port uint16) {
	if c.hasSetPort.CompareAndSwap(false, true) {
		c.port = port
		close(c.hasSetPortChan)
	}
}

func (c *vncPortContainer) WaitSetPort() (uint16, error) {
	c.doOne.Do(func() {
		select {
		case <-c.hasSetPortChan:
			return
		case <-c.ctx.Done():
			if c.hasSetPort.CompareAndSwap(false, true) {
				c.err = fmt.Errorf("自定义上下结束")
				close(c.hasSetPortChan)
				return
			}
		}
	})

	<-c.hasSetPortChan
	return c.port, c.err
}

// openVncRelay
func (m *manager) openVncRelay(code string, relayAddr string) {
	m.vncPortContainerMapMu.Lock()
	if _, ok := m.vncPortContainerMap[code]; ok {
		m.vncPortContainerMapMu.Unlock()
		return
	}

	ctxTimeout, cancel := context.WithTimeout(m.ctx, 2000*time.Millisecond)
	defer cancel()

	c := newVncPortContainer(ctxTimeout)
	m.vncPortContainerMap[code] = c
	m.vncPortContainerMapMu.Unlock()
	m.sendGetVncServerPortMessage(code)

	defer func() {
		m.vncPortContainerMapMu.Lock()
		delete(m.vncPortContainerMap, code)
		m.vncPortContainerMapMu.Unlock()
	}()

	if port, err := c.WaitSetPort(); err != nil {
		log.Errorf("[cProgramSocket] WaitSetPort err = %+v", err)
		return
	} else {

		client := vncRelayClient.NewClient(fmt.Sprintf(":%d", port), relayAddr, code)
		defer client.Stop()

		ctxTimeout, cancel := context.WithTimeout(m.ctx, 10*time.Second)
		defer cancel()
		if err := client.Handshake(ctxTimeout); err != nil {
			log.Errorf("[cProgramSocket] 中继客户端握手失败 err = %+v", err)
			return
		}

		done := make(chan struct{})
		defer func() {
			for range done {
				/* code */
			}
		}()

		go func() {
			defer close(done)
			client.Transfer()
		}()

		select {
		case <-m.ctx.Done():

		case <-done:
		}
		client.Stop()
	}
}
