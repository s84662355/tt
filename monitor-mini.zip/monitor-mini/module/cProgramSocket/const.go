package cProgramSocket

// socketProtocolType 定义了套接字协议的类型，使用 uint8 类型
// 由于使用 uint8，最多可以定义 256 种不同的协议类型
type socketProtocolType uint8

// 定义具体的协议类型，从 1 开始递增
// 每个常量代表一种特定的套接字协议类型，方便在通信中区分不同的数据类型
const (
	// RustdeskData 表示与 Rustdesk 相关的数据协议类型
	RustdeskData socketProtocolType = iota + 1
	// WatermarkData 表示与水印相关的数据协议类型
	WatermarkData
	EVncClient
	GetVncServerPort // 4
	Version          // 5 版本号
	ProcessActive    // 6
	VncRecordPort    // 7

)

// 定义与监控程序相关的常量
const (
	// MonitorDirectory 是监控程序解压后所在的目录名称
	MonitorDirectory = "monitor"
	// MonitorZip 是监控程序压缩包的文件名
	MonitorZip = "monitor.zip"
	// MonitorExe 是监控程序可执行文件的文件名
	MonitorExe = "monitor.exe"

	MonitorVExe = "CloudSeven-v.exe"
)

// 定义数据模板常量，用于格式化不同类型的数据
// RustdeskDataTemplate 是 Rustdesk 数据的 JSON 模板
// 其中包含 rd_key（可能是 Rustdesk 的密钥）、rd_relay_server（中继服务器地址）和 rd_rendezous_server（会合服务器地址）
// 在使用时，可以使用格式化函数将具体的值填充到模板中
const (
	RustdeskDataTemplate = `
		{
			"rd_key":"%s",
			"rd_relay_server":"%s",
			"rd_rendezous_server":"%s"
		}
	`
	// WatermarkDataTemplate 是水印数据的 JSON 模板
	// 包含了水印的各种属性，如透明度（wm_alpha）、列数（wm_col）、颜色（wm_color_b、wm_color_g、wm_color_r）等
	// 同样可以使用格式化函数将具体的水印属性值填充到模板中
	WatermarkDataTemplate = `
		{
			"wm_alpha":"%f",
			"wm_col":"%d",
			"wm_color_b":"%d",
			"wm_color_g":"%d",
			"wm_color_r":"%d",
			"wm_font":"%s",
			"wm_font_angle":"%d",
			"wm_font_size":"%d",
			"wm_row":"%d",
			"wm_text":"%s",
			"wm_type":"%d"
		}
	`
	GetVncServerPortTemplate = `
       {
       		"vnc_fps":%d,
       		"code":"%s"
       }
	`

	SetProcessActiveTemplate = `
		{
			 "enable":%t
		}
	`
)

// ProcessMonitorData 表示完整的进程监控数据
type ProcessMonitorData struct {
	EndTime        int64                `json:"end_time"`        // 结束时间戳
	ProcessMonitor []ProcessMonitorItem `json:"process_monitor"` // 进程监控列表
	StartTime      int64                `json:"start_time"`      // 开始时间戳
}

// ProcessMonitorItem 表示单个进程的监控数据
type ProcessMonitorItem struct {
	Name string `json:"name"` // 进程名称
	Time int64  `json:"time"` // 进程运行时间
}
