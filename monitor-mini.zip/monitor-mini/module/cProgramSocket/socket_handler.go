package cProgramSocket

import (
	"context"
	"encoding/json"
	"net"
	"sync"
	"time"

	"monitor/log"
	pb "monitor/protobuf"
	. "monitor/protocol"
)

// socketHandler 是处理网络连接的函数，负责接收和发送数据
func (m *manager) socketHandler(pCtx context.Context, conn net.Conn) {
	// 创建一个可取消的上下文，基于传入的父上下文 pCtx
	ctx, cancel := context.WithCancel(pCtx)
	// 确保在函数结束时取消上下文，释放相关资源
	defer cancel()

	// 创建一个同步等待组，用于等待两个 goroutine 完成
	wg := &sync.WaitGroup{}
	// 为等待组添加 2 个任务计数，因为有两个 goroutine 需要等待
	wg.Add(2)
	// 确保在函数结束时等待两个 goroutine 完成
	defer wg.Wait()

	// 启动一个 goroutine 用于接收数据
	go func() {
		defer log.DRecover("[cProgramSocket] socketHandler Read")
		// 当 goroutine 结束时，将等待组的计数减 1
		defer wg.Done()
		// 确保在 goroutine 结束时取消上下文
		defer cancel()
		// 确保在 goroutine 结束时关闭网络连接
		defer conn.Close()

		for {
			// 检查上下文是否被取消，如果取消则退出循环
			select {
			case <-ctx.Done():
				return
			default:
			}
			// 从网络连接中解析出协议数据
			data, err := socketProtocolUnmarshal(conn)
			if err != nil {
				// 如果解析数据出错，记录错误日志并退出 goroutine
				log.Errorf("[cProgramSocket] socketProtocolUnmarshal err = %+v", err)
				return
			}

			m.socketHandlerMsg(ctx, data)

			// 记录接收到的数据信息，包括数据类型和数据内容
			log.Infof("[cProgramSocket] 接收数据 type:%d data:%s ", data.Type, string(data.Data))
		}
	}()

	// 启动一个 goroutine 用于发送数据
	go func() {
		defer log.DRecover("[cProgramSocket] socketHandler Write")
		// 当 goroutine 结束时，将等待组的计数减 1
		defer wg.Done()
		// 确保在 goroutine 结束时取消上下文
		defer cancel()
		// 确保在 goroutine 结束时关闭网络连接
		defer conn.Close()

		for {
			// 检查上下文是否被取消，如果取消则退出循环
			select {
			case <-ctx.Done():
				return
			// 从消息通道 m.msgChan 中接收消息
			case msg, ok := <-m.msgChan:
				if ok && msg != nil {
					// 记录要发送的数据信息，包括数据类型和数据内容
					log.Infof("[cProgramSocket] 发送数据 type:%d data:%s ", msg.Type, string(msg.Data))
					// 将消息按照协议进行封装并发送到网络连接
					if _, err := conn.Write(socketProtocolMarshal(msg.Type, msg.Data)); err != nil {
						// 如果发送数据出错，记录错误日志并退出 goroutine
						log.Errorf("[cProgramSocket] 发送数据失败 type:%d data:%s error:%+v", msg.Type, string(msg.Data), err)
						return
					}
				}
			}
		}
	}()
}

func (m *manager) socketHandlerMsg(pCtx context.Context, data *socketProtocol) {
	switch data.Type {
	case GetVncServerPort:
		p := VncPortData{}
		err := json.Unmarshal(data.Data, &p) // 注意传递指针
		if err != nil {
			log.Errorf("[cProgramSocket] GetVncServerPort json.Unmarshal err = %+v", err)
			return
		}

		m.vncPortContainerMapMu.RLock()
		c, ok := m.vncPortContainerMap[p.Code]
		m.vncPortContainerMapMu.RUnlock()
		if !ok {
			log.Errorf("[cProgramSocket] GetVncServerPort code:%s 容器不存在", p.Code)
			return
		}

		c.SetPort(p.VncPort)

	case VncRecordPort:

		p := VncPortData{}
		err := json.Unmarshal(data.Data, &p) // 注意传递指针
		if err != nil {
			log.Errorf("[cProgramSocket] VncRecordPort json.Unmarshal err = %+v", err)
			return
		}

		m.vncPortContainerMapMu.RLock()
		c, ok := m.vncPortContainerMap[p.Code]
		m.vncPortContainerMapMu.RUnlock()
		if !ok {
			log.Errorf("[cProgramSocket] VncRecordPort code:%s 容器不存在", p.Code)
			return
		}

		c.SetPort(p.VncPort)

	case ProcessActive: /// 进程活跃
		log.Infof("[cProgramSocket] 接收到进程活跃数据 type:%d data:%s ", data.Type, string(data.Data))
		p := ProcessMonitorData{}
		err := json.Unmarshal(data.Data, &p) // 注意传递指针
		if err != nil {
			log.Errorf("[cProgramSocket] ProcessActive json.Unmarshal err = %+v", err)
			return
		}

		reportAppDurationList := make([]*pb.ReportAppDurationInfo, 0, len(p.ProcessMonitor))
		for _, v := range p.ProcessMonitor {
			reportAppDurationList = append(reportAppDurationList, &pb.ReportAppDurationInfo{
				AppName:        v.Name,
				Duration:       v.Time,
				Timestamp:      time.Now().Unix(),
				CollectStartTs: p.StartTime / 1000,
				CollectEndTs:   p.EndTime / 1000,
			})
		}

		m.moduleApi.WriteProtoMessage(
			MsgIdMonitorReportAppDuration,
			&pb.ReportAppDurationListReq{
				ReportAppDurationList: reportAppDurationList,
			},
		)

	}
}
