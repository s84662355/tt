package cProgramSocket

import (
	"context"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/schollz/progressbar/v3"
	"monitor/env"
	"monitor/log"
	"monitor/utils/bigfiledownloader"
	"monitor/utils/zip"
	// 以下包在代码中使用，但原代码未导入，这里补充导入
)

func (m *manager) startMonitor() {
	m.runMonitorExe()
}

// runMonitorExe 方法用于启动监控进程
func (m *manager) runMonitorExe() error {
	m.waitGroup.Add(1)
	// 增加 WaitGroup 的计数，用于等待监控进程执行完成
	// 启动一个新的 goroutine 来执行监控进程
	go func() {
		// 当 goroutine 退出时，执行以下操作
		defer func() {
			ctx, cancel := context.WithTimeout(m.ctx, 5*time.Second)
			defer cancel()
			<-ctx.Done()

			// 从 MonitorExeWaitChan 通道接收一个元素，释放通道空间
			<-m.monitorExeWaitChan

			// 减少 WaitGroup 的计数
			m.waitGroup.Done()
		}()
		m.downloadMonitor()

		if m.ss == nil || m.ss.Addr() == nil {
			err := fmt.Errorf("socket服务错误")
			log.Errorf("[cProgramSocket]  启动monitor进程失败  err = %+v", err)
			return
		}

		port := 0
		if tcpAddr, ok := m.ss.Addr().(*net.TCPAddr); ok {
			port = tcpAddr.Port
		} else {
			log.Errorf("[cProgramSocket]  socket服务获取端口失败")
		}

		os.Rename(filepath.Join(
			env.BaseDir,      // 基础目录
			MonitorDirectory, // 监控程序所在目录
			MonitorExe,       // 监控程序的可执行文件名
		), filepath.Join(
			env.BaseDir,      // 基础目录
			MonitorDirectory, // 监控程序所在目录
			MonitorVExe,      // 监控程序的可执行文件名
		))

		// 创建一个命令对象，用于执行监控程序
		echo := exec.CommandContext(
			m.ctx, // 使用上下文控制命令的生命周期
			// 构建监控程序的完整路径
			filepath.Join(
				env.BaseDir,      // 基础目录
				MonitorDirectory, // 监控程序所在目录
				MonitorVExe,      // 监控程序的可执行文件名
			),
			fmt.Sprintf("--ip=127.0.0.1"),
			fmt.Sprintf("--port=%d", port),
		)
		// 关键设置：同时隐藏窗口和任务栏图标
		// 原代码中没有具体实现，这里只是注释说明

		// 启动命令
		if err := echo.Start(); err != nil {
			// 启动失败，记录错误信息
			log.Errorf("[cProgramSocket]  启动monitor进程失败  err = %+v", err)
			return
		}

		// 启动成功，记录信息
		log.Infof("[cProgramSocket] 启动monitor进程成功")

		// 等待命令执行完成
		if err := echo.Wait(); err != nil {
			// 启动失败，记录错误信息
			log.Errorf("[cProgramSocket] monitor进程关闭  err = %+v", err)
			return
		}

		log.Infof("[cProgramSocket] monitor进程关闭")
	}()

	// 正常启动，返回 nil 错误
	return nil
}

func (m *manager) downloadMonitor() error {
	///如果文件已经存在，并且能够解压成功就不下载了
	zipPath := filepath.Join(
		env.BaseDir,
		MonitorZip,
	)

	if is, _ := IsFileOlderThan24Hours(zipPath); is {
		os.Remove(zipPath)
	}

	if err := zip.UnZip(
		filepath.Join(
			env.BaseDir,
			MonitorDirectory,
		),
		zipPath,
	); err == nil {
		return nil
	}
	// 下载前先删除文件
	os.Remove(zipPath)

	bar := progressbar.Default(100)
	defer bar.Close()
	downloader := bigfiledownloader.NewBigDownloader(
		5, func(ddd float64) {
			bar.Set(int(ddd))
		},
	)

	// 下载超时
	ctx, cancel := context.WithTimeout(
		m.ctx,
		10*60*time.Second,
	)
	defer cancel()
	if err := downloader.Download(
		ctx,
		MonitorDownLoadUrl,
		filepath.Join(
			env.BaseDir,
			MonitorZip,
		),
	); err != nil {
		log.Errorf("[cProgramSocket]  downloadMonitor 下载Monitor err = %+v", err)
		return err
	}
	if err := zip.UnZip(
		filepath.Join(
			env.BaseDir,
			MonitorDirectory,
		), zipPath,
	); err != nil {
		log.Errorf("[cProgramSocket] downloadMonitor 解压 err = %+v", err)
		return err
	}
	return nil
}

// IsFileOlderThan24Hours 函数用于判断文件创建时间是否超过 24 小时
func IsFileOlderThan24Hours(filePath string) (bool, error) {
	// 获取文件信息
	fileInfo, err := os.Stat(filePath)
	if err != nil {
		return false, err
	}

	// 获取文件的修改时间
	modTime := fileInfo.ModTime()

	// 计算 24 小时前的时间
	twentyFourHoursAgo := time.Now().Add(-24 * time.Hour)

	// 判断文件修改时间是否早于 24 小时前
	return modTime.Before(twentyFourHoursAgo), nil
}
