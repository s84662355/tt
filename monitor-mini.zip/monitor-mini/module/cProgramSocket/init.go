package cProgramSocket

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"
	"monitor/env"
	"monitor/log"
	"monitor/protobuf"
	. "monitor/protocol"
	"monitor/utils/gohook/pkg/mouse"
	"monitor/utils/process"
)

// manager 结构体用于管理与 C 程序的套接字通信
type manager struct {
	ctx          context.Context  // 上下文，用于控制生命周期
	cronT        *cron.Cron       // 定时任务管理器
	moduleApi    common.ModuleApi // 模块 API，用于与其他模块交互
	MonitorExeMu sync.Mutex       // 用于保护水位标记数据的互斥锁

	waitGroup             sync.WaitGroup
	monitorExeWaitChan    chan struct{} // 用于等待水位标记执行完成的通道
	vncRecordChan         chan struct{}
	fw                    *process.FindWindows // 查找窗口的工具
	msgChan               chan *socketProtocol // 消息通道，用于发送套接字协议消息
	ss                    *socketServer
	csDeskRelayServerInfo atomic.Pointer[protobuf.PushCsDeskRelayServerInfo]
	waterMarkData         atomic.Pointer[protobuf.DeviceWatermarkInfo] // 水位标记数据
	vncPort               atomic.Int32
	vncPortContainerMap   map[string]*vncPortContainer
	vncPortContainerMapMu sync.RWMutex
	vncRecordMu           sync.Mutex
	isCanRecord           bool
}

// Start 方法用于启动管理器
func (m *manager) Start(cc common.ModuleApi) error {
	// 创建一个可取消的上下文
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	m.moduleApi = cc
	// 函数结束时取消上下文
	defer cancel()

	m.vncPortContainerMap = map[string]*vncPortContainer{}

	m.monitorExeWaitChan = make(chan struct{}, 1)
	defer close(m.monitorExeWaitChan)

	m.vncRecordChan = make(chan struct{}, 1)
	defer close(m.vncRecordChan)

	// 创建一个有缓冲的消息通道
	m.msgChan = make(chan *socketProtocol, 8)
	// 函数结束时关闭消息通道
	defer close(m.msgChan)

	// 创建一个新的套接字服务器，传入套接字处理函数
	ss, err := newSocketServer(m.socketHandler)
	if err != nil {
		// 如果创建套接字服务器失败，返回错误信息
		return fmt.Errorf("cProgramSocket newSocketServer error:%w", err)
	}

	// 函数结束时关闭套接字服务器
	defer ss.Close()
	m.ss = ss

	m.runCron()
	defer func() {
		cancel()
		ctx := m.cronT.Stop()
		///等待定时任务完全结束
		<-ctx.Done()
	}()
	mhook := mouse.New()
	mouseChan, err := mhook.Install()
	if err != nil {
		return fmt.Errorf("[keyboardMouse] mouse.Install err=%+v", err)
	}
	defer mhook.Uninstall()

	ticker := time.NewTicker(3 * time.Second)
	defer ticker.Stop()
	nowTime := time.Now()
	tenMinutes := 10 * time.Minute

	defer m.waitGroup.Wait()
	defer cancel()
	for {
		select {
		// 如果上下文被取消，退出函数
		case <-cc.GetContext().Done():
			return nil
		// 从模块 API 获取消息
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				// 如果通道关闭，退出函数
				return nil
			}

			if moduleMsg == nil {
				// 如果消息为空，继续下一次循环
				continue
			}
			// 根据消息的路由消息 ID 进行不同的处理
			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorPushWatermarkInfo: ///水印
				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.DeviceWatermarkInfo); ok && mm != nil {
						m.waterMarkData.Store(mm)
					}
				}
			case MsgIdMonitorPushViewOnlineInfo: // 推送在线观看中继服务器信息
				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.MonitorViewOnlineInfo); ok && mm != nil {
						log.Infof("[cProgramSocket] 接收推送在线观看中继服务器信息 %+v", mm)
						if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorScreenOnLive) {
							log.Errorf("[cProgramSocket]  没有在线观看中继服务器权限")
							continue
						}

						m.waitGroup.Add(1)
						go func() {
							defer m.waitGroup.Done()
							m.openVncRelay(mm.Uuid, fmt.Sprintf("%s:%d", mm.Host, mm.Port))
						}()
					}
				}
			case MsgIdMonitorPushScreenRecordOpt:

				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.ScreenRecordOpt); ok && mm != nil {
						log.Infof("[cProgramSocket]录制权限%+v", mm)
						m.isCanRecord = false
						if mm.IsScreenRecord == 1 {
							m.isCanRecord = true
						}

					}
				}

			default:
				// 这里可以添加具体的处理逻辑
			}

		case m.monitorExeWaitChan <- struct{}{}:
			m.startMonitor()

		case <-ticker.C:
			if !m.isCanRecord {
				continue
			}

			timeDiff := time.Now().Sub(nowTime)

			if timeDiff < tenMinutes {
				select {
				case m.vncRecordChan <- struct{}{}:
					m.waitGroup.Add(1)
					go func() {
						defer func() {
							m.waitGroup.Done()
							<-m.vncRecordChan
						}()

						log.Info("[cProgramSocket] 开始录制")
						m.vncRecord(fmt.Sprintf("%s-%s", env.CompanyId, env.MachineID))
						log.Info("[cProgramSocket] 结束录制")
					}()

				default:

				}
			}

		case <-mouseChan:
			nowTime = time.Now()

		}
	}
}
