package cProgramSocket

import (
	"encoding/binary"
	"io"
	"net"
)

// 定义协议头各部分的长度
const (
	typeLen     = 1 // 协议类型字段的长度，单位为字节
	dataSizeLen = 2 // 数据大小字段的长度，单位为字节
)

// socketProtocol 结构体表示套接字协议的消息结构
type socketProtocol struct {
	Type socketProtocolType // 协议类型
	Data []byte             // 协议携带的数据
}

// socketProtocolUnmarshal 函数用于从网络连接中解析出 socketProtocol 结构体
func socketProtocolUnmarshal(conn net.Conn) (*socketProtocol, error) {
	// 读取协议头（类型和数据大小），创建一个长度为 typeLen + dataSizeLen 的缓冲区
	buf := make([]byte, typeLen+dataSizeLen)
	// 从连接中完整读取协议头数据
	if _, err := io.ReadFull(conn, buf); err != nil {
		// 如果读取失败，返回 nil 和错误信息
		return nil, err
	}

	// 创建一个新的 socketProtocol 结构体实例
	r := &socketProtocol{
		Type: socketProtocolType(buf[0]), // 从缓冲区的第一个字节获取协议类型
	}

	// 从缓冲区的第 2 到 3 字节获取数据大小
	dataSize := binary.BigEndian.Uint16(buf[1:3])
	// 创建一个长度为数据大小的缓冲区
	buf = make([]byte, dataSize)
	// 从连接中完整读取数据
	if _, err := io.ReadFull(conn, buf); err != nil {
		// 如果读取失败，返回 nil 和错误信息
		return nil, err
	}
	// 将读取到的数据赋值给 socketProtocol 结构体的 Data 字段
	r.Data = buf
	// 返回解析后的 socketProtocol 结构体和 nil 错误
	return r, nil
}

// socketProtocolMarshal 函数用于将协议类型和数据封装成字节切片
func socketProtocolMarshal(Type socketProtocolType, data []byte) []byte {
	// 获取数据的长度
	n := len(data)
	// 创建一个长度为 typeLen + dataSizeLen + 数据长度的字节切片
	b := make([]byte, typeLen+dataSizeLen+n)
	// 将协议类型放入字节切片的第一个字节
	b[0] = byte(Type)
	// 将数据大小以大端字节序放入字节切片的第 2 到 3 字节
	binary.BigEndian.PutUint16(b[1:3], uint16(n))
	// 将数据复制到字节切片的第 4 个字节开始的位置
	copy(b[3:], data)
	// 返回封装好的字节切片
	return b
}
