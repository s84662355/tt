//go:build pro

package cProgramSocket

// MonitorDownLoadUrl是监控程序压缩包的下载地址
const (
	MonitorDownLoadUrl = "https://cloudseven.oss-ap-southeast-1.aliyuncs.com/cs_monitor/monitor.zip"
)
