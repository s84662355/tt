package cProgramSocket

import (
	"context"
	"fmt"
	"io"
	"net"
	"os/user"
	"time"

	"monitor/dao"
	"monitor/env"
	"monitor/log"

	"monitor/utils/registry"

	uIp "monitor/utils/ip"
)

func (m *manager) vncRecord(machineID string) {
	code := fmt.Sprint(machineID, time.Now().Unix())
	m.vncPortContainerMapMu.Lock()
	if _, ok := m.vncPortContainerMap[code]; ok {
		m.vncPortContainerMapMu.Unlock()
		return
	}

	ctxTimeout, cancel := context.WithTimeout(m.ctx, 2000*time.Millisecond)
	defer cancel()

	c := newVncPortContainer(ctxTimeout)
	m.vncPortContainerMap[code] = c
	m.vncPortContainerMapMu.Unlock()
	m.sendVncRecordPortMessage(code)

	defer func() {
		m.vncPortContainerMapMu.Lock()
		delete(m.vncPortContainerMap, code)
		m.vncPortContainerMapMu.Unlock()
	}()

	if port, err := c.WaitSetPort(); err != nil {
		log.Errorf("[cProgramSocket]vncRecord WaitSetPort code:%s err = %+v", code, err)
		return
	} else {
		done := make(chan struct{})
		defer func() {
			for range done {
				/* code */
			}
		}()
		ctxPar, cancelPar := context.WithCancel(m.ctx)
		defer cancelPar() // cancel when we are finished consuming integers
		d := net.Dialer{
			Timeout: 5 * time.Second,
		}
		conn, err := d.DialContext(ctxPar, "tcp", fmt.Sprintf(":%d", port))
		if err != nil {
			log.Errorf("[cProgramSocket]vncRecord DialContext err = %+v", err)
			return
		}
		defer conn.Close()

		defer close(done)
		defer cancelPar()

		serverAddr := ""
		if ScreenRecordHost, err := m.getVncRecordAddress(); err != nil {
			log.Errorf("[cProgramSocket]vncRecord getVncRecordAddress err = %+v", err)
			return
		} else {
			serverAddr = ScreenRecordHost
		}

		connServer, err := d.Dial("tcp", serverAddr)
		if err != nil {
			log.Errorf("[cProgramSocket] 录制连接服务端失败err = %+v", err)
			return
		}
		defer connServer.Close()

		if _, err := connServer.Write(append([]byte{byte(uint8(len(machineID)))}, []byte(machineID)...)); err != nil {
			log.Errorf("[cProgramSocket] 录制连接服务端握手失败 err = %+v", err)
			return
		}
		buf := make([]byte, 2)
		if _, err := connServer.Read(buf); err != nil {
			log.Errorf("[cProgramSocket] 录制连接服务端握手失败 err = %+v", err)
			return
		}

		if string(buf) != "ok" {
			log.Errorf("[cProgramSocket] 录制连接服务端握手失败 err = %+v", err)
			return
		}

		errChan := make(chan error, 2)
		go func() {
			_, err := io.Copy(connServer, conn)
			errChan <- err
		}()

		go func() {
			_, err := io.Copy(conn, connServer)
			errChan <- err
		}()

		select {
		case <-ctxPar.Done():
			connServer.Close()
			conn.Close()

			<-errChan
			<-errChan
		case <-errChan:
			connServer.Close()
			conn.Close()

			<-errChan

		}

		connServer.Close()
		conn.Close()

	}
}

func (m *manager) getVncRecordAddress() (string, error) {
	// 获取主机的 IP 适配器信息
	ipAdapterInfo, err := uIp.DefaultNIC()
	if err != nil {
		return "", err
	}

	// 从缓存中获取外网 IP 地址
	ip, err := uIp.GetIpFromCache(m.ctx)
	if err != nil {
		return "", err
	}

	currentUser, err := user.Current()
	if err != nil {
		return "", err
	}

	if currentUser == nil {
		return "", fmt.Errorf("currentUser == nil")
	}

	port, _ := registry.GetRDPPort()

	ScreenRecordHost, _, _, err := dao.GetMonitorGateway(m.ctx, ip, fmt.Sprintf("%s-%s", env.CompanyId, env.MachineID), ipAdapterInfo.IpAddress, env.StaffId, currentUser.Username, port)
	if err != nil {
		return "", err
	}
	return ScreenRecordHost, nil
}
