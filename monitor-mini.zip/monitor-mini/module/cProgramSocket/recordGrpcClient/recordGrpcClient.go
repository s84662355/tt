package recordGrpcClient

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	//"google.golang.org/grpc"
	//	"google.golang.org/grpc/credentials/insecure"
	pb "monitor/proto"
	//"monitor/vncRecord"
)

type RecordGrpcClient struct {
	grpcclient        pb.RecordServiceClient
	stream            pb.RecordService_StreamClient
	loginRequestError error
	loginDoOnce       sync.Once
	loginSuccessful   atomic.Bool
	mu                sync.Mutex
	done              chan struct{}
	ctx               context.Context
	cancel            context.CancelFunc
}

func NewRecordGrpcClient(
	ctx context.Context,
	grpcclient pb.RecordServiceClient,
	machineID string,
) (*RecordGrpcClient, error) {
	r := &RecordGrpcClient{}
	r.ctx, r.cancel = context.WithCancel(ctx)

	r.grpcclient = grpcclient
	stream, err := r.grpcclient.Stream(r.ctx)
	if err != nil {
		return nil, err
	}
	r.stream = stream
	if err := r.loginRequest(r.ctx, machineID); err != nil {
		r.stream.CloseSend()
		return nil, err
	}

	return r, nil
}

func (r *RecordGrpcClient) loginRequest(ctx context.Context, machineID string) error {
	r.loginDoOnce.Do(func() {
		loginReq := &pb.StreamMessage{
			Type: pb.MessageType_LOGIN,
			Content: &pb.StreamMessage_Login{
				Login: &pb.LoginRequest{
					MachineId: machineID,
					//	TaskId:   taskId,
				},
			},
		}

		done := make(chan struct{})
		go func() {
			defer close(done)
			err := r.send(loginReq)
			if err != nil {
				r.loginRequestError = err
				return
			}

			if msg, err := r.stream.Recv(); err != nil {
				r.loginRequestError = err
				return
			} else {
				if msg.GetType() != pb.MessageType_LoginSuccessful {
					r.loginRequestError = fmt.Errorf("服务端应答登录消息类型错误")
					return
				}
			}

			r.loginSuccessful.Store(true)
		}()

		select {
		case <-ctx.Done():
			r.stream.CloseSend()
			<-done
			r.loginRequestError = fmt.Errorf("登录上下文取消")
		case <-done:
		}

		if r.loginRequestError != nil {
			r.stream.CloseSend()
			return
		}

		r.done = make(chan struct{})
		go func() {
			defer close(r.done)

			done := make(chan struct{})
			defer func() {
				r.cancel()
				for range done {
					/* code */
				}
			}()

			go func() {
				defer close(done)

				//  定时器
				ticker := time.NewTicker(10 * time.Second)
				defer ticker.Stop() // 退出前停止定时器

				for {
					select {
					case done <- struct{}{}:
						r.stream.CloseSend()
						return
					case <-ticker.C:
						if err := r.send(&pb.StreamMessage{
							Type: pb.MessageType_Heartbeat,
						}); err != nil {
							r.stream.CloseSend()
							return
						}
					}
				}
			}()

			for {
				if _, err := r.stream.Recv(); err != nil {
					r.stream.CloseSend()
					return
				} else {
				}
			}
		}()
	})
	return r.loginRequestError
}

func (r *RecordGrpcClient) PushFrameData(imgCollMsg *pb.StreamMessage) error {
	return r.stream.Send(imgCollMsg)
}

func (r *RecordGrpcClient) Stop() error {
	return r.send(&pb.StreamMessage{
		Type: pb.MessageType_Finish,
		Content: &pb.StreamMessage_Login{
			Login: &pb.LoginRequest{},
		},
	})
}

func (r *RecordGrpcClient) send(msg *pb.StreamMessage) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.stream.Send(msg)
}

func (r *RecordGrpcClient) Close() {
	r.stream.CloseSend()
	r.cancel()
	for range r.done {
		/* code */
	}
}

func (r *RecordGrpcClient) Done() <-chan struct{} {
	return r.done
}
