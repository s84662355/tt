package cProgramSocket

import (
	"fmt"

	"monitor/controlCenter/common"
)

// sendData 方法用于将数据发送到消息通道 m.msgChan
// 如果上下文 m.ctx 被取消，则直接返回，不再发送数据
func (m *manager) sendData(data *socketProtocol) {
	select {
	// 如果上下文被取消，退出函数
	case <-m.ctx.Done():
		return
	// 向消息通道发送一个套接字协议消息
	case m.msgChan <- data:
	default:
	}
}

// sendCsDeskRelayServerInfoMessage 方法用于发送 Rustdesk 相关的数据消息
// 它会检查 csDeskRelayServerInfo 是否存在，如果存在则格式化数据并调用 sendData 方法发送
func (m *manager) sendCsDeskRelayServerInfoMessage() {
	// 从 m.csDeskRelayServerInfo 中加载数据
	if csDeskRelayServerInfo := m.csDeskRelayServerInfo.Load(); csDeskRelayServerInfo != nil {
		// 调用 sendData 方法发送数据
		m.sendData(&socketProtocol{
			Type: RustdeskData, // 数据类型为 RustdeskData
			Data: []byte(
				// 使用 RustdeskDataTemplate 模板格式化数据
				fmt.Sprintf(
					RustdeskDataTemplate,
					csDeskRelayServerInfo.Key,         // 填充密钥
					csDeskRelayServerInfo.RelayServer, // 填充中继服务器地址
					csDeskRelayServerInfo.ApiServer,   // 填充 API 服务器地址
				),
			),
		})
	}
}

// sendGetVncServerPortMessage 方法获取vnc服务端口
func (m *manager) sendGetVncServerPortMessage(code string) {
	m.sendData(&socketProtocol{
		Type: GetVncServerPort,
		Data: []byte(
			fmt.Sprintf(
				GetVncServerPortTemplate,
				15,
				code,
			),
		),
	})
}

func (m *manager) sendVncRecordPortMessage(code string) {
	m.sendData(&socketProtocol{
		Type: VncRecordPort,
		Data: []byte(
			fmt.Sprintf(
				GetVncServerPortTemplate,
				15,
				code,
			),
		),
	})
}

// sendWatermarkDataMessage 方法用于发送水印相关的数据消息
// 它会先检查监控项目中水印策略是否开启，再根据水印数据的情况格式化并发送数据
func (m *manager) sendWatermarkDataMessage() {
	// 检查监控项目中水印策略是否开启
	if m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorWatermarkStrategy) {
		// 从 m.waterMarkData 中加载水印数据
		if waterMarkData := m.waterMarkData.Load(); waterMarkData != nil {
			wm_type := 0
			// 根据水印的操作类型和水印方法确定 wm_type
			if waterMarkData.OptType == 1 {
				switch waterMarkData.WatermarkMethod {
				case 1:
					wm_type = 1
				case 2:
					wm_type = 2
				default:
				}
			}
			// 调用 sendData 方法发送水印数据
			m.sendData(&socketProtocol{
				Type: WatermarkData, // 数据类型为 WatermarkData
				Data: []byte(
					// 使用 WatermarkDataTemplate 模板格式化水印数据
					fmt.Sprintf(
						WatermarkDataTemplate,
						float32(float32(waterMarkData.Transparency)/100), // 计算并填充透明度
						5,             // 填充列数
						190, 190, 190, // 填充颜色值
						"Arial",                 // 填充字体
						30,                      // 填充字体角度
						30,                      // 填充字体大小
						3,                       // 填充行数
						waterMarkData.Watermark, // 填充水印文本
						wm_type,                 // 填充水印类型
					),
				),
			})
		}
	} else {
		// 如果水印策略未开启，发送默认的水印数据
		m.sendData(&socketProtocol{
			Type: WatermarkData, // 数据类型为 WatermarkData
			Data: []byte(
				// 使用 WatermarkDataTemplate 模板格式化默认水印数据
				fmt.Sprintf(
					WatermarkDataTemplate,
					0.0,           // 透明度为 0
					5,             // 列数
					190, 190, 190, // 颜色值
					"Arial", // 字体
					30,      // 字体角度
					30,      // 字体大小
					3,       // 行数
					"",      // 空的水印文本
					0,       // 水印类型为 0
				),
			),
		})
	}
}

func (m *manager) setProcessActiveMessage(active bool) {
	m.sendData(&socketProtocol{
		Type: ProcessActive,
		Data: []byte(
			fmt.Sprintf(
				SetProcessActiveTemplate,
				active,
			),
		),
	})
}
