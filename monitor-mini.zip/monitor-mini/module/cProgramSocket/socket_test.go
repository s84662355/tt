package cProgramSocket

import (
	"context"
	"fmt"
	"net"
	"sync"
	"testing"
	"time"
)

// go test -run TestSocket -v  -tags "dev"
func TestSocket(t *testing.T) {
	msgChan := make(chan *socketProtocol)
	defer close(msgChan)
	ss, _ := newSocketServer(func(pCtx context.Context, conn net.Conn) {
		ctx, cancel := context.WithCancel(pCtx)
		defer cancel()
		wg := &sync.WaitGroup{}
		wg.Add(2)
		defer wg.Wait()

		go func() {
			defer wg.Done()
			defer cancel()
			defer conn.Close()
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				data, err := socketProtocolUnmarshal(conn)
				if err != nil {
					fmt.Println("socketProtocolUnmarshal失败:", err)
					return
				}
				fmt.Println(data.Type, string(data.Data))
			}
		}()

		go func() {
			defer wg.Done()
			defer cancel()
			defer conn.Close()

			for {
				select {
				case <-ctx.Done():
					return
				case msg, ok := <-msgChan:
					if ok && msg != nil {
						if _, err := conn.Write(socketProtocolMarshal(msg.Type, msg.Data)); err != nil {
							fmt.Println("conn.Write失败:", err)
							return
						}
					}
				}
			}
		}()
	})

	defer ss.Close()

	conn, err := net.Dial("tcp", ss.Addr().String())
	if err != nil {
		fmt.Println("连接服务器失败:", err)
		return
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	wg := &sync.WaitGroup{}
	wg.Add(3)
	defer wg.Wait()

	go func() {
		defer wg.Done()
		defer cancel()
		defer conn.Close()
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()

		for i := 0; i < 10; i++ {
			ticker.Reset(2 * time.Second)
			if _, err := conn.Write(socketProtocolMarshal(VncRecordPort,

				[]byte(
					fmt.Sprintf(
						GetVncServerPortTemplate,
						10,
						"ifjdsiojfiodsjiofds",
					),
				),
			),
			); err != nil {
				fmt.Println("client conn.Write失败:", err)
				return
			}
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
			}

		}
	}()

	go func() {
		defer wg.Done()
		defer conn.Close()
		defer cancel()
		for {
			select {
			case <-ctx.Done():
				return
			default:
			}

			data, err := socketProtocolUnmarshal(conn)
			if err != nil {
				fmt.Println("client socketProtocolUnmarshal失败:", err)
				return
			}
			fmt.Println(data.Type, string(data.Data))
		}
	}()

	go func() {
		defer wg.Done()
		defer cancel()
		defer conn.Close()
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()

		for {
			ticker.Reset(1 * time.Second)
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:

				select {
				case <-ctx.Done():
					return
				case msgChan <- &socketProtocol{
					Type: ProcessActive,
					Data: []byte("树立了国与国相互成就、合作共赢的典范。"),
				}:
				}

			}
		}
	}()
}

// go test -run TestSocketMonitor -v  -tags "dev"
func TestSocketMonitor(t *testing.T) {
	msgChan := make(chan *socketProtocol)
	defer close(msgChan)
	ss, _ := newSocketServer(func(pCtx context.Context, conn net.Conn) {
		conn.Write(socketProtocolMarshal(ProcessActive, []byte(
			fmt.Sprintf(
				SetProcessActiveTemplate,
				true,
			),
		)))
		ctx, cancel := context.WithCancel(pCtx)
		defer cancel()
		wg := &sync.WaitGroup{}
		wg.Add(2)
		defer wg.Wait()

		go func() {
			defer wg.Done()
			defer cancel()
			defer conn.Close()
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				data, err := socketProtocolUnmarshal(conn)
				if err != nil {
					fmt.Println("socketProtocolUnmarshal失败:", err)
					return
				}
				fmt.Println(data.Type, string(data.Data))
			}
		}()

		go func() {
			defer wg.Done()
			defer cancel()
			defer conn.Close()

			for {
				select {
				case <-ctx.Done():
					return

				case msg, ok := <-msgChan:
					if ok && msg != nil {
						if _, err := conn.Write(socketProtocolMarshal(msg.Type, msg.Data)); err != nil {
							fmt.Println("conn.Write失败:", err)
							return
						}
					}
				}
			}
		}()
	})

	defer ss.Close()

	fmt.Println("连接服务器:", ss.Addr().String())

	for i := 0; i < 100; i++ {
		time.Sleep(3 * time.Second)
		select {
		case msgChan <- &socketProtocol{
			Type: VncRecordPort,
			Data: []byte(
				fmt.Sprintf(
					GetVncServerPortTemplate,
					10,
					fmt.Sprint(time.Now().Unix()),
				),
			),
		}:
		default:
		}
	}
}
