package cProgramSocket

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "CProgramSocket"

var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorGetRelayServerInfo,     // 19 获取中继服务器信息
	MsgIdMonitorPushRelayServerInfo,    // 20 推送中继服务器信息
	MsgIdMonitorRepCsDeskPwdInfo,       // 21 上报csDesk账号密码信息
	MsgIdMonitorRefreshRelayServerInfo, // 25 更新中继服务器信息
	MsgIdMonitorGetMonitorProjectInfo,  // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo, // 29 推送当前坐席版本

	MsgIdMonitorPushWatermarkInfo,      // 26 推送实例水印设置
	MsgIdMonitorGetWatermarkInfo,       // 27 获取实例水印设置
	MsgIdMonitorGetMonitorProjectInfo,  // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo, // 29 推送当前坐席版本

	MsgIdMonitorPushViewOnlineInfo, // 34 推送在线观看中继服务器信息

	MsgIdMonitorGetScreenRecordOpt,  // 获取是否屏幕录制
	MsgIdMonitorPushScreenRecordOpt, // 推送是否屏幕录制

}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn: Strat,
			Msgs:    slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
		})
}
