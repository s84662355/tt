package vncRelayClient

import (
	"context"
	"fmt"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

type Client struct {
	vncServer       string
	relayServer     string
	relayKey        string
	vncConn         net.Conn
	relayConn       net.Conn
	handshakeStatus atomic.Bool
	ctx             context.Context
	cancel          context.CancelFunc
	transfer        func() error
	handshakeOnce   sync.Once
	handshakeError  error
	stopOnce        sync.Once
}

func NewClient(
	vncServer string,
	relayServer string,
	relayKey string,
) *Client {
	c := &Client{
		vncServer:   vncServer,
		relayServer: relayServer,
		relayKey:    relayKey,
	}

	c.ctx, c.cancel = context.WithCancel(context.Background())

	c.transfer = sync.OnceValue(func() error {
		wg := sync.WaitGroup{}
		defer func() {
			c.vncConn.Close()
			c.relayConn.Close()
			wg.Wait()
		}()
		errChan := make(chan error, 2)
		wg.Add(2)
		go func() {
			defer wg.Done()
			_, err := io.CopyBuffer(c.vncConn, c.relayConn, make([]byte, 8*1024))
			errChan <- err
		}()

		go func() {
			defer wg.Done()
			_, err := io.CopyBuffer(c.relayConn, c.vncConn, make([]byte, 8*1024))
			errChan <- err
		}()

		select {
		case <-c.ctx.Done():
			return nil
		case err := <-errChan:
			return err
		}
	})

	return c
}

func (c *Client) Handshake(ctx context.Context) error {
	c.handshakeOnce.Do(func() {
		d := net.Dialer{
			Timeout: 5 * time.Second,
		}

		{
			conn, err := d.DialContext(ctx, "tcp", c.vncServer)
			if err != nil {
				c.handshakeError = err
				return
			}
			c.vncConn = conn
		}

		{
			conn, err := d.DialContext(ctx, "tcp", c.relayServer)
			if err != nil {
				c.vncConn.Close()
				c.handshakeError = err
				return
			}
			c.relayConn = conn
		}

		done := make(chan struct{})
		var cErr error = nil
		defer func() {
			for range done {
			}
			if cErr != nil {
				c.handshakeError = cErr
			}
		}()

		go func() {
			defer close(done)
			select {
			case done <- struct{}{}:
			case <-ctx.Done():
				c.vncConn.Close()
				c.relayConn.Close()
				cErr = fmt.Errorf("控制上下文关闭")
			case <-c.ctx.Done():
				c.vncConn.Close()
				c.relayConn.Close()
				cErr = fmt.Errorf("客户端关闭")
			}
		}()

		{
			if _, err := c.relayConn.Write(SocketProtocolMarshal(RdpServerHello, append([]byte{1}, []byte(c.relayKey)...))); err != nil {
				c.vncConn.Close()
				c.relayConn.Close()
				c.handshakeError = err
				return
			}
		}

		{
			if data, err := SocketProtocolUnmarshal(c.relayConn); err != nil {
				c.vncConn.Close()
				c.relayConn.Close()
				c.handshakeError = err
				return
			} else {
				if data.Type != RelayAckRdpServer {
					c.vncConn.Close()
					c.relayConn.Close()
					c.handshakeError = fmt.Errorf("获取服务响应类型错误")
					return
				} else {
					if string(data.Data) == "ok" {
						if c.handshakeStatus.CompareAndSwap(false, true) {

							c.handshakeError = nil
							return
						}
						c.vncConn.Close()
						c.relayConn.Close()
						c.handshakeError = fmt.Errorf("客户端被关闭")
						return

					} else {
						c.vncConn.Close()
						c.relayConn.Close()

						c.handshakeError = fmt.Errorf("获取服务响应错误")
						return

					}
				}
			}
		}
	})

	return c.handshakeError
}

func (c *Client) Transfer() error {
	return c.transfer()
}

func (c *Client) Stop() {
	c.stopOnce.Do(func() {
		if !c.handshakeStatus.CompareAndSwap(false, true) {
			c.vncConn.Close()
			c.relayConn.Close()
		}
	})

	c.cancel()
}
