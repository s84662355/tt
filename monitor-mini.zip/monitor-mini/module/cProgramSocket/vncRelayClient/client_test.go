package vncRelayClient

import (
	"fmt"
	"log"
	"net"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

// go test -run TestVncRelayClient -v
func TestVncRelayClient(t *testing.T) {
	go func() {
		handleClient := func(conn net.Conn) {
			defer conn.Close()
			buf := make([]byte, 1024)
			for {
				n, err := conn.Read(buf)
				if err != nil {
					log.Printf("客户端断开连接: %s", conn.RemoteAddr())
					break
				}

				message := string(buf[:n])

				// 处理消息
				message = strings.TrimSpace(message) + "3489899390543"
				log.Printf("来自 %s 的消息: %s", conn.RemoteAddr(), message)

				// 回显消息给客户端
				conn.Write([]byte(fmt.Sprintf("你发送了: %s\n", message)))
			}
		}

		// 监听TCP端口
		listener, err := net.Listen("tcp", ":15260")
		if err != nil {
			log.Fatalf("启动服务器失败: %v", err)
		}
		defer listener.Close()

		log.Println("服务器启动在 :15260")

		// 循环接受客户端连接
		for {
			conn, err := listener.Accept()
			if err != nil {
				log.Printf("接受连接失败: %v", err)
				continue
			}

			// 为每个客户端创建一个goroutine处理
			go handleClient(conn)
		}
	}()

	go func() {
		c := NewClient(":15260", ":54653", "dsadasdada")
		if c.Handshake() == nil {
			c.Transfer()
		}
	}()

	go func() {
		// 连接到WebSocket服务器
		c, _, err := websocket.DefaultDialer.Dial("ws://127.0.0.1:28452/relay?id=dsadsadsadasdada", nil)
		if err != nil {
			log.Fatalf("连接失败: %v", err)
		}
		defer c.Close()

		// 接收服务器消息
		receiveMessages := func(c *websocket.Conn) {
			defer c.Close()
			for {
				fmt.Println("接收消asdsad n", c.WriteMessage(websocket.BinaryMessage, []byte("dksoapfksdpofkosdfs")))
				// 读取消息
				_, message, err := c.ReadMessage()
				if err != nil {
					log.Printf("接收消息失败: %v", err)
					return
				}
				fmt.Println("qq5454qqqqqqqqqq", string(message))
			}
		}

		// 启动接收消息的goroutine
		receiveMessages(c)
	}()

	time.Sleep(30 * time.Second)
}
