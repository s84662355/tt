package cProgramSocket

import (
	"context"
	"net"
)

// socketServerHandler 定义了处理连接的函数类型
// 接收一个上下文和一个网络连接作为参数
type socketServerHandler func(ctx context.Context, conn net.Conn)

// socketServer 结构体表示一个 TCP 套接字服务器
type socketServer struct {
	listener net.Listener        // 网络监听器，用于监听传入的连接
	handler  socketServerHandler // 处理连接的函数
	ctx      context.Context     // 上下文，用于控制服务器的生命周期
	cancel   context.CancelFunc  // 用于取消上下文的函数
	run      func()              // 启动服务器的函数，使用 sync.OnceFunc 确保只执行一次
	done     chan struct{}       // 用于通知服务器已关闭的通道
}

// newSocketServer 创建一个新的 socketServer 实例
// 接收一个处理连接的函数作为参数
func newSocketServer(handler socketServerHandler) (*socketServer, error) {
	// 监听 TCP 端口，":0" 表示让操作系统自动分配一个可用的端口
	listener, err := net.Listen("tcp", ":0")
	if err != nil {
		// 如果监听失败，返回 nil 和错误信息
		return nil, err
	}
	// 创建一个新的 socketServer 实例
	s := &socketServer{
		listener: listener,
		handler:  handler,
		done:     make(chan struct{}),
	}
	// 创建一个可取消的上下文
	s.ctx, s.cancel = context.WithCancel(context.Background())
	// 使用 sync.OnceFunc 确保 s.run 函数只执行一次

	go func() {
		// 当函数退出时，关闭 done 通道
		defer close(s.done)
		for {
			// 检查上下文是否已取消
			select {
			case <-s.ctx.Done():
				// 如果上下文已取消，退出循环
				return
			default:
			}
			// 接受一个新的连接
			conn, err := s.listener.Accept()
			if err != nil || conn == nil {
				// 如果接受连接失败，继续下一次循环
				continue
			}
			if s.handler != nil {
				// 定义一个匿名函数处理连接
				func() {
					// 当函数退出时，关闭连接
					defer conn.Close()
					// 调用处理函数处理连接
					s.handler(s.ctx, conn)
				}()
			} else {
				conn.Close()
			}
		}
	}()

	// 返回新创建的 socketServer 实例和 nil 错误
	return s, nil
}

// Close 方法关闭服务器
func (s *socketServer) Close() error {
	// 定义一个匿名函数，等待 run 协程完全退出
	defer func() {
		// 从 done 通道接收信号，直到通道关闭
		for range s.done {
		}
	}()
	// 取消上下文
	s.cancel()
	// 关闭监听器
	return s.listener.Close()
}

// Addr 方法返回服务器监听的地址
func (s *socketServer) Addr() net.Addr {
	// 返回监听器的地址
	return s.listener.Addr()
}
