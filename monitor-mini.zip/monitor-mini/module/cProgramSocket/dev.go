//go:build dev

package cProgramSocket

// MonitorDownLoadUrl是监控程序压缩包的下载地址
const (
	MonitorDownLoadUrl = "https://cloudseven.oss-ap-southeast-1.aliyuncs.com/monitor.zip"
)
