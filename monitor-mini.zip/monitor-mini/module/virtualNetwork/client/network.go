package client

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"sync/atomic"
	"time"

	"golang.org/x/sys/windows"

	"github.com/lysShub/divert-go"
	"github.com/s84662355/simple-message/client"
	"github.com/s84662355/simple-message/connection"

	"monitor/gvisor.dev/gvisor/pkg/tcpip"
	"monitor/gvisor.dev/gvisor/pkg/tcpip/header"
	. "monitor/module/virtualNetwork/protocol"
)

var (
	ErrHandshakeTimeout = errors.New("握手超时")
	ErrHandshake        = errors.New("握手失败")
	ErrSendHandshake    = errors.New("发送握手数据失败")
)

type (
	errFunc     func(err error)
	DialContext func(ctx context.Context) (net.Conn, error)
)

type VMNetwork struct {
	cidr           string
	minIP          net.IP
	maxIP          net.IP
	svmip          string
	sip            string
	organizationId string
	mid            string
	sipAddress     tcpip.Address
	defaultAddrrr  *divert.Address
	mtu            uint32 // 最大传输单元
	// 网络接口信息
	ifIdx    uint32 // 接口索引
	subIfIdx uint32 // 子接口索引
	tempBuf  []byte // 临时缓冲区
	run      atomic.Bool
	client   *client.Client
	ctx      context.Context
	cancel   context.CancelFunc
	runChan  chan struct{}

	handle        *divert.Handle
	ipPackChan    chan []byte
	ipPackDevChan chan []byte
	ef            errFunc
	dialContext   DialContext
}

func NewVMNetwork(
	cidr string,
	svmip string,
	OrganizationId string,
	Mid string,
	dialContext DialContext,
	ef errFunc,
) (*VMNetwork, error) {
	a := &VMNetwork{}

	if minIP, maxIP, err := GetIPRange(cidr); err != nil {
		return nil, err
	} else {
		a.minIP = minIP
		a.maxIP = maxIP
	}

	a.ef = ef
	a.dialContext = dialContext

	a.ipPackChan = make(chan []byte)
	a.ipPackDevChan = make(chan []byte)
	a.run.Store(true)
	a.cidr = cidr
	a.svmip = svmip

	a.organizationId = OrganizationId
	a.mid = Mid

	a.ctx, a.cancel = context.WithCancel(context.Background())
	// 创建客户端实例
	a.client = client.NewClient(
		map[uint32]connection.Handler{
			MsgIdHandshakeRequest:  a,
			MsgIdHandshakeResponse: a,
			MsgIdIpProtocolSend:    a,
			MsgIdIpProtocolGet:     a,
		}, // 消息处理器映射
		1024*2, // 最大数据长度
		a,
	)

	return a, nil
}

// Handle 实现消息处理接口，打印收到的消息ID和内容
func (a *VMNetwork) Handle(request connection.IRequest) {
	// 可以通过以下方法获取消息数据和ID
	data := request.GetData()
	msgID := request.GetMsgID()

	switch msgID {
	case MsgIdHandshakeResponse:

		handshakeResponseData := &HandshakeResponseData{}
		if err := json.Unmarshal(data, &handshakeResponseData); err != nil {
			defer request.GetConnection().Close()
			a.ef(err)
			return
		} else {
			if !handshakeResponseData.Ok {
				a.ef(fmt.Errorf("%w %s", ErrHandshake, handshakeResponseData.Msg))
				defer request.GetConnection().Close()
				return
			}
		}

		close(a.runChan)
	default:

		select {
		case <-a.runChan:
		default:
			return
		}
		switch msgID {
		case MsgIdIpProtocolGet:
			if len(data) < header.IPv4MinimumSize {
				return
			}

			ipHeader := header.IPv4(data)
			ipHeader.SetDestinationAddress(a.sipAddress)
			// 重新计算 IP 头部校验和（修改后必须重新计算）
			ipHeader.SetChecksum(0) // 先清零
			ipHeader.SetChecksum(calculateIPv4Checksum(data[:header.IPv4MinimumSize]))

			select {
			case a.ipPackDevChan <- data:
			case <-a.ctx.Done():
				return
			case <-request.GetConnection().Ctx().Done():
				return

			}

		default:
			return

		}

	}
}

func (a *VMNetwork) DialContext(ctx context.Context) (connection.Conn, error) {
	a.runChan = make(chan struct{})
	return a.dialContext(ctx)
}

func (a *VMNetwork) Stop() {
	a.run.Store(false)
	a.cancel()
	a.client.Stop()
}

func (a *VMNetwork) ConnErr(ctx context.Context, conn *connection.Connection, err error) {
	fmt.Printf("连接错误: %v, 连接信息: %v, 准备重连...\n", err, conn)
	a.ef(err)
}

func (a *VMNetwork) runDivert(conn *connection.Connection, ctx context.Context) {
	defer conn.Close()
	IfIdx, SubIfIdx, mtu, sip, err := GetInterfaceIndex(a.cidr)
	if err != nil {
		a.ef(err)
		return
	}

	filter := fmt.Sprintf(
		"ifIdx = %d and  outbound and ip and  (  ip.DstAddr  >=  %s  &&  ip.DstAddr  <=  %s ) and not loopback",
		IfIdx,
		a.minIP.String(),
		a.maxIP.String(),
	)
	handle, err := divert.Open(filter, divert.Network, -995, 0)
	if err != nil {
		a.ef(err)
		return
	}

	a.sip = sip
	a.handle = handle
	a.mtu = mtu
	a.tempBuf = make([]byte, mtu)
	// 5. 配置默认地址参数
	addrrr := &divert.Address{}
	addrrr.Layer = divert.Network
	addrrr.Event = divert.NetworkPacket
	nw := addrrr.Network()
	nw.IfIdx = IfIdx
	nw.SubIfIdx = SubIfIdx
	addrrr.SetIPv6(false)        // 仅IPv4
	addrrr.SetOutbound(false)    // 入站流量
	addrrr.SetLoopback(false)    // 非回环
	addrrr.SetIPChecksum(true)   // 校验IP校验和
	addrrr.SetTCPChecksum(false) // 不校验TCP校验和
	addrrr.SetImpostor(false)    // 非伪造包
	addrrr.SetUDPChecksum(false) // 不校验UDP校验和
	a.defaultAddrrr = addrrr
	a.sipAddress = tcpip.AddrFrom4([4]byte(net.ParseIP(sip).To4()))
	done := make(chan struct{})
	defer func() {
		conn.Close()
		a.handle.Shutdown(divert.Both)
		a.handle.Close()
		for range done {
			/* code */
		}
	}()

	go func() {
		defer close(done)
		for {
			select {
			case <-a.ctx.Done():
				a.handle.Shutdown(divert.Both)
				a.handle.Close()
				return
			case <-ctx.Done():
				a.handle.Shutdown(divert.Both)
				a.handle.Close()
				return
			case data := <-a.ipPackDevChan:
				a.handle.Send(data, a.defaultAddrrr)
			}
		}
	}()

	aaa := tcpip.AddrFrom4([4]byte(net.ParseIP(a.svmip).To4()))
	var addr divert.Address
	for a.run.Load() {
		n, err := a.handle.Recv(a.tempBuf, &addr)
		if err != nil {
			// 若缓冲区不足，继续接收
			if errors.Is(err, windows.ERROR_INSUFFICIENT_BUFFER) {
				continue
			}
			// 其他错误则退出函数
			a.ef(err)
			return
		}
		// 若接收到的数据包长度为 0，继续接收
		if n == 0 {
			continue
		}

		if n < header.IPv4MinimumSize {
			continue
		}
		ipHeader := header.IPv4(a.tempBuf[:n])
		ipHeader.SetSourceAddress(aaa)
		ipHeader.SetChecksum(0) // 先清零
		ipHeader.SetChecksum(calculateIPv4Checksum(a.tempBuf[:header.IPv4MinimumSize]))

		select {
		case <-a.ctx.Done():
			return
		case <-ctx.Done():
			return
		default:
			if err := conn.SendMsg(MsgIdIpProtocolSend, a.tempBuf[:n]); err != nil {
				a.ef(err)
				return
			}

		}

	}
}

func (a *VMNetwork) ConnectedBegin(ctx context.Context, conn *connection.Connection) {
	defer conn.Close()
	if data, err := json.Marshal(&HandshakeRequestData{
		OrganizationId: a.organizationId,
		Mid:            a.mid,
		Ip:             a.svmip,
	}); err == nil {
		if err := conn.SendMsgContext(ctx, MsgIdHandshakeRequest, data); err != nil {
			a.ef(fmt.Errorf("%w  %w", ErrSendHandshake, err))
			return
		}

		ctxTimeout, _ := context.WithTimeout(context.Background(), 10000*time.Millisecond)
		select {
		case <-ctxTimeout.Done():
			a.ef(ErrHandshakeTimeout)
			return
		case <-a.ctx.Done():
			return
		case <-ctx.Done():
			return
		case <-a.runChan:
		}
	} else {
		return
	}
	a.runDivert(conn, ctx)
}

// 手动计算 IPv4 头部校验和（兼容所有 gvisor 版本）
func calculateIPv4Checksum(ipHeader []byte) uint16 {
	var sum uint32
	// IP 头部长度以 32 位（4 字节）为单位，需转换为 16 位（2 字节）的数量
	// IHL 字段值 * 2（因 4 字节 = 2 个 16 位）
	ihl := int(ipHeader[0] & 0x0F) // 获取 IHL 字段（头部长度，单位：32 位）
	length := ihl * 2              // 16 位整数的数量

	// 累加所有 16 位整数
	for i := 0; i < length; i++ {
		// 按网络字节序（大端）解析 16 位整数
		val := uint32(ipHeader[2*i])<<8 | uint32(ipHeader[2*i+1])
		sum += val
	}

	// 处理溢出（将高 16 位与低 16 位相加）
	for sum>>16 != 0 {
		sum = (sum & 0xffff) + (sum >> 16)
	}

	// 取反得到校验和
	return ^uint16(sum)
}
