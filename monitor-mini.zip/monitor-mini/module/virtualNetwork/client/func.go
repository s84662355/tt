package client

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/lysShub/divert-go"

	"monitor/gvisor.dev/gvisor/pkg/tcpip/header"
)

func GetIPRange(cidr string) (net.IP, net.IP, error) {
	// 解析CIDR
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		return nil, nil, err
	}

	// 最小IP是网络地址
	minIP := ipnet.IP

	// 最大IP是广播地址
	maxIP := make(net.IP, len(ipnet.IP))
	copy(maxIP, ipnet.IP)

	for i := 0; i < len(ipnet.IP); i++ {
		maxIP[i] |= ^ipnet.Mask[i]
	}

	return minIP, maxIP, nil
}

func GetInterfaceIndex(cidr string) (uint32, uint32, uint32, string, error) {
	divert.MustLoad(divert.DLL)

	minIP, maxIP, err := GetIPRange(cidr)
	if err != nil {
		return 0, 0, 0, "", fmt.Errorf("GetIPRange: %w", err)
	}

	filter := fmt.Sprintf(" not loopback and outbound and ip and  (  ip.DstAddr  >=  %s  &&  ip.DstAddr  <=  %s )", minIP.String(), maxIP.String())
	fmt.Println(minIP.String(), maxIP.String())
	// 2. 打开WinDivert句柄
	hd, err := divert.Open(filter, divert.Network, 0, divert.Sniff)
	if err != nil {
		return 0, 0, 0, "", fmt.Errorf("打开WinDivert失败: %w", err)
	}
	defer hd.Close()
	defer hd.Shutdown(divert.Both)

	addr := divert.Address{}
	buff := make([]byte, 1500)
	var n int

	errChan := make(chan error, 1)
	defer func() {
		hd.Close()
		hd.Shutdown(divert.Both)

		for range errChan {
		}
	}()
	go func() {
		defer close(errChan)
		n, err = hd.Recv(buff, &addr)
		errChan <- err
	}()

	wg := &sync.WaitGroup{}
	defer wg.Wait()

	startConnection(wg, "tcp", fmt.Sprintf("%s:23342", minIP.String())) // IPv4查询

	// 5. 设置超时
	ctxTimeOut, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	select {
	case <-ctxTimeOut.Done():
		return 0, 0, 0, "", fmt.Errorf("操作超时")
	case err := <-errChan:
		if err != nil {
			return 0, 0, 0, "", err
		}
	}

	// 6. 获取MTU信息
	nw := addr.Network()
	interfaces, err := net.Interfaces()
	if err != nil {
		return 0, 0, 0, "", fmt.Errorf("获取网络接口失败: %w", err)
	}

	var mtu uint32
	for _, iface := range interfaces {
		if iface.Index == int(nw.IfIdx) {
			mtu = uint32(iface.MTU)
			break
		}
	}

	if len(buff[:n]) < header.IPv4MinimumSize {
		return 0, 0, 0, "", fmt.Errorf("小于IPv4MinimumSize")
	}

	if mtu == 0 {
		return 0, 0, 0, "", fmt.Errorf("获取网络接口mtu失败 nw.IfIdx:%d, nw.SubIfIdx:%d", nw.IfIdx, nw.SubIfIdx)
	}
	ipHeader := header.IPv4(buff[:n])

	// 1. 获取源 IP 的 [4]byte 数组
	srcAddr4 := ipHeader.SourceAddress().As4() // 类型：[4]byte
	ip := net.IP(srcAddr4[:])
	return nw.IfIdx, nw.SubIfIdx, mtu, ip.String(), nil
}

// startConnection 是一个辅助函数，用于启动一个 goroutine 进行网络连接
// 参数:
//
//	wg      - 等待组，用于等待 goroutine 完成
//	network - 网络协议类型，如 "tcp4" 或 "tcp6"
//	address - 目标地址和端口
func startConnection(wg *sync.WaitGroup, network, address string) {
	wg.Add(1)
	go func() {
		defer wg.Done()
		// 尝试进行网络连接，设置超时时间为 1 秒
		conn, err := net.DialTimeout(network, address, 2*time.Second)
		if err != nil {
			fmt.Printf("---------------net.DialTimeout(%q, %q, time.Second)-------------------%+v  ", network, address, err)
			return
		}
		// 关闭连接
		conn.Close()
	}()
}
