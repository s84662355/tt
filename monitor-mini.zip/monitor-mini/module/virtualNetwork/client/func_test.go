package client

import (
	"fmt"
	"testing"
)

// go test -run TestNewVMNetwork -v
func TestNewVMNetwork(t *testing.T) {
	fmt.Println(GetInterfaceIndex("10.0.0.0/8"))
	a, err := NewVMNetwork(
		"10.0.0.0/8",
		"10.0.0.21",
		"A",
		"dsadsa",
	)

	fmt.Println(a, err)

	select {}
}

// go test -run TestGetInterfaceIndex -v
func TestGetInterfaceIndex(t *testing.T) {
	fmt.Println(GetInterfaceIndex("10.0.0.0/8"))
}
