package virtualNetwork

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"

	"monitor/api"
	"monitor/controlCenter/common"
	"monitor/env"
	"monitor/log"
	"monitor/module/virtualNetwork/client"
)

type manager struct {
	ctx       context.Context
	moduleApi common.ModuleApi
}

func (m *manager) Start(cc common.ModuleApi) error {
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	defer cancel()
	m.moduleApi = cc

	wg := sync.WaitGroup{}
	defer wg.Wait()

	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	done := make(chan struct{}, 1)

	defer cancel()
	for {
		select {
		case <-cc.GetContext().Done():
			return nil
		case <-ticker.C:
			select {
			case done <- struct{}{}:
				wg.Add(1)
				go func() {
					defer wg.Done()
					m.startVirtualNetwork(cc.GetContext())
					<-done
				}()
			default:
				/* code */
			}

		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			default:
			}
		case moduleMsg, ok := <-m.moduleApi.GetModuleMsg(): // 模块之间的消息
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			default:
			}

		}
	}
}

func (m *manager) startVirtualNetwork(ctx context.Context) {
	IsTemporaryLogin := false
	if env.IsTemporaryLogin == 1 {
		IsTemporaryLogin = true
	}
	monitorVirtualIpResp, err := api.MonitorVirtualIp(
		fmt.Sprintf("%s-%s", env.CompanyId, env.MachineID),
		IsTemporaryLogin,
	)
	if err != nil {
		log.Errorf("[virtualNetwork] 获取虚拟ip失败 error:%+v", err)
		return
	}

	log.Infof("[virtualNetwork] 获取虚拟ip:%s", monitorVirtualIpResp.VirtualIp)
	a, err := client.NewVMNetwork(
		monitorVirtualIpResp.NetworkSegment,
		monitorVirtualIpResp.VirtualIp,
		env.CompanyId,
		env.MachineID,
		func(ctx context.Context) (net.Conn, error) {
			ctxTimeout, _ := context.WithTimeout(ctx, 5*time.Second)
			<-ctxTimeout.Done()
			monitorVirtualIpResp, err := api.MonitorVirtualIp(
				fmt.Sprintf("%s-%s", env.CompanyId, env.MachineID),
				IsTemporaryLogin,
			)
			if err != nil {
				log.Errorf("[virtualNetwork] 获取虚拟ip失败 error:%+v", err)
				return nil, err
			}

			var d net.Dialer
			conn, err := d.DialContext(ctx, "tcp", monitorVirtualIpResp.ForwardIp)
			if err != nil {
				log.Errorf("[virtualNetwork] 连接转发服务失败 error:%+v", err)
				return nil, err
			}
			if tcpConn, ok := conn.(*net.TCPConn); ok {
				// 启用TCP保活机制
				if err := tcpConn.SetKeepAlive(true); err != nil {
					fmt.Printf("设置TCP保活失败: %v\n", err)
				}
			}
			log.Infof("[virtualNetwork] 连接转发服务成功 %s  %s", monitorVirtualIpResp.ForwardIp, monitorVirtualIpResp.VirtualIp)
			return conn, nil
		},
		func(err error) {
			log.Errorf("[virtualNetwork] 虚拟网卡错误 error:%+v", err)
		},
	)
	if err != nil {
		log.Errorf("[virtualNetwork] 启动虚拟网络失败 error:%+v", err)
		return
	}

	defer a.Stop()
	<-ctx.Done()
}
