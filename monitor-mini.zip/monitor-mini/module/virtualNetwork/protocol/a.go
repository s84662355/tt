package protocol

const (
	MsgIdHandshakeRequest uint32 = iota + 1
	MsgIdHandshakeResponse
	MsgIdIpProtocolSend
	MsgIdIpProtocolGet
)

type HandshakeRequestData struct {
	OrganizationId string
	Mid            string
	Ip             string
}

type HandshakeResponseData struct {
	Ok  bool
	Msg string
}
