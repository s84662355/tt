package virtualNetwork

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "VirtualNetwork"

var handleMsgs []MsgId = []MsgId{}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn:    Strat,
			Msgs:       slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
			ModuleMsgs: []ModuleMsgId{},
		})
}
