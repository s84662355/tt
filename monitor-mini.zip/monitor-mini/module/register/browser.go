package register

import (
	_ "monitor/module/browser"
)
