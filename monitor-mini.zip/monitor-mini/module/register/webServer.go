package register

import (
	_ "monitor/module/webServer"
)
