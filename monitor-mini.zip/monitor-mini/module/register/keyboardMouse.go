package register

import (
	_ "monitor/module/keyboardMouse"
)
