package register

import (
	_ "monitor/module/tProxyRdpClient"
)
