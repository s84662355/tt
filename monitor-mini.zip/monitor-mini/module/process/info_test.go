package process

import (
	"context"
	"fmt"
	"testing"
)

// go test -v -run TestGetGPUUsage  -tags "dev"
func TestGetGPUUsage(t *testing.T) {
	info, err := getGPUUsage(context.Background())
	if err != nil {
		t.Error("getGPUUsage err: ", err)
		return
	}
	t.Log("gpu :", info)
	fmt.Println(getGPUInfo())
}

func TestGetCpuModelName(t *testing.T) {
	info, err := GetCpuModelName(context.Background())
	if err != nil {
		t.Error("GetCpuModelName err: ", err)
		return
	}

	t.Log("cpu model name :", info)
}

func TestGetVmTotal(t *testing.T) {
	info, err := GetVmTotal(context.Background())
	if err != nil {
		t.Error("GetVmTotal err: ", err)
		return
	}
	t.Log("vm total :", info)
}

func TestGetDiskTotal(t *testing.T) {
	info, err := GetDiskTotal(context.Background())
	if err != nil {
		t.Error("GetVmTotal err: ", err)
		return
	}
	t.Log("disk total :", info)
}

func TestGetWindowsVersion(t *testing.T) {
	info, err := GetWindowsVersion(context.Background())
	if err != nil {
		t.Error("GetWindowsVersion err: ", err)
		return
	}
	t.Log("host info :", info)
}

func TestGetMachineUUid(t *testing.T) {
	uuid, err := GetMachineUUid(context.Background())
	if err != nil {
		t.Error("TestGetMachineUUid err: ", err)
		return
	}
	t.Log("uuid :", uuid)
}
