package process

import (
	"slices"
	"strings"
	"sync"

	uProcess "monitor/utils/process"
)

var (
	disableApps     = []string{}
	disableAppslock sync.RWMutex
	enableApps      = []string{}
	enableAppslock  sync.RWMutex
)

func init() {}

func GetDisableApps() []string {
	disableAppslock.RLock()
	defer disableAppslock.RUnlock()
	return slices.Clone(disableApps)
}

func SetDisableApps(apps []string) {
	disableAppslock.Lock()
	defer disableAppslock.Unlock()
	disableApps = append(disableApps[:0], apps...)
	for i := 0; i < len(disableApps); i++ {
		disableApps[i] = strings.TrimSpace(disableApps[i])
	}
	disableApps = slices.DeleteFunc(disableApps, func(n string) bool {
		return n == ""
	})
	disableApps = slices.Compact(disableApps)
}

func GetEnableApps() []string {
	enableAppslock.RLock()
	defer enableAppslock.RUnlock()
	return slices.Clone(enableApps)
}

func SetEnableApps(apps []string) {
	enableAppslock.Lock()
	defer enableAppslock.Unlock()
	enableApps = append(enableApps[:0], enableApps...)
}

func CloseDisableApps() {
	apps := GetDisableApps()
	for _, app := range apps {
		///关闭更新程序
		uProcess.CloseProcess(func(ProcName string, FullPath string) bool {
			if strings.Contains(strings.ToLower(FullPath), strings.ToLower(app)) {
				return true
			}
			return false
		})
	}
}

func CloseProcessByName(name string) {
	///关闭更新程序
	uProcess.CloseProcess(func(ProcName string, FullPath string) bool {
		if strings.Contains(strings.ToLower(FullPath), strings.ToLower(name)) {
			return true
		}
		return false
	})
}
