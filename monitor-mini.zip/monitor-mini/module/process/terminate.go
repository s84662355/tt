package process

import (
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

func KillProcess(find func(ProcName string, FullPath string) bool) error {
	return killProcess(find)
}

func killProcess(find func(ProcName string, FullPath string) bool) error {
	snapshot, err := windows.CreateToolhelp32Snapshot(windows.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		return err
	}
	defer windows.CloseHandle(snapshot)
	var procEntry windows.ProcessEntry32
	procEntry.Size = uint32(unsafe.Sizeof(procEntry))
	if err = windows.Process32First(snapshot, &procEntry); err != nil {
		return err
	}
	for {
		procName := syscall.UTF16ToString(procEntry.ExeFile[:])

		handle, err := windows.OpenProcess(windows.PROCESS_QUERY_INFORMATION|windows.PROCESS_VM_READ|windows.PROCESS_TERMINATE, false, procEntry.ProcessID)
		if err != nil {
			err = windows.Process32Next(snapshot, &procEntry)
			if err != nil {
				return err
			}
			continue
		}

		var exePath [windows.MAX_PATH]uint16
		var exePathLen uint32 = windows.MAX_PATH
		err = windows.QueryFullProcessImageName(handle, 0, &exePath[0], &exePathLen)
		if err != nil {
			windows.CloseHandle(handle)
			err = windows.Process32Next(snapshot, &procEntry)
			if err != nil {
				return err
			}
			continue
		}

		fullPath := syscall.UTF16ToString(exePath[:exePathLen])

		if find(procName, fullPath) {
			windows.TerminateProcess(handle, 1)
		}

		windows.CloseHandle(handle)
		err = windows.Process32Next(snapshot, &procEntry)
		if err != nil {
			return err
		}
	}

	return nil
}
