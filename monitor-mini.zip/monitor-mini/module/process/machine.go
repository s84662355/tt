package process

import (
	"context"
	"errors"
	"fmt"
	"sync/atomic"
	"time"

	"github.com/shirou/gopsutil/cpu"
	"github.com/shirou/gopsutil/host"
	net2 "github.com/shirou/gopsutil/net"
	"github.com/shirou/gopsutil/v3/disk"
	"github.com/shirou/gopsutil/v3/mem"
	"monitor/protobuf"
	"monitor/utils/ip"
)

type Win32_BaseBoard struct {
	Product      string
	Manufacturer string
	SerialNumber string
	Version      string
}

var (
	trafficInUsage, trafficOutUsage       atomic.Uint64
	diskReadUsageByte, diskWriteUsageByte atomic.Uint64
)

func GetMachineMetric(ctx context.Context) (*protobuf.ReportMachinePerformanceRequest, error) {
	return getMachineMetric(ctx)
}

func getMachineMetric(ctx context.Context) (*protobuf.ReportMachinePerformanceRequest, error) {
	reportMachinePerformanceRequest := &protobuf.ReportMachinePerformanceRequest{
		CollectStartTs: time.Now().Unix(),
	}

	{ // cpu
		percent, err := cpu.PercentWithContext(ctx, 5*time.Second, false)
		if err != nil {
			return reportMachinePerformanceRequest, err
		}

		if len(percent) > 0 {
			reportMachinePerformanceRequest.CpuUsagePercentage = percent[0]
		} else {
			return nil, errors.New("采集到cpu数量为0")
		}
	}

	{ ///网络io
		netCounters, err := net2.IOCountersWithContext(ctx, false)
		if err != nil {
			return reportMachinePerformanceRequest, err
		}
		if len(netCounters) == 0 {
			return nil, errors.New("采集到网卡数量为0")
		}

		// uint64 trafficInUsage = 14; // 应用INT流量字节
		// uint64 trafficOutUsage = 15; // 应用OUT流量字节

		if trafficInUsage.Load() > 0 {
			reportMachinePerformanceRequest.TrafficInUsage = netCounters[0].BytesRecv - trafficInUsage.Swap(netCounters[0].BytesRecv)
		} else {
			trafficInUsage.Swap(netCounters[0].BytesRecv)
		}

		if trafficOutUsage.Load() > 0 {
			reportMachinePerformanceRequest.TrafficOutUsage = netCounters[0].BytesSent - trafficOutUsage.Swap(netCounters[0].BytesSent)
		} else {
			trafficOutUsage.Swap(netCounters[0].BytesSent)
		}

		// reportMachinePerformanceRequest.BandwidthReadUsageByte = netCounters[0].BytesSent
		// reportMachinePerformanceRequest.BandwidthWriteUsageByte = netCounters[0].BytesRecv
	}

	{ // 磁盘分区IO信息
		pCounters, err := disk.IOCountersWithContext(ctx)
		if err != nil {
			return nil, err
		}

		if len(pCounters) == 0 {
			return reportMachinePerformanceRequest, errors.New("采集到磁盘分区数量为0")
		}

		var (
			pReadBytes  uint64 = 0
			pWriteBytes uint64 = 0
		)

		for _, v := range pCounters {
			pReadBytes += v.ReadBytes
			pWriteBytes += v.WriteBytes
		}

		// 		  uint64 diskReadUsageByte = 3; // 磁盘读取了多少个字节
		// uint64 diskWriteUsageByte = 4; // 磁盘写入了多少个字节

		if diskReadUsageByte.Load() > 0 {
			reportMachinePerformanceRequest.DiskReadUsageByte = pReadBytes - diskReadUsageByte.Swap(pReadBytes)
		} else {
			diskReadUsageByte.Swap(pReadBytes)
		}

		if diskWriteUsageByte.Load() > 0 {
			reportMachinePerformanceRequest.DiskWriteUsageByte = pWriteBytes - diskWriteUsageByte.Swap(pWriteBytes)
		} else {
			diskWriteUsageByte.Swap(pWriteBytes)
		}

	}

	{ ///内存
		memInfo, err := mem.VirtualMemoryWithContext(ctx)
		if err != nil {
			return nil, err
		}
		reportMachinePerformanceRequest.MemoryUsagePercentage = memInfo.UsedPercent
	}

	{
		ipStr, err := ip.GetIpFromCache(ctx)
		if err != nil {
			return nil, err
		}
		reportMachinePerformanceRequest.MonitoryIp = ipStr
	}

	{
		ipAdapterInfo, err := ip.DefaultNIC()
		if err != nil {
			return nil, err
		}
		reportMachinePerformanceRequest.InnerIp = ipAdapterInfo.IpAddress
	}

	// {
	// 	gpus, err := getGPUUsage(ctx)
	// 	if err != nil {
	// 		fmt.Printf("获取gpu使用率 error:%v", err)
	// 	} else {
	// 		for _, gpu := range gpus {
	// 			reportMachinePerformanceRequest.GpuUsagePercentage += gpu
	// 		}
	// 	}

	// }

	reportMachinePerformanceRequest.Timestamp = time.Now().Unix()
	reportMachinePerformanceRequest.CollectEndTs = time.Now().Unix()
	return reportMachinePerformanceRequest, nil
}

func GetCpuModelName(ctx context.Context) (name string, err error) {
	info, err := cpu.InfoWithContext(ctx)
	if err != nil {
		err = fmt.Errorf("GetCpuModelName err: %w", err)
		return
	}

	if len(info) == 0 {
		err = fmt.Errorf("GetCpuModelName info count == 0  ")
		return
	}

	name = info[0].ModelName
	return
}

func GetVmTotal(ctx context.Context) (vm uint64, err error) {
	memInfo, err := mem.VirtualMemoryWithContext(ctx)
	if err != nil {
		err = fmt.Errorf("GetVmTotal err: %w", err)
		return
	}
	vm = memInfo.Total
	return
}

func GetDiskTotal(ctx context.Context) (total uint64, err error) {
	// #1 获取分区
	parts, err := disk.PartitionsWithContext(ctx, true)
	if err != nil {
		err = fmt.Errorf("GetDiskTotal err: %w", err)
		return
	}

	for _, part := range parts {
		usage, errr := disk.Usage((part.Mountpoint))
		if errr != nil {
			err = fmt.Errorf("GetDiskTotal part err: %w", errr)
			return
		}

		total += usage.Total
	}
	return
}

func GetWindowsVersion(ctx context.Context) (OsVersion string, err error) {
	h, err := host.InfoWithContext(ctx)
	if err != nil {
		err = fmt.Errorf("GetWindowsVersion err: %w", err)
		return
	}

	OsVersion = fmt.Sprintf("%s %s %s", h.Platform, h.PlatformVersion, h.KernelArch)
	return
}

func GetMachineUUid(ctx context.Context) (uuid string, err error) {
	h, err := host.InfoWithContext(ctx)
	if err != nil {
		err = fmt.Errorf("GetMachineUUid err: %w", err)
		return
	}

	uuid = h.HostID
	return
}
