package process

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "Process"

var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorReportMachinePerformance,
	MsgIdMonitorReportAppPerformance,
	MsgIdMonitorAppClose,
	MsgIdMonitorAppDisable,
	MsgIdMonitorAppEnable,
	MsgIdMonitorGetMonitorProjectInfo,  // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo, // 29 推送当前坐席版本
}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn:    Strat,
			Msgs:       slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
			ModuleMsgs: []ModuleMsgId{ModuleMsgIdReportAppTraffic},
		})
}
