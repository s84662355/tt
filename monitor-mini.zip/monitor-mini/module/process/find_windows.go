package process

import (
	"sync"
	"syscall"
	"unsafe"
)

var (
	user32                       = syscall.NewLazyDLL("user32.dll")
	procEnumWindows              = user32.NewProc("EnumWindows")
	procIsWindowVisible          = user32.NewProc("IsWindowVisible")
	procGetWindowRect            = user32.NewProc("GetWindowRect")
	procGetClientRect            = user32.NewProc("GetClientRect")
	procGetWindowTextW           = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW     = user32.NewProc("GetWindowTextLengthW")
	procGetWindowThreadProcessId = user32.NewProc("GetWindowThreadProcessId")
	procIsIconic                 = user32.NewProc("IsIconic")

	enumVisibleWindows = struct {
		mu        sync.Mutex
		GetWinPid func() map[uint32]struct{}
		callback  uintptr
		res       map[uint32]struct{}
	}{}
)

// 获取窗口标题长度
func GetWindowTextLength(hwnd syscall.Handle) int {
	ret, _, _ := procGetWindowTextLengthW.Call(uintptr(hwnd))
	return int(ret)
}

// 获取窗口标题
func GetWindowTitle(hwnd syscall.Handle) string {
	length := GetWindowTextLength(hwnd)
	if length == 0 {
		return ""
	}

	buf := make([]uint16, length+1)
	procGetWindowTextW.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&buf[0])),
		uintptr(length+1))

	return syscall.UTF16ToString(buf)
}

// RECT 结构体表示窗口的矩形区域
type RECT struct {
	Left   int32
	Top    int32
	Right  int32
	Bottom int32
}

// 判断窗口是否最小化（图标化）
func IsWindowIconic(hwnd syscall.Handle) (bool, error) {
	ret, _, err := procIsIconic.Call(uintptr(hwnd))
	return ret != 0, err
}

// GetWindowRect 获取窗口的屏幕坐标位置和大小
func GetWindowRect(hwnd syscall.Handle) (RECT, error) {
	var rect RECT
	r1, _, err := procGetWindowRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&rect)))
	if r1 == 0 {
		return rect, err
	}
	return rect, nil
}

// GetClientRect 获取窗口客户区的坐标和大小
func GetClientRect(hwnd syscall.Handle) (RECT, error) {
	var rect RECT
	r1, _, err := procGetClientRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(&rect)))
	if r1 == 0 {
		return rect, err
	}
	return rect, nil
}

func init() {
	enumVisibleWindows.callback = syscall.NewCallback(func(hwnd syscall.Handle, _ uintptr) uintptr {
		// 检查窗口是否可见
		isVisible, _, _ := procIsWindowVisible.Call(uintptr(hwnd))
		if isVisible == 0 {
			return 1 // 继续枚举其他窗口
		}

		if r, err := GetWindowRect(hwnd); err != nil {
			return 1 // 继续枚举其他窗口
		} else {

			if r.Left == 0 && r.Top == 0 && r.Right == 0 && r.Bottom == 0 {
				return 1 // 继续枚举其他窗口
			}

			if GetWindowTitle(hwnd) == "" {
				return 1 // 继续枚举其他窗口
			}

		}

		// 获取窗口所属进程 PID
		var pid uint32
		procGetWindowThreadProcessId.Call(
			uintptr(hwnd),
			uintptr(unsafe.Pointer(&pid)),
		)

		if pid == 0 {
			return 1
		}

		enumVisibleWindows.res[pid] = struct{}{}

		return 1
	})

	enumVisibleWindows.GetWinPid = func() map[uint32]struct{} {
		enumVisibleWindows.mu.Lock()
		defer func() {
			enumVisibleWindows.res = nil
			enumVisibleWindows.mu.Unlock()
		}()
		enumVisibleWindows.res = map[uint32]struct{}{}

		procEnumWindows.Call(enumVisibleWindows.callback, 0)
		return enumVisibleWindows.res
	}
}
