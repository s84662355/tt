package process

import (
	"time"

	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"
	"monitor/protocol"
)

func (m *manager) runCron() {
	m.cronT = cron.New(cron.WithSeconds())

	///上传进程数据
	time.AfterFunc(10*time.Second, func() {
		m.updateProcessMetric()
	})
	time.AfterFunc(10*time.Second, func() {
		m.updateReportMachineMetric()
	})

	m.cronT.Schedule(cron.Every(5*60*time.Second), cron.FuncJob(func() {
		m.updateProcessMetric()
	}))

	// 上传机器数据
	m.cronT.Schedule(cron.Every(60*time.Second), cron.FuncJob(func() {
		m.updateReportMachineMetric()
	}))

	// 定时关闭黑名单应用
	m.cronT.Schedule(cron.Every(30*time.Second), cron.FuncJob(func() {
		if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorAppStrategy) {
			return
		}
		CloseDisableApps()
	}))

	// // 14获取禁用应用
	m.cronT.Schedule(cron.Every(5*60*time.Second), cron.FuncJob(func() {
		m.moduleApi.WriteProtoMessage(protocol.MsgIdMonitorGetDisableApp, nil)
	}))

	time.AfterFunc(5*time.Second, func() {
		m.moduleApi.WriteProtoMessage(protocol.MsgIdMonitorGetDisableApp, nil)
	})

	m.cronT.Start()
}
