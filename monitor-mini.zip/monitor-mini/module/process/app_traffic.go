package process

import (
	"sync"

	"monitor/module/message"
)

var (
	appTrafficMap   = map[string]*message.AppTraffic{}
	appTrafficMapMu sync.Mutex
)

func init() {}

func addAppTraffic(k string, v *message.AppTraffic) {
	appTrafficMapMu.Lock()
	defer appTrafficMapMu.Unlock()

	if a, ok := appTrafficMap[k]; ok {
		a.InFlow += v.InFlow
		a.OutFlow += v.OutFlow
		a.EndTime = v.EndTime
	} else {
		appTrafficMap[k] = v
	}
}

func swapAppTraffic() map[string]*message.AppTraffic {
	appTrafficMapMu.Lock()
	defer appTrafficMapMu.Unlock()
	temp := appTrafficMap
	appTrafficMap = map[string]*message.AppTraffic{}
	return temp
}
