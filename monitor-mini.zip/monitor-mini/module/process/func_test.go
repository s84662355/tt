package process

import (
	"context"
	"fmt"
	"testing"
	"time"

	gowindows "github.com/elastic/go-windows"
)

// go test -v -run TestGetProcessList  -tags "dev"
func TestGetProcessList(t *testing.T) {
	// fmt.Println(enumVisibleWindows.GetWinPid())
	fmt.Println(getProcessList())
}

// go test   -cpuprofile  cpu.prof  -memprofile mem.prof -v -run TestGetAllProcessMetricOnTaskRunManagerOnProtobuf -tags "dev"
// go tool pprof ./cpu.prof
// go test -v -run TestGetAllProcessMetricOnTaskRunManagerOnProtobuf  -tags "dev"
func TestGetAllProcessMetricOnTaskRunManagerOnProtobuf(t *testing.T) {
	infos, err := GetAllProcessMetricOnTaskRunManagerOnProtobuf(context.Background(), 60*time.Second)
	if err != nil {
		t.Error("TestGetAllProcessMetricOnTaskRunManagerOnProtobuf err: ", err)
		return
	}
	t.Log("TestGetAllProcessMetricOnTaskRunManagerOnProtobuf :", len(infos.AppPerformance))
	t.Log("TestGetAllProcessMetricOnTaskRunManagerOnProtobuf :", infos.InnerIp)
	for _, info := range infos.AppPerformance {
		t.Log("TestGetAllProcessMetricOnTaskRunManagerOnProtobuf :", info)
	}
}

// go test -v -run TestGetFileVersionInfo  -tags "dev"
func TestGetFileVersionInfo(t *testing.T) {
	FullPath := "C:\\Windows\\System32\\svchost.exe"
	versionData, err := gowindows.GetFileVersionInfo(FullPath)
	if err != nil {
		t.Error(err)
		return
	}
	/*
		InternalName
		ProductName
		CompanyName
		LegalCopyright
		ProductVersion
		FileDescription
		LegalTrademarks
		PrivateBuild
		FileVersion
		OriginalFilename
		SpecialBuild

	*/
	ProductName, err := versionData.QueryValue("FileDescription")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(ProductName)
}
