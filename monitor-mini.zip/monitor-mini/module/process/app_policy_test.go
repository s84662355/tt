package process

import (
	"testing"
)

// go test -v -run TestCloseProcessByName  -tags "dev"
func TestCloseProcessByName(t *testing.T) {
	CloseProcessByName("Notepad.exe")
}
