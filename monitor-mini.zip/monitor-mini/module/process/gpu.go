package process

import (
	"context"
	"fmt"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"syscall"

	"github.com/go-ole/go-ole"
	"github.com/go-ole/go-ole/oleutil"
)

func getGPUUsage(ctx context.Context) ([]float64, error) {
	cmd := exec.CommandContext(ctx, "powershell",
		`Get-Counter "\GPU Engine(*)\Utilization Percentage" | 
		 Select-Object -ExpandProperty CounterSamples | 
		 Where-Object CookedValue -gt 0 | 
		 Format-Table Path, CookedValue -AutoSize`)

	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	output, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("执行命令失败: %v，输出: %s", err, string(output))
	}

	text := strings.TrimSpace(string(output))

	res := []float64{}

	// 匹配浮点数的正则表达式
	re := regexp.MustCompile(`\d+\.\d+`)

	// 查找所有匹配项
	matches := re.FindAllString(text, -1)

	// 输出结果
	fmt.Println("提取到的浮点数:", text)
	for _, match := range matches {
		// 将字符串转换为浮点数
		if f, err := strconv.ParseFloat(match, 64); err == nil {
			res = append(res, f)
		}
	}

	return res, nil
}

func getGPUInfo() (string, float64, error) {
	// 初始化 OLE 库
	err := ole.CoInitializeEx(0, ole.COINIT_MULTITHREADED)
	if err != nil {
		return "", 0, fmt.Errorf("初始化 COM 库失败: %v", err)
	}
	defer ole.CoUninitialize()

	// 创建 WMI 服务对象
	unknown, err := oleutil.CreateObject("WbemScripting.SWbemLocator")
	if err != nil {
		return "", 0, fmt.Errorf("创建 WMI 定位器失败: %v", err)
	}
	defer unknown.Release()

	wmi, err := unknown.QueryInterface(ole.IID_IDispatch)
	if err != nil {
		return "", 0, fmt.Errorf("获取 WMI 定位器接口失败: %v", err)
	}
	defer wmi.Release()

	// 连接到 WMI 服务
	serviceRaw, err := oleutil.CallMethod(wmi, "ConnectServer", nil, "root\\cimv2")
	if err != nil {
		return "", 0, fmt.Errorf("连接到 WMI 服务失败: %v", err)
	}
	service := serviceRaw.ToIDispatch()
	defer service.Release()

	// 查询 GPU 信息
	query := "SELECT * FROM Win32_VideoController"
	resultSetRaw, err := oleutil.CallMethod(service, "ExecQuery", query)
	if err != nil {
		return "", 0, fmt.Errorf("执行 WMI 查询失败: %v", err)
	}
	resultSet := resultSetRaw.ToIDispatch()
	defer resultSet.Release()

	// 遍历查询结果
	count, err := oleutil.GetProperty(resultSet, "Count")
	if err != nil {
		return "", 0, fmt.Errorf("获取结果数量失败: %v", err)
	}

	if count.Val > 0 {
		// 获取第一个 GPU
		itemRaw, err := oleutil.CallMethod(resultSet, "ItemIndex", 0)
		if err != nil {
			return "", 0, fmt.Errorf("获取 GPU 项目失败: %v", err)
		}
		gpu := itemRaw.ToIDispatch()
		defer gpu.Release()

		// 获取 GPU 名称
		name, err := oleutil.GetProperty(gpu, "Name")
		if err != nil {
			return "", 0, fmt.Errorf("获取 GPU 名称失败: %v", err)
		}

		// 获取 GPU 显存
		vram, err := oleutil.GetProperty(gpu, "AdapterRAM")
		if err != nil {
			return "", 0, fmt.Errorf("获取 GPU 显存失败: %v", err)
		}
		/// "GPU 名称    GPU 显存   GB
		return name.ToString(), float64(vram.Val) / (1024 * 1024 * 1024), nil

	}

	return "", 0, fmt.Errorf("未检测到 GPU")
}
