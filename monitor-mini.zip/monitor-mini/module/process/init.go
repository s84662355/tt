package process

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"
	. "monitor/env"
	"monitor/log"
	"monitor/module/message"
	"monitor/protobuf"
	. "monitor/protocol"
)

type manager struct {
	ctx                      context.Context
	moduleApi                common.ModuleApi
	cronT                    *cron.Cron
	processMetricMutex       sync.Mutex
	reportMachineMetricMutex sync.Mutex
}

func (m *manager) Start(cc common.ModuleApi) error {
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	defer cancel()
	m.moduleApi = cc

	m.runCron()
	defer func() {
		cancel()
		ctx := m.cronT.Stop()
		///等待定时任务完全结束
		<-ctx.Done()
	}()

	for {
		select {
		case <-cc.GetContext().Done():
			return nil
		case moduleMsg, ok := <-m.moduleApi.GetModuleMsg(): // 模块之间的消息

			if !ok {
				return nil
			}

			if moduleMsg == nil || moduleMsg.Data == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			case ModuleMsgIdReportAppTraffic:
				if m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportAppPerformanceStrategy) {
					if moduleMsg.Data != nil {
						if appTraffic, ok := moduleMsg.Data.(*message.AppTraffic); ok && appTraffic != nil {
							addAppTraffic(fmt.Sprint(appTraffic.Pid, ":", appTraffic.Exe), appTraffic)
						}
					}
				} else {
					swapAppTraffic()
				}
			}

		case moduleMsg, ok := <-m.moduleApi.GetMsg(): ///服务器的消息
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorReportMachinePerformance:
				m.updateReportMachineMetric()
			case MsgIdMonitorReportAppPerformance:
				m.updateProcessMetric()
			case MsgIdMonitorAppClose:
				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.CloseAppRequest); ok && mm != nil {
						m.closeAppClose(mm)
					}
				}
			case MsgIdMonitorAppDisable:
				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.DisableAppRequest); ok && mm != nil {
						m.appDisableMsg(mm)
					}
				}
			case MsgIdMonitorAppEnable:
				if moduleMsg.Data != nil {
					if mm, ok := moduleMsg.Data.(*protobuf.EnableAppRequest); ok && mm != nil {
						m.appEnableMsg(mm)
					}
				}

			default:
			}
		}
	}

	return nil
}

func (m *manager) updateProcessMetric() {
	if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportAppPerformanceStrategy) {
		swapAppTraffic()
		return
	}
	if !m.processMetricMutex.TryLock() {
		return
	}
	defer m.processMetricMutex.Unlock()
	log.Info("[开始上传进程数据]")

	reportRunningAppPerformanceRequest, err := GetAllProcessMetricOnTaskRunManagerOnProtobuf(m.ctx, 60*time.Second)
	if err != nil {
		log.Error("[开始上传进程数据] Cron GetAllProcessMetric  err: ", err)
		return
	}
	reportRunningAppPerformanceRequest.Version = Version

	err = m.moduleApi.WriteProtoMessage(
		MsgIdMonitorReportAppPerformance,
		reportRunningAppPerformanceRequest,
	)
	if err != nil {
		log.Error("[开始上传进程数据] 失败  ", err)
	}
}

func (m *manager) updateReportMachineMetric() {
	if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportMachinePerformanceStrategy) {
		swapAppTraffic()
		return
	}

	if !m.reportMachineMetricMutex.TryLock() {
		return
	}
	defer m.reportMachineMetricMutex.Unlock()

	log.Info("[开始上传机器数据]")
	ctxTimeOut, cancel := context.WithTimeout(m.ctx, 20*time.Second)
	defer cancel()
	machineMetric, err := GetMachineMetric(ctxTimeOut)
	fmt.Println(machineMetric)
	if err != nil {
		log.Error("[开始上传机器数据] Cron GetMachineMetric  err: ", err)
		return
	}
	machineMetric.Version = Version
	err = m.moduleApi.WriteProtoMessage(
		MsgIdMonitorReportMachinePerformance,
		machineMetric,
	)
	if err != nil {
		log.Error("[开始上传机器数据]  ", err)
	}
}

func (m *manager) closeAppClose(clientRequest *protobuf.CloseAppRequest) {
	if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorAppStrategy) {
		return
	}

	AppName := strings.TrimSpace(clientRequest.AppName)
	log.Info("[关闭指定应用] MsgIdMonitorAppClose 关闭应用  ", clientRequest.AppName)
	if AppName != "" {
		CloseProcessByName(AppName)
	}
}

func (m *manager) appDisableMsg(clientRequest *protobuf.DisableAppRequest) {
	if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorAppStrategy) {
		return
	}

	log.Info("[禁止指定应用] MsgIdMonitorAppDisable    ", clientRequest.AppName)
	SetDisableApps(clientRequest.AppName)
	CloseDisableApps()
}

func (m *manager) appEnableMsg(clientRequest *protobuf.EnableAppRequest) {
	log.Info("[指定应用白名单] MsgIdMonitorAppEnable    ", clientRequest.AppName)
	SetEnableApps(clientRequest.AppName)
}
