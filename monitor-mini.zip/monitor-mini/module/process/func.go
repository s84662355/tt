package process

import (
	"context"
	"fmt"
	"path/filepath"
	"slices"
	"sync/atomic"
	"time"
	//"runtime"
	gowindows "github.com/elastic/go-windows"
	"github.com/shirou/gopsutil/process"
	"monitor/protobuf"
	"monitor/utils/ip"
	uprocess "monitor/utils/process"
	"monitor/utils/taskRunManager"
)

type Process struct {
	*process.Process
	ProcessID            uint32
	ParentProcessID      uint32
	FullPath             string
	IsRunning            bool
	CpuPercentPercentage float64
	MemInfoPercentage    float64
	DiskReadkb           uint64
	DiskWritekb          uint64
	StartTs              int64 //
	CollectStartTs       int64 // 采集开始时间戳（秒）
	CollectEndTs         int64 // 采集结束时间戳（秒）
	IsCheck              atomic.Bool
	ProductName          string
	IsStatistics         bool
}

func GetProcessList() ([]*Process, error) {
	return getProcessList()
}

func getProcessList() ([]*Process, error) {
	plist, err := process.Processes()
	if len(plist) == 0 {
		return nil, err
	}
	// uprocess.GetPpids()
	ppidMap, err := uprocess.GetPpids()
	if len(ppidMap) == 0 {
		return nil, err
	}
	data := make([]*Process, 0, len(plist))
	for _, procEntry := range plist {
		FullPath, _ := procEntry.Exe()
		//  ParentProcessID, _ := procEntry.Ppid()
		ParentProcessID, ok := ppidMap[uint32(procEntry.Pid)]
		if !ok {
			ParentProcessID = 0
		}
		if FullPath != "" {
			data = append(data, &Process{
				Process:         procEntry,
				ProcessID:       uint32(procEntry.Pid),
				ParentProcessID: uint32(ParentProcessID),
				FullPath:        filepath.Join(FullPath),
			})
		}
	}
	return data, nil
}

var collectStartTs = time.Now()

// 整合进程信息到protobuf
func GetAllProcessMetricOnTaskRunManagerOnProtobuf(
	ctx context.Context,
	timeOut time.Duration,
) (*protobuf.ReportRunningAppPerformanceRequest, error) {
	processList, err := getAllProcessMetricOnGetSpecifyQuantityTaskRunManager(ctx, timeOut)
	if err != nil {
		return nil, err
	}

	processList = slices.DeleteFunc(processList, func(pProcess *Process) bool {
		return !(pProcess.IsCheck.Load() && pProcess.IsRunning)
	})

	appTrafficMap := swapAppTraffic()

	ipStr, _ := ip.GetIpFromCache(ctx)
	reportRunningAppPerformanceRequest := &protobuf.ReportRunningAppPerformanceRequest{}
	for _, pProcess := range processList {
		///fmt.Println(pProcess.FullPath, pProcess.ProcessID, pProcess.ParentProcessID)
		///只把完成检测的放进去
		var TrafficInUsage, TrafficOutUsage uint64
		var CollectStartTs, CollectEndTs int64

		if appTraffic, ok := appTrafficMap[fmt.Sprint(pProcess.ProcessID, ":", pProcess.FullPath)]; ok && appTraffic != nil {
			TrafficInUsage = appTraffic.InFlow
			TrafficOutUsage = appTraffic.OutFlow
			CollectStartTs = appTraffic.StartTime.Unix()
			CollectEndTs = appTraffic.EndTime.Unix()
		} else {
			CollectStartTs = collectStartTs.Unix()
			CollectEndTs = time.Now().Unix()
		}

		reportRunningAppPerformanceRequest.AppPerformance = append(reportRunningAppPerformanceRequest.AppPerformance, &protobuf.ReportRunningAppPerformance{
			CpuUsagePercentage:    pProcess.CpuPercentPercentage,
			MemoryUsagePercentage: pProcess.MemInfoPercentage,
			DiskReadUsageByte:     pProcess.DiskReadkb,
			DiskWriteUsageByte:    pProcess.DiskWritekb,
			Timestamp:             time.Now().Unix(),
			AppName:               pProcess.FullPath,
			StartTs:               pProcess.StartTs,
			ProcessId:             uint64(pProcess.ProcessID),
			ParentProcessId:       uint64(pProcess.ParentProcessID),
			CollectStartTs:        CollectStartTs,
			CollectEndTs:          CollectEndTs,
			ProductName:           pProcess.ProductName,
			TrafficInUsage:        TrafficInUsage,
			TrafficOutUsage:       TrafficOutUsage,
		})
	}

	ipAdapterInfo, err := ip.DefaultNIC()
	if err != nil {
		return nil, err
	}

	reportRunningAppPerformanceRequest.MonitoryIp = ipStr
	reportRunningAppPerformanceRequest.InnerIp = ipAdapterInfo.IpAddress

	collectStartTs = time.Now()
	return reportRunningAppPerformanceRequest, nil
}

type ProcessIDTree struct {
	Data map[uint32]*ProcessIDTree
}

func findTheTopParentPid(pid uint32, processList []*Process) uint32 {
	for _, p := range processList {
		if p.ProcessID == pid {
			if p.ParentProcessID != 0 {
				ppid := findTheTopParentPid(p.ParentProcessID, processList)
				if ppid == 0 {
					return p.ProcessID
				}
				return ppid
			} else {
				return p.ProcessID
			}
		}
	}
	return 0
}

func CreateProcessIDTree(pid uint32, data *ProcessIDTree, processList []*Process) {
	for _, p := range processList {
		if p.ParentProcessID == pid {
			if data.Data == nil {
				data.Data = make(map[uint32]*ProcessIDTree)
			}
			data.Data[p.ProcessID] = &ProcessIDTree{}
			CreateProcessIDTree(p.ProcessID, data.Data[p.ProcessID], processList)
		}
	}
}

func SetProcessStatistics(pid uint32, ptree *ProcessIDTree, processList []*Process) {
	for _, p := range processList {
		if p.ProcessID == pid {
			p.IsStatistics = true
			if ptree.Data != nil {
				for pid, ptree := range ptree.Data {
					SetProcessStatistics(pid, ptree, processList)
				}
			}

		}
	}
}

// 并发获取进程信息
func getAllProcessMetricOnGetSpecifyQuantityTaskRunManager(
	ctx context.Context,
	timeOut time.Duration,
) ([]*Process, error) {
	processList, err := getProcessList()

	if err != nil && len(processList) == 0 {
		return nil, err
	}

	winpids := enumVisibleWindows.GetWinPid()

	FullPathSlices := []string{}
	for pid := range winpids {
		for _, p := range processList {
			if p.ProcessID == pid {
				FullPathSlices = append(FullPathSlices, p.FullPath)
				FullPathSlices = slices.Compact(FullPathSlices)
				break
			}
		}
	}

	pProcessList := []*Process{}

	for _, p := range processList {
		for _, FullPath := range FullPathSlices {
			if p.FullPath == FullPath {
				pProcessList = append(pProcessList, p)
				pProcessList = slices.Compact(pProcessList)
				break
			}
		}

		// if p.IsStatistics {
		// 	pProcessList = append(pProcessList, p)
		// }
	}

	count := len(pProcessList) / 2
	if count == 0 {
		count = 1
	}

	if count > 100 {
		count = 100
	}

	resChan := taskRunManager.RunTaskGetSpecifyQuantityResultTimeOutContext[*Process, *Process](
		ctx,
		timeOut,
		pProcessList,
		func(ctx context.Context, pProcess *Process) (*Process, bool) {
			if err := getProcessMetric(
				pProcess.Process,
				ctx,
				pProcess,
			); err != nil {
				return nil, false
			}

			return pProcess, true
		},
		len(processList),
		count,
	)

	results := make([]*Process, 0, len(pProcessList))
	for m := range resChan {
		results = append(results, m)
	}

	return results, nil
}

func getProcessMetric(
	p *process.Process,
	ctx context.Context,
	ProcessInfo *Process,
) error {
	ProcessInfo.IsRunning, _ = p.IsRunningWithContext(ctx)

	if !ProcessInfo.IsRunning {
		return fmt.Errorf("getProcessMetric 程序is not running ")
	}

	// ProcessInfo.CollectStartTs = time.Now().Unix() // 采集开始时间戳（秒）

	{
		// 5秒内cpu的使用率
		cpuPercent, err := p.PercentWithContext(ctx, time.Second*5) // float64
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProcessInfo.CpuPercentPercentage = cpuPercent
	}

	{ ///磁盘
		prevIO, err := p.IOCountersWithContext(ctx)
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProcessInfo.DiskReadkb = prevIO.ReadBytes
		ProcessInfo.DiskWritekb = prevIO.WriteBytes
	}

	{
		memInfoPercentage, err := p.MemoryPercentWithContext(ctx) // float32
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProcessInfo.MemInfoPercentage = float64(memInfoPercentage)
	}

	{ ///进程启动时间
		startTs, err := p.CreateTimeWithContext(ctx)
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProcessInfo.StartTs = startTs / 1000
	}

	{ // 进程文件产品
		FullPath, _ := p.Exe()
		versionData, err := gowindows.GetFileVersionInfo(FullPath)
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProductName, err := versionData.QueryValue("FileDescription")
		if err != nil {
			return fmt.Errorf("getProcessMetric err = %w", err)
		}
		ProcessInfo.ProductName = ProductName
	}

	// ProcessInfo.CollectEndTs = time.Now().Unix() // 采集结束时间戳（秒）
	ProcessInfo.IsCheck.Swap(true)

	FullPath, _ := p.Exe()
	versionData, err := gowindows.GetFileVersionInfo(FullPath)
	if err != nil {
		return err
	}
	ProductName, err := versionData.QueryValue("ProductName")
	if err != nil {
		return err
	}
	ProcessInfo.ProductName = ProductName
	return nil
}
