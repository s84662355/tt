package keyboardMouse

import (
	"bytes"
	"fmt"
	"image"
	"image/draw"
	"image/jpeg"
	"image/png"
	"slices"
	"time"

	"github.com/kbinani/screenshot"

	"monitor/controlCenter/common"

	"monitor/log"
	"monitor/protobuf"
	. "monitor/protocol"
)

func (m *manager) reportScreenshot() {
	m.moduleApi.WriteProtoMessage(MsgIdMonitorGetCollectBehaviorInfo, nil)
	log.Infof("[keyboardMouse]准备上传屏幕截图数据")
	log.Infof("[keyboardMouse] 数据433434AAA", m.isBehaviorOpt.Load(), m.isScreenshot.Load())
	if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorScreenshot) {
		log.Errorf("[keyboardMouse]  没有截屏权限")
		return
	}
	log.Infof("[keyboardMouse] 数据AAAA", m.isBehaviorOpt.Load(), m.isScreenshot.Load())
	if m.isBehaviorOpt.Load() && m.isScreenshot.Swap(false) {
		log.Infof("[keyboardMouse]确认可以上传屏幕截图数据")
		if m.screenshotMutex.TryLock() {
			log.Infof("[keyboardMouse]获取上传屏幕截图数据的锁")
			m.wg.Add(1)
			go func() {
				defer m.wg.Done()
				defer m.screenshotMutex.Unlock()
				m.screenshot()
			}()
		}
	}
}

func (m *manager) screenshot() {
	// 获取显示器数量
	numDisplays := screenshot.NumActiveDisplays()
	//	data := make([]*protobuf.MonitorBehaviorInfo, numDisplays)
	data := make([][]byte, numDisplays)
	for i := 0; i < numDisplays; i++ {
		d := m.screenshotByIndex(i)
		if d != nil {
			data[i] = d
		} else { ///重新再截取
			d := m.screenshotByIndex(i)
			if d != nil {
				data[i] = d
			}
		}

	}

	data = slices.DeleteFunc(data, func(n []byte) bool {
		return n == nil
	})

	if len(data) != numDisplays {
		log.Errorf("[keyboardMouse]截屏  截取屏幕数量%d与屏幕数量%d不符合", len(data), numDisplays)
	}

	if len(data) > 0 {
		log.Infof("[keyboardMouse]合并屏幕截图数据")

		imgData, title, err := MergeImagesVertically(data)
		if err != nil {
			log.Errorf("[keyboardMouse]合并屏幕截图数据失败 error:%v", err)
			return
		}

		if imgData == nil {
			log.Errorf("[keyboardMouse]合并屏幕截图数据失败 图片数据为空")
			return
		}

		m.moduleApi.WriteProtoMessage(MsgIdMonitorReportDeviceBehaviorInfo, &protobuf.MonitorBehaviorInfoReq{
			MonitorBehaviorInfo: []*protobuf.MonitorBehaviorInfo{
				{
					PictureName: fmt.Sprintf("%s_screen.%s", time.Now().Format("20060102150405"), title),
					PictureData: imgData, // 获取二进制数据
					Timestamp:   time.Now().Unix(),
				},
			},
		})
	}
}

func (m *manager) screenshotByIndex(i int) []byte {
	// 获取显示器边界（分辨率等信息）
	bounds := screenshot.GetDisplayBounds(i)
	// 捕获指定显示器屏幕内容
	img, err := screenshot.CaptureRect(bounds)
	if err != nil {
		log.Errorf("[keyboardMouse]截屏  捕获屏幕%d失败 error:%+v", i, err)
		return nil
	}

	var buf bytes.Buffer
	err = jpeg.Encode(&buf, img, &jpeg.Options{Quality: 100})
	if err != nil {
		log.Errorf("[keyboardMouse]截屏  屏幕%d编码失败失败 error:%+v", i, err)
		return nil
	}

	return buf.Bytes()
}

// func (m *manager) screenshotByIndex(i int) *protobuf.MonitorBehaviorInfo {
// 	// 获取显示器边界（分辨率等信息）
// 	bounds := screenshot.GetDisplayBounds(i)
// 	// 捕获指定显示器屏幕内容
// 	img, err := screenshot.CaptureRect(bounds)
// 	if err != nil {
// 		log.Errorf("[keyboardMouse]截屏  捕获屏幕%d失败 error:%+v", i, err)
// 		return nil
// 	}

// 	var buf bytes.Buffer
// 	err = jpeg.Encode(&buf, img, &jpeg.Options{Quality: 75})
// 	if err != nil {
// 		log.Errorf("[keyboardMouse]截屏  屏幕%d编码失败失败 error:%+v", i, err)
// 		return nil
// 	}

// 	return &protobuf.MonitorBehaviorInfo{
// 		PictureName: fmt.Sprintf("%s_screen_%d.jpg", time.Now().Format("20060102150405"), i),
// 		PictureData: buf.Bytes(), // 获取二进制数据
// 		Timestamp:   time.Now().Unix(),
// 	}
// }

// MergeImagesVertically 纵向合并多张图片的字节数据
func MergeImagesVertically(imgBytesList [][]byte) ([]byte, string, error) {
	var images []image.Image
	var format string

	// 解码所有图片
	for _, imgBytes := range imgBytesList {
		img, f, err := image.Decode(bytes.NewReader(imgBytes))
		if err != nil {
			return nil, "", err
		}
		if format == "" {
			format = f // 使用第一张图片的格式作为输出格式
		}
		images = append(images, img)
	}

	if len(images) == 0 {
		return nil, "", nil
	}

	// 计算合并后图片的总高度和最大宽度
	maxWidth := 0
	totalHeight := 0
	for _, img := range images {
		bounds := img.Bounds()
		width := bounds.Dx()
		height := bounds.Dy()
		if width > maxWidth {
			maxWidth = width
		}
		totalHeight += height
	}

	// 创建合并后的图片
	result := image.NewRGBA(image.Rect(0, 0, maxWidth, totalHeight))
	currentY := 0

	// 纵向合并图片
	for _, img := range images {
		bounds := img.Bounds()
		width := bounds.Dx()
		height := bounds.Dy()

		// 居中放置图片（如果宽度不足最大宽度）
		xOffset := (maxWidth - width) / 2

		draw.Draw(result, image.Rect(xOffset, currentY, xOffset+width, currentY+height),
			img, bounds.Min, draw.Over)
		currentY += height
	}

	// 编码合并后的图片为字节流
	var buf bytes.Buffer
	var err error

	switch format {
	case "jpeg", "jpg":
		err = jpeg.Encode(&buf, result, &jpeg.Options{Quality: 100})
	case "png":
		err = png.Encode(&buf, result)
	default:
		// 默认使用 JPEG 格式
		err = jpeg.Encode(&buf, result, &jpeg.Options{Quality: 100})
		format = "jpeg"
	}

	if err != nil {
		return nil, "", err
	}

	return buf.Bytes(), format, nil
}
