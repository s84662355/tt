package keyboardMouse

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "KeyboardMouse"

var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorGetMonitorProjectInfo,    // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo,   // 29 推送当前坐席版本
	MsgIdMonitorReportDeviceBehaviorInfo, // 31 上报设备行为截图
	MsgIdMonitorOptCollectBehaviorInfo,   // 32 是否采集设备行为截图 1: 采集；2: 不采集
	MsgIdMonitorGetCollectBehaviorInfo,   // 33 获取是否采集设备行为截图
}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn: Strat,
			Msgs:    slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
		})
}
