package keyboardMouse

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"
	"monitor/log"
	"monitor/utils/gohook/pkg/keyboard"
	"monitor/utils/gohook/pkg/mouse"

	//	"monitor/env"
	"monitor/protobuf"
	. "monitor/protocol"
)

type manager struct {
	ctx                context.Context
	moduleApi          common.ModuleApi
	cronT              *cron.Cron
	isWorking          atomic.Bool
	isScreenshot       atomic.Bool
	isBehaviorOpt      atomic.Bool
	workCollectStartTs atomic.Int64
	screenshotMutex    sync.Mutex
	wg                 sync.WaitGroup
}

func (m *manager) Start(cc common.ModuleApi) error {
	defer func() {
		fmt.Println("----------------keyboardMouse关闭完成---------------------")
	}()
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	defer cancel()
	defer m.wg.Wait()

	m.moduleApi = cc
	m.cronT = cron.New(cron.WithSeconds())
	m.cronT.Start()
	defer func() {
		ctx := m.cronT.Stop()
		///等待定时任务完全结束
		<-ctx.Done()
	}()
	m.workCollectStartTs.Store(time.Now().Unix())
	time.AfterFunc(15*time.Second, func() {
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetCollectBehaviorInfo, nil)
	})
	m.cronT.Schedule(cron.Every(30*time.Second), cron.FuncJob(func() {
		m.reportMonitorActiveInfo()
		m.moduleApi.WriteProtoMessage(MsgIdMonitorGetCollectBehaviorInfo, nil)
	}))

	m.cronT.Schedule(cron.Every(10*60*time.Second), cron.FuncJob(func() {
		m.reportScreenshot()
	}))

	mhook := mouse.New()
	mouseChan, err := mhook.Install()
	if err != nil {
		return fmt.Errorf("[keyboardMouse] mouse.Install err=%+v", err)
	}
	defer func() {
		mhook.Uninstall()
		fmt.Println("---------------- Mouse钩子关闭完成---------------------")
	}()

	khook := keyboard.New()
	keyboardChan, err := khook.Install()
	if err != nil {
		return fmt.Errorf("[keyboardMouse] keyboard.Install err=%+v", err)
	}
	defer func() {
		khook.Uninstall()
		fmt.Println("---------------- 键盘钩子关闭完成---------------------")
	}()

	defer cancel()
	for {
		select {
		case <-cc.GetContext().Done():
			fmt.Println("----------------keyboardMouse开始关闭---------------------")
			return nil

		case <-mouseChan:
			m.isWorking.Store(true)
			m.isScreenshot.Store(true)
		case <-keyboardChan:
			m.isWorking.Store(true)
			m.isScreenshot.Store(true)
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorOptCollectBehaviorInfo:
				if moduleMsg.Data != nil {
					// 类型断言，确保数据类型正确
					if mm, ok := moduleMsg.Data.(*protobuf.MonitorBehaviorOpt); ok && mm != nil {
						log.Infof("[keyboardMouse]  MonitorBehaviorOpt Data = %+v", mm)
						if mm.OptType == 1 {
							m.isBehaviorOpt.Store(true)
						} else {
							m.isBehaviorOpt.Store(false)
						}
					}
				}
			default:
			}
		}
	}
}

func (m *manager) reportMonitorActiveInfo() {
	IsActive := 2
	if m.isWorking.Swap(false) {
		IsActive = 1
	}
	if m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportActiveInfoStrategy) {
		log.Infof("[keyboardMouse]上传鼠标键盘活跃数据 IsActive:	%d", IsActive)
		r := &protobuf.ReportMonitorActiveInfoReq{
			CollectStartTs: m.workCollectStartTs.Swap(time.Now().Unix()),
			CollectEndTs:   time.Now().Unix(),
			Timestamp:      time.Now().Unix(),
			IsActive:       int64(IsActive),
		}

		m.moduleApi.WriteProtoMessage(MsgIdMonitorReportActiveInfo, r)
	}
}
