package tProxy

import (
	"fmt"
	"io"
	"regexp"
	"sync"

	//"go.uber.org/zap"
	"context"
	"time"

	"monitor/gvisor.dev/gvisor/pkg/tcpip/adapters/gonet"
	"monitor/gvisor.dev/gvisor/pkg/tcpip/transport/tcp"
	"monitor/gvisor.dev/gvisor/pkg/waiter"
)

// transportProtocolHandler 处理TCP转发请求
// 参数r是TCP转发请求对象
func (m *Manager) transportProtocolHandler(r *tcp.ForwarderRequest) {
	// 创建等待队列，用于TCP端点的异步操作
	wq := waiter.Queue{}

	// 创建TCP端点(Endpoint)
	ep, tcperr := r.CreateEndpoint(&wq)
	if tcperr != nil {
		// log.Error("创建TCP端点失败", zap.Any("error", tcperr))
		r.Complete(true) // 标记请求完成(带错误)
		return
	}
	defer ep.Close()        // 确保函数退出时关闭端点
	defer r.Complete(false) // 标记请求成功完成

	// 将gVisor的TCP端点包装为Go标准的net.Conn接口
	cep := gonet.NewTCPConn(&wq, ep)
	defer cep.Close() // 确保函数退出时关闭连接
	ctx, _ := context.WithTimeout(m.tcm.Context(), 50*time.Millisecond)
	<-ctx.Done()
	dataByte := make([]byte, 2000)
	if n, err := cep.Read(dataByte); err != nil {
		return
	} else {

		id := r.ID()
		domain := regexpDomain(string(dataByte[:n]))
		target, err := m.proxyConfig.ProxyConn(
			m.tcm.Context(),
			domain,
			id.LocalAddress.String(),
			id.LocalPort,
		)
		if err != nil {
			return
		}
		defer target.Close() // 确保函数退出时关闭目标连接

		if _, err := target.Write(dataByte[:n]); err != nil {
			return
		}

		// 创建错误通道，用于协程间通信
		errChan := make(chan error, 2)
		defer close(errChan) // 确保函数退出时关闭通道

		// 使用WaitGroup等待两个协程完成
		wg := &sync.WaitGroup{}
		// 等待所有协程完成
		defer wg.Wait()

		wg.Add(2) // 需要等待2个协程

		// 启动协程1：从目标连接读取数据并写入客户端端点
		go func() {
			defer wg.Done()
			_, err := io.Copy(cep, target)
			errChan <- err // 发送可能发生的错误
		}()

		// 启动协程2：从客户端端点读取数据并写入目标连接
		go func() {
			defer wg.Done()
			_, err = io.Copy(target, cep)
			errChan <- err // 发送可能发生的错误
		}()

		// 等待以下两种情况之一发生：
		select {
		case err := <-errChan: // 1. 任一协程发生错误
			if err != nil {
				// log.Error("数据传输错误", zap.Any("error", err))
			}
		case <-m.tcm.Context().Done(): // 2. 上下文被取消

		}

		// 关闭连接
		cep.Close()
		target.Close()

		fmt.Println("连接代理结束")
	}
}

// regexpDomain 函数用于从给定的文本中提取域名。
// 它使用正则表达式匹配域名模式，如果找到匹配项，则返回第一个匹配到的域名；
// 如果没有找到匹配项，则返回空字符串。
// 参数：
//   - text: 待搜索域名的文本字符串
//
// 返回值：
//   - string: 匹配到的第一个域名，如果没有匹配项则返回空字符串
func regexpDomain(text string) string {
	// 编译一个正则表达式，用于匹配域名模式
	// 该正则表达式匹配由字母、数字、点和连字符组成，且以至少两个字母的顶级域名结尾的字符串
	domainRegex := regexp.MustCompile(`([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})`)
	// 在给定的文本中查找所有匹配该正则表达式的字符串，并返回捕获组的信息
	// -1 表示查找所有匹配项
	matches := domainRegex.FindAllStringSubmatch(text, -1)
	// 遍历所有匹配结果
	for _, match := range matches {
		// 遍历每个匹配结果中的捕获组
		for _, v := range match {
			// 返回第一个匹配到的域名
			return v
		}
	}
	// 如果没有找到匹配的域名，返回空字符串
	return ""
}
