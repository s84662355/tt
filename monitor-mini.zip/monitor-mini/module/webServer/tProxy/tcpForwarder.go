package tProxy

import (
	"monitor/gvisor.dev/gvisor/pkg/tcpip/stack"
)

func (m *Manager) HandleTcpPacket(id stack.TransportEndpointID, pkt stack.PacketBufferPtr) bool {
	return m.tcpForwarder.HandlePacket(id, pkt)
}
