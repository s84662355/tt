package ss

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"strings"
	"testing"
	"time"
)

// go test -run TestSs -v
func TestSs(t *testing.T) {
	_, err := GetConn(
		context.Background(),
		"8.148.183.111:14016",
		"chacha20-ietf-poly1305",
		"token:cc5798294583f68735d3af536651d30bf647d6389ffdfb38d422944089c2c9d2",
		"www.google.com:443",
	)
	if err != nil {
		fmt.Println(err)
		return
	}
}

// 自定义拨号器使用GetConn函数
type SSDialer struct {
	Server   string
	Method   string
	Password string
	Timeout  time.Duration
}

func (d *SSDialer) DialContext(ctx context.Context, network, addr string) (net.Conn, error) {
	// 为防止ctx超时，我们添加一个超时检查
	if deadline, ok := ctx.Deadline(); ok {
		timeoutCtx, cancel := context.WithDeadline(context.Background(), deadline)
		defer cancel()
		ctx = timeoutCtx
	}

	// 使用GetConn获取Shadowsocks代理连接
	return GetConn(ctx, d.Server, d.Method, d.Password, addr)
}

// go test -run TestSssss -v
func TestSssss(t *testing.T) {
	// Shadowsocks服务器配置
	server := "8.148.183.111:14016"                                                      // 替换为您的Shadowsocks服务器地址
	method := "chacha20-ietf-poly1305"                                                   // 替换为您使用的加密方式
	password := "token:cc5798294583f68735d3af536651d30bf647d6389ffdfb38d422944089c2c9d2" // 替换为您的密码

	// 创建自定义拨号器
	dialer := &SSDialer{
		Server:   server,
		Method:   method,
		Password: password,
		Timeout:  10 * time.Second,
	}

	// 方法一：使用http.Transport自动处理HTTP请求
	fmt.Println("===== 使用 http.Transport 发送请求 =====")
	sendRequestWithTransport(dialer)

	// 方法二：手动构建HTTP请求并通过自定义连接发送
	fmt.Println("\n===== 手动发送 HTTP 请求 =====")
	sendManualRequest(dialer)
}

// 使用http.Transport方式发送请求
func sendRequestWithTransport(dialer *SSDialer) {
	// 创建自定义Transport
	transport := &http.Transport{
		DialContext: dialer.DialContext,
		// 其他可选配置
		MaxIdleConns:          100,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
	}

	// 创建HTTP客户端
	client := &http.Client{
		Transport: transport,
		Timeout:   30 * time.Second,
	}

	// 发起HTTP GET请求到百度
	resp, err := client.Get("http://www.baidu.com")
	if err != nil {
		log.Fatalf("请求失败: %v", err)
	}
	defer resp.Body.Close()

	// 读取并显示响应
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("读取响应失败: %v", err)
	}

	fmt.Printf("状态码: %d\n", resp.StatusCode)
	fmt.Printf("响应头: %v\n", resp.Header)
	// 只显示前200个字符避免输出过多
	fmt.Printf("响应内容: %s...\n", string(body[:min(len(body), 200)]))
}

// 手动构建HTTP请求并发送
func sendManualRequest(dialer *SSDialer) {
	targetAddr := "www.baidu.com:80"
	ctx := context.Background()

	// 获取连接
	conn, err := dialer.DialContext(ctx, "tcp", targetAddr)
	if err != nil {
		log.Fatalf("连接失败: %v", err)
	}
	defer conn.Close()

	// 构建HTTP请求
	httpRequest := strings.Join([]string{
		"GET / HTTP/1.1",
		"Host: www.baidu.com",
		"User-Agent: Mozilla/5.0",
		"Accept: text/html,application/xhtml+xml,application/xml",
		"Connection: close", // 请求完成后关闭连接
		"",                  // 空行标志着头部结束
		"",                  // 空行结束请求
	}, "\r\n")

	// 发送请求
	_, err = conn.Write([]byte(httpRequest))
	if err != nil {
		log.Fatalf("发送请求失败: %v", err)
	}

	// 读取响应
	reader := bufio.NewReader(conn)

	// 读取并解析HTTP响应头
	resp, err := http.ReadResponse(reader, &http.Request{Method: "GET", URL: &url.URL{}})
	if err != nil {
		log.Fatalf("读取响应失败: %v", err)
	}
	defer resp.Body.Close()

	// 读取响应体
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("读取响应体失败: %v", err)
	}

	fmt.Printf("状态码: %d\n", resp.StatusCode)
	fmt.Printf("响应头: %v\n", resp.Header)
	// 只显示前200个字符
	fmt.Printf("响应内容: %s...\n", string(body[:min(len(body), 200)]))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
