package ss

import (
	"context"
	"fmt"
	"net"

	"github.com/shadowsocks/go-shadowsocks2/core"
	"github.com/shadowsocks/go-shadowsocks2/socks"
)

func GetConn(ctx context.Context, server, method, password string, targetAddr string) (net.Conn, error) {
	// 创建密码器
	cipher, err := core.PickCipher(method, nil, password)
	if err != nil {
		return nil, err
	}

	// 2. 创建TCP拨号器并连接到代理服务器
	var Dialer net.Dialer
	rc, err := Dialer.DialContext(ctx, "tcp", server)
	if err != nil {
		return nil, fmt.Errorf("连接代理服务器失败: %w", err)
	}

	// 包装连接并转发
	rc = cipher.StreamConn(rc)
	// 向服务器发送目标地址
	_, err = rc.Write(socks.ParseAddr(targetAddr))
	if err != nil {
		rc.Close()
		return nil, err
	}

	return rc, nil
}
