package webServer

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	//	"os"
	//"path/filepath"
	"github.com/gin-gonic/gin"
	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"

	"golang.org/x/sys/windows/registry"
	//"monitor/env"
	"monitor/log"

	"monitor/module/message"
	httpProxy "monitor/module/webServer/proto/http"
	"monitor/module/webServer/proto/socks"
	"monitor/module/webServer/proto/ss"
	"monitor/module/webServer/proto/trojan"
	"monitor/module/webServer/tProxy"
	. "monitor/protocol"
)

type manager struct {
	ctx                  context.Context
	moduleApi            common.ModuleApi
	srv                  *http.Server
	cronT                *cron.Cron
	rdpClientStatus      atomic.Pointer[[]string]
	runProxyChan         chan struct{}
	proxyConfig          *ProxyConfig
	tProxyManagerPointer atomic.Pointer[tProxy.Manager]
	waitGroup            sync.WaitGroup
}

func (m *manager) Start(cc common.ModuleApi) error {
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	defer cancel()
	m.moduleApi = cc

	defer m.waitGroup.Wait()

	// 创建一个本地TCP监听器，监听在8080端口上
	// listener, err := net.Listen("tcp", ":8280")
	listener, err := net.Listen("tcp", ":0")
	if err != nil {
		log.Errorf("[webServer] net.Listen error:%+v", err)
		return err
	}
	defer listener.Close()

	m.runProxyChan = make(chan struct{}, 1)

	if err := setWebAddr("webAddr", listener.Addr().String()); err != nil {
		log.Errorf("[webServer] 写入注册表失败  error:%+v", err)
		return err
	}

	// 设置路由
	router := gin.Default()
	router.GET("/openRdpClient", m.openRdpClient)
	router.GET("/closeRdpClient", m.closeRdpClient)
	router.POST("/openRdpClient", m.openRdpClient)
	router.GET("/getRdpClientStatus", m.getRdpClientStatus)

	router.POST("/startProxy", m.startProxy)
	router.GET("/stopProxy", m.stopProxy)

	m.srv = &http.Server{
		Handler: router,
	}

	srvErrChan := make(chan error, 1)
	defer func() {
		listener.Close()
		m.srv.Shutdown(m.ctx)
		for range srvErrChan {
		}
		fmt.Println("--------------------webServer关闭-------------------------")
	}()

	go func() {
		defer close(srvErrChan)
		srvErrChan <- m.srv.Serve(listener)
	}()

	ticker := time.NewTicker(10 * time.Second)

	defer ticker.Stop()

	defer cancel()
	for {
		select {
		case <-cc.GetContext().Done():
			return nil
		case <-ticker.C:
			if err := setWebAddr("webAddr", listener.Addr().String()); err != nil {
				log.Errorf("[webServer] 写入注册表失败  error:%+v", err)
				// return err
			}
			ticker.Reset(10 * time.Second)
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}
			if moduleMsg == nil {
				continue
			}
			switch moduleMsg.RouteMsgId {
			default:
			}
		case moduleMsg, ok := <-m.moduleApi.GetModuleMsg(): // 模块之间的消息
			if !ok {
				return nil
			}
			if moduleMsg == nil {
				continue
			}
			switch moduleMsg.RouteMsgId {
			case ModuleMsgIdPushRdpClientStatus:
				if moduleMsg.Data != nil {
					if rdpClientStatus, ok := moduleMsg.Data.(*message.RdpClientStatus); ok && rdpClientStatus != nil {
						m.rdpClientStatus.Store(&rdpClientStatus.Status)
					}
				}

			default:
			}
		case err := <-srvErrChan:
			log.Errorf("[webServer] srvErrChan error:%+v", err)
			return fmt.Errorf("webServer srvErrChan %+v", err)
		}
	}
}

func (m *manager) getRdpClientStatus(c *gin.Context) {
	rdpClientStatus := m.rdpClientStatus.Load()
	if rdpClientStatus != nil {
		c.JSON(http.StatusOK, *rdpClientStatus)
		return
	}
	c.JSON(http.StatusOK, make([]string, 0, 0))
}

// /用来测试的
func (m *manager) openRdpClient(c *gin.Context) {
	var jsonData message.TProxyRdpClientJson
	if err := c.ShouldBindJSON(&jsonData); err != nil {
		log.Errorf("[webServer] openRdpClient error:%+v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	m.moduleApi.WriteModuleMessage(
		ModuleMsgIdRunTProxyRdpClient,
		&jsonData,
	)
	log.Infof("[webServer]  启动rdp客户端数据%+v", jsonData)
	c.JSON(http.StatusOK, "")
}

func (m *manager) closeRdpClient(c *gin.Context) {
	id := c.Query("id")
	m.moduleApi.WriteModuleMessage(
		ModuleMsgIdCloseTProxyRdpClient,
		&message.TProxyRdpClientJson{
			Id: id,
		},
	)
	c.String(http.StatusOK, "")
}

func (m *manager) stopProxy(c *gin.Context) {
	tProxyManagerOld := m.tProxyManagerPointer.Load()
	if tProxyManagerOld != nil {
		tProxyManagerOld.Stop()
	}
	c.String(http.StatusOK, "")
}

func (m *manager) startProxy(c *gin.Context) {
	var config ProxyConfig
	// 解析请求体 JSON 到 user 结构体
	if err := c.ShouldBindJSON(&config); err != nil {
		// 解析失败时返回错误信息
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}
	m.proxyConfig = &config
	select {
	case m.runProxyChan <- struct{}{}:
		if err := m.runProxy(); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": err.Error(),
			})
			return
		}
		c.String(http.StatusOK, "")
	default:
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "代理已经开启",
		})
	}
}

func (m *manager) runProxy() error {
	config := m.proxyConfig
	DefaultRules := make([]ProxyRules, len(config.DefaultRules))
	CustomRules := make([]ProxyRules, len(config.CustomRules))
	for i, v := range config.DefaultRules {
		result := strings.Split(v, ",")
		if len(result) > 1 {
			DefaultRules[i].Type = result[0]
			DefaultRules[i].Address = result[1]
			//	DefaultRules[i].Model = result[2]
		}
	}
	for i, v := range config.CustomRules {
		result := strings.Split(v, ",")
		if len(result) > 1 {
			CustomRules[i].Type = result[0]
			CustomRules[i].Address = result[1]
			// CustomRules[i].Model = result[2]
		}
	}
	tProxyManager := tProxy.NewManager(&tProxy.ProxyConfig{
		ProxyConn: func(ctx context.Context, domain, ip string, port uint16) (net.Conn, error) {
			if domain != "" {
				if len(config.DefaultProxies) > 0 {
					for _, v := range DefaultRules {
						if strings.Contains(domain, v.Address) {
							// if v.Model == "Proxy" {

							proxyData := config.DefaultProxies[int(time.Now().Unix())%len(config.DefaultProxies)]
							conn, err := GetConn(m.ctx, domain, proxyData)
							if err != nil {
								log.Errorf("[全局代理]  代理 %v 目标地址:%s error:%+v", proxyData, domain, err)
								return conn, err
							}
							log.Infof("[全局代理] 代理 %v 目标域名:%s 目标ip地址:%s ", proxyData, domain, fmt.Sprintf("%s:%d", ip, port))

							return conn, err
							//}
						}
					}
				}
				if len(config.CustomProxies) > 0 {
					for _, v := range CustomRules {
						if strings.Contains(domain, v.Address) {
							// if v.Model == "Proxy" {
							proxyData := config.CustomProxies[int(time.Now().Unix())%len(config.CustomProxies)]
							conn, err := GetConn(m.ctx, domain, proxyData)
							if err != nil {
								log.Errorf("[全局代理]  代理 %v 目标地址:%s error:%+v", proxyData, domain, err)
								return conn, err
							}
							log.Infof("[全局代理] 代理 %v 目标域名:%s 目标ip地址:%s % ", proxyData, domain, fmt.Sprintf("%s:%d", ip, port))

							return conn, err
							//}
						}
					}
				}

			} else {
				if len(config.DefaultProxies) > 0 {
					for _, v := range DefaultRules {
						if isIPInCIDR(ip, v.Address) {
							// if v.Model == "Proxy" {
							proxyData := config.DefaultProxies[int(time.Now().Unix())%len(config.DefaultProxies)]
							conn, err := GetConn(m.ctx, fmt.Sprintf("%s:%d", ip, port), proxyData)
							if err != nil {
								log.Errorf("[全局代理]  代理 %v 目标地址:%s error:%+v", proxyData, fmt.Sprintf("%s:%d", ip, port), err)
								return conn, err
							}
							log.Infof("[全局代理] 代理 %v 目标域名:%s 目标ip地址:%s % ", proxyData, domain, fmt.Sprintf("%s:%d", ip, port))

							return conn, err
							//}
						}
					}
				}

				if len(config.CustomProxies) > 0 {
					for _, v := range CustomRules {
						if isIPInCIDR(ip, v.Address) {
							// if v.Model == "Proxy" {
							proxyData := config.CustomProxies[int(time.Now().Unix())%len(config.CustomProxies)]
							conn, err := GetConn(m.ctx, fmt.Sprintf("%s:%d", ip, port), proxyData)
							if err != nil {
								log.Errorf("[全局代理]  代理 %v 目标地址:%s  error:%+v", proxyData, fmt.Sprintf("%s:%d", ip, port), err)
								return conn, err
							}
							log.Infof("[全局代理] 代理 %v 目标域名:%s 目标ip地址:%s % ", proxyData, domain, fmt.Sprintf("%s:%d", ip, port))

							return conn, err
							//}
						}
					}
				}

			}

			var d net.Dialer

			conn, err := d.DialContext(ctx, "tcp", fmt.Sprintf("%s:%d", ip, port))
			if err != nil {
				log.Errorf("[全局代理] 直连失败   目标域名:%s 目标ip地址:%s error:%+v", domain, fmt.Sprintf("%s:%d", ip, port), err)
				return conn, err
			}
			log.Infof("[全局代理] 直连成功   目标域名:%s 目标ip地址:%s", domain, fmt.Sprintf("%s:%d", ip, port))

			return conn, err
		},
	})

	tProxyManagerOld := m.tProxyManagerPointer.Swap(tProxyManager)
	if tProxyManagerOld != nil {
		tProxyManagerOld.Stop()
	}
	errChan, err := tProxyManager.Start()
	if err != nil {
		tProxyManager.Stop()
		<-m.runProxyChan
		return err
	}

	m.waitGroup.Add(1)
	go func() {
		defer m.waitGroup.Done()
		defer func() {
			tProxyManager.Stop()
			for range errChan {
				/* code */
			}
			<-m.runProxyChan
		}()

		select {
		case err, ok := <-errChan:
			if ok {
				log.Errorf("[全局代理] 退出 %+w", err)
			}
		case <-m.ctx.Done():

		}
	}()

	return nil
}

func isIPInCIDR(ipStr, cidrStr string) bool {
	// 解析IP地址
	ip := net.ParseIP(ipStr)
	if ip == nil {
		return false // IP格式无效
	}

	// 解析CIDR网段
	_, cidrNet, err := net.ParseCIDR(cidrStr)
	if err != nil {
		return false // CIDR格式无效
	}

	// 检查IP是否在网段内
	return cidrNet.Contains(ip)
}

func GetConn(ctx context.Context, targetAddr string, proxyData Proxy) (net.Conn, error) {
	switch proxyData.Type {
	case "trojan":
		return trojan.GetConn(
			ctx,
			fmt.Sprintf("%s:%d", proxyData.Server, proxyData.Port),

			proxyData.Password,
			targetAddr,
			proxyData.Sni,
			proxyData.SkipCertVerify,
		)
	case "socks5":
		return socks.GetConn(
			ctx,
			fmt.Sprintf("socks://%s:%s@%s:%d",
				proxyData.Username,
				proxyData.Password,
				proxyData.Server,
				proxyData.Port,
			),
			targetAddr,
		)
	case "http":
		return httpProxy.GetConn(
			ctx,
			fmt.Sprintf("http://%s:%s@%s:%d",
				proxyData.Username,
				proxyData.Password,
				proxyData.Server,
				proxyData.Port,
			),
			targetAddr,
		)
	case "ss":
		return ss.GetConn(
			ctx,
			fmt.Sprintf("%s:%d", proxyData.Server, proxyData.Port),
			proxyData.Cipher,
			proxyData.Password,
			targetAddr,
		)

	}

	return nil, fmt.Errorf("不支持代理类型 %+v", proxyData.Type)
}

func setWebAddr(Key string, valueData string) error {
	// 定义注册表的键和值
	keyPath := `SOFTWARE\CloudSeven\CSmonitor`
	valueName := Key

	// 尝试打开注册表项
	key, err := registry.OpenKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
	if err != nil {
		if err == registry.ErrNotExist {
			// 如果键不存在，则创建它
			key, _, err = registry.CreateKey(registry.LOCAL_MACHINE, keyPath, registry.QUERY_VALUE|registry.SET_VALUE)
			if err != nil {
				fmt.Printf("创建注册表项失败: %v\n", err)
				return err
			}
			defer key.Close()
			fmt.Println("注册表项不存在，已成功创建。")
		} else {
			fmt.Printf("打开注册表项失败: %v\n", err)
			return err
		}
	}
	defer key.Close()

	return key.SetStringValue(valueName, valueData)
}

// Proxy 表示代理服务器配置
type Proxy struct {
	Name           string `json:"name"`   // 代理名称
	Type           string `json:"type"`   // 代理类型（如 'ss'）
	Server         string `json:"server"` // 服务器地址（IP或域名）
	Port           int    `json:"port"`   // 服务器端口
	Cipher         string `json:"cipher"` // 加密方式
	Username       string `json:"username"`
	Password       string `json:"password"` // 密码或令牌
	UDP            bool   `json:"udp"`      // 是否启用UDP
	SkipCertVerify bool   `json:"skip-cert-verify"`
	Sni            string `json:"sni"`
	FastOpen       bool   `json:"fast-open"` // 是否启用快速打开（注意JSON字段名映射）
}

// Config 包含所有代理和规则配置
type ProxyConfig struct {
	DefaultProxies []Proxy  `json:"userIpProxyConfig"`  // 默认代理列表
	DefaultRules   []string `json:"userIpProxyRule"`    // 默认规则列表
	CustomProxies  []Proxy  `json:"staffIpProxyConfig"` // 机场自定义代理列表
	CustomRules    []string `json:"staffIpProxyRule"`   // 机场自定义规则列表
}

type ProxyRules struct {
	Type    string
	Address string
	Model   string
}
