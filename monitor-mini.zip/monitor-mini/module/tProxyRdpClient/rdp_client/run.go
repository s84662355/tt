package rdp_client

import (
	"context"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows/registry"
	"monitor/utils/windowActivate"
)

// Run 启动RDP客户端连接
// ctx: 上下文对象，用于控制进程生命周期
// m_ip: 目标服务器IP地址
// m_username: RDP用户名
// m_password: RDP密码
// m_enable_multimon: 是否启用多显示器支持(0/1)
func Run(
	ctx context.Context,
	m_ip string,
	m_username string,
	m_password string,
	m_enable_multimon int8,

	audiocapturemode int8,
	audioqualitymode int8,
	rdpConnection int8,
	audiomode int8,
) error {
	// 1. 生成RDP配置文件
	fileName, err := writeRdpFile(
		m_ip,
		m_username,
		m_enable_multimon,
		audiocapturemode,
		audioqualitymode,
		rdpConnection,
		audiomode,
	)
	if err != nil {
		return fmt.Errorf("创建RDP文件失败: %w", err)
	}

	fmt.Println(fileName)

	defer func() {
		fmt.Println(os.Remove(fileName))
	}()

	ip, _, _ := net.SplitHostPort(m_ip)
	// 2. 保存凭据到Windows凭据管理器
	if err := saveCredentials(
		ctx,
		ip,
		m_username,
		m_password,
	); err != nil {
		return fmt.Errorf("保存凭据失败: %w", err)
	}

	// 3. 配置忽略认证提示
	IgnoreAuthentication(ip)

	// 4. 启动mstsc.exe连接远程桌面

	storeCmd := exec.CommandContext(ctx,
		"mstsc",  // Windows远程桌面客户端
		fileName, // 使用生成的RDP配置文件
	)

	if err := storeCmd.Start(); err != nil {
		return fmt.Errorf("启动失败: %w", err)
	}

	done := make(chan struct{})
	defer func() {
		for range done {
			/* code */
		}
	}()

	// windowActivate.Activate(storeCmd.Process.Pid)

	go func() {
		defer close(done)

		// 创建一个每秒触发一次的Ticker
		ticker := time.NewTicker(500 * time.Millisecond)
		defer ticker.Stop() // 程序结束前停止Ticker

		for i := 0; i < 10; i++ {
			select {
			case <-ticker.C:
				if windowActivate.Activate(storeCmd.Process.Pid) == nil {
					return
				}
			case done <- struct{}{}:
				return
			}
		}
	}()

	return storeCmd.Wait()

	// storeCmd := exec.CommandContext(ctx,
	// 	"mstsc",  // Windows远程桌面客户端
	// 	fileName, // 使用生成的RDP配置文件
	// )
	// return storeCmd.Run()
}

// saveCredentials 将凭据保存到Windows凭据管理器
func saveCredentials(
	ctx context.Context,
	m_ip string,
	m_username string,
	m_password string,
) error {
	// 使用cmdkey命令存储凭据
	storeCmd := exec.CommandContext(ctx, "cmdkey",
		"/generic:TERMSRV/"+m_ip, // 目标服务器标识
		"/user:"+m_username,      // 用户名
		"/pass:"+m_password)      // 密码

	storeCmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	return storeCmd.Run()
}

// writeRdpFile 生成RDP连接配置文件
func writeRdpFile(
	m_ip string,
	m_username string,
	m_enable_multimon int8,
	audiocapturemode int8,
	audioqualitymode int8,
	rdpConnection int8,
	audiomode int8,
) (string, error) {
	// 使用模板生成RDP文件内容
	content := fmt.Sprintf(
		rdpFileTemplate, // RDP文件模板常量(未在代码中显示)
		m_ip,
		m_username,
		m_enable_multimon,
		audiocapturemode,
		audioqualitymode,
		rdpConnection,
		audiomode,
	)

	if rdpConnection == 1 {
		content += `

				desktopbackground:i:1,
				fontsmoothing:i:1,
				desktopcomposition:i:1,
				disable full window drag:i:0,
				menuanimations:i:1,
				themes:i:1,
				persistentbitmapcaching:i:1,
				autoreconnect:i:1,
		    `
	}

	fmt.Println(content)

	// 获取数据存储目录
	dir, err := getDataPath()
	if err != nil {
		return "", fmt.Errorf("获取数据目录失败: %w", err)
	}

	m_ip = strings.ReplaceAll(m_ip, ":", "-")

	// 生成RDP文件路径
	filename := filepath.Join(dir, fmt.Sprint("rdp-", m_ip))

	// 写入文件(权限644)
	return filename, os.WriteFile(filename, []byte(content), 0o644)
}

// getCurrentPath 获取当前可执行文件所在目录
func getCurrentPath() string {
	// 获取可执行文件路径
	exePath, err := os.Executable()
	if err != nil {
		// 失败时回退到当前工作目录
		wd, _ := os.Getwd()
		return wd
	}

	// 提取目录路径
	currentPath := filepath.Dir(exePath)

	// 统一路径分隔符为Windows风格
	currentPath = strings.ReplaceAll(currentPath, "/", "\\")
	return currentPath
}

// getDataPath 获取或创建数据存储目录
func getDataPath() (string, error) {
	currentPath := getCurrentPath()

	// 构建data子目录路径
	dataPath := filepath.Join(currentPath, "data") + string(filepath.Separator)

	// 创建目录(如果不存在)
	if _, err := os.Stat(dataPath); os.IsNotExist(err) {
		err := os.MkdirAll(dataPath, 0o755) // 权限755
		if err != nil {
			return "", fmt.Errorf("创建数据目录失败: %w", err)
		}
	}

	return dataPath, nil
}

// ignoreAuthentication 配置RDP客户端忽略认证提示
func IgnoreAuthentication(m_ip string) (error, error) {
	// 1. 将目标IP添加到本地设备列表(值76表示特殊标志)
	err1 := writeRegistry("Software\\Microsoft\\Terminal Server Client\\LocalDevices", m_ip, 76)
	// 2. 设置认证级别覆盖为0(不提示认证)
	err2 := writeRegistry("SOFTWARE\\Microsoft\\Terminal Server Client", "AuthenticationLevelOverride", 0)

	return err1, err2
}

// writeRegistry 写入Windows注册表键值
func writeRegistry(keyPath, valueName string, value interface{}) error {
	// 打开或创建注册表键(HKCU下)
	key, _, err := registry.CreateKey(
		registry.CURRENT_USER,
		keyPath,
		registry.ALL_ACCESS,
	)
	if err != nil {
		return fmt.Errorf("无法打开注册表键: %w", err)
	}
	defer key.Close() // 确保关闭注册表键

	// 根据值类型设置注册表值
	switch v := value.(type) {
	case string:
		err = key.SetStringValue(valueName, v)
	case int:
		err = key.SetDWordValue(valueName, uint32(v))
	case []byte:
		err = key.SetBinaryValue(valueName, v)
	default:
		return fmt.Errorf("不支持的注册表值类型: %T", value)
	}

	if err != nil {
		return fmt.Errorf("写入注册表值失败: %w", err)
	}
	return nil
}
