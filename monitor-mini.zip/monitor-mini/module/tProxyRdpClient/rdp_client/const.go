package rdp_client

/*
audiocapturemode:i:1：启用麦克风（值为 1 表示允许客户端录制并发送到远程）。
audioqualitymode:i:2：设置音频质量（0 = 低，1 = 中，2 = 高）。

	connection // 这里 6 表示 LAN (10 Mbps 或更高)
*/
const rdpFileTemplate = `full address:s:%s
username:s:%s
prompt for credentials:i:0
administrative session:i:1
	use multimon:i:%d
	audiocapturemode:i:%d
	audioqualitymode:i:%d
	connection type:i:%d  
	audiomode:i:%d
`
