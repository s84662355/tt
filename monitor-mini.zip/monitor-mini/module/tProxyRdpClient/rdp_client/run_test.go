package rdp_client

import (
	"context"
	"fmt"
	"testing"
)

// go test   -run TestRun -v
func TestRun(t *testing.T) {
	err := Run(
		context.Background(),
		"47.250.140.114:3389",
		"Administrator",
		"u$]m*52rdsKNg3[",
		1,
		0,
		1,
		1,
		1,
	)
	if err != nil {
		fmt.Println(err)
		return
	}
}
