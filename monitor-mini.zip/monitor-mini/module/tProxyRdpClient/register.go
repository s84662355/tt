package tProxyRdpClient

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "TProxyRdpClient"

var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorRdpPushQuitReq, // 36 网关推送监控Rdp退出
}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn:    Strat,
			Msgs:       slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
			ModuleMsgs: []ModuleMsgId{ModuleMsgIdRunTProxyRdpClient, ModuleMsgIdCloseTProxyRdpClient},
		})
}
