package tProxy

import (
	"context"
	"fmt"
	"io"
	"net"
	"sync"
	"time"

	//"go.uber.org/zap"
	"monitor/gvisor.dev/gvisor/pkg/tcpip/adapters/gonet"
	"monitor/gvisor.dev/gvisor/pkg/tcpip/transport/tcp"
	"monitor/gvisor.dev/gvisor/pkg/waiter"
	//"time"
	//"transparent/log"
	"monitor/module/tProxyRdpClient/proto/http"
	"monitor/module/tProxyRdpClient/proto/socks"
	"monitor/module/tProxyRdpClient/proto/trojan"
)

// transportProtocolHandler 处理TCP转发请求
// 参数r是TCP转发请求对象
func (m *manager) transportProtocolHandler(r *tcp.ForwarderRequest) {
	defer m.exitChanPutOnce(nil)
	// 创建等待队列，用于TCP端点的异步操作
	wq := waiter.Queue{}

	// 创建TCP端点(Endpoint)
	ep, tcperr := r.CreateEndpoint(&wq)
	if tcperr != nil {
		// log.Error("创建TCP端点失败", zap.Any("error", tcperr))
		r.Complete(true) // 标记请求完成(带错误)
		return
	}
	defer ep.Close()        // 确保函数退出时关闭端点
	defer r.Complete(false) // 标记请求成功完成

	// 将gVisor的TCP端点包装为Go标准的net.Conn接口
	cep := gonet.NewTCPConn(&wq, ep)
	defer cep.Close() // 确保函数退出时关闭连接

	buf := make([]byte, 1)
	var n int
	var readErr error = nil
	done := make(chan struct{})
	defer func() {
		for range done {
			/* code */
		}
	}()
	go func() {
		defer close(done)
		n, readErr = cep.Read(buf)
	}()

	go func() {
		for range done {
			/* code */
		}
		if readErr != nil {
			m.exitChanPutOnce(readErr)
		}
	}()

	// 获取到目标地址的连接
	target, err := m.getConn()
	if err != nil {
		m.exitChanPutOnce(err)
		// log.Error("获取代理连接失败", zap.Any("error", err))
		return
	}
	defer target.Close() // 确保函数退出时关闭目标连接

	// 创建错误通道，用于协程间通信
	errChan := make(chan error, 2)
	defer close(errChan) // 确保函数退出时关闭通道

	// 使用WaitGroup等待两个协程完成
	wg := &sync.WaitGroup{}
	// 等待所有协程完成
	defer wg.Wait()

	wg.Add(2) // 需要等待2个协程

	// 启动协程1：从目标连接读取数据并写入客户端端点
	go func() {
		defer wg.Done()
		_, err := io.Copy(cep, target)
		errChan <- err // 发送可能发生的错误
	}()

	// 启动协程2：从客户端端点读取数据并写入目标连接
	go func() {
		defer wg.Done()
		for range done {
			/* code */
		}

		if readErr == nil && n > 0 {
			target.Write(buf[:n])
		}

		_, err = io.Copy(target, cep)
		errChan <- err // 发送可能发生的错误
	}()

	// 等待以下两种情况之一发生：
	select {
	case err := <-errChan: // 1. 任一协程发生错误
		if err != nil {
			// log.Error("数据传输错误", zap.Any("error", err))
		}
	case <-m.tcm.Context().Done(): // 2. 上下文被取消

	}

	// 关闭连接
	cep.Close()
	target.Close()

	fmt.Println("连接代理结束")
}

// getConn 根据配置获取到目标地址的连接
// 返回net.Conn连接对象和可能的错误
func (m *manager) getConn() (net.Conn, error) {
	ctx, cancel := context.WithTimeout(m.tcm.Context(), 5*time.Second)
	defer cancel()
	if m.isUseProxy {
		switch m.rdpJson.ProxyType {
		case "socks": // SOCKS代理
			return socks.GetConn(ctx, m.rdpJson.ProxyUrl, m.rdpJson.TargetAddr)
		case "http": // HTTP代理
			return http.GetConn(ctx, m.rdpJson.ProxyUrl, m.rdpJson.TargetAddr)
		// Trojan代理支持，
		case "trojan":
			return trojan.GetConn(
				ctx,
				m.rdpJson.TrojanProxy.Server,
				m.rdpJson.TrojanProxy.Password,
				m.rdpJson.TargetAddr,
				m.rdpJson.TrojanProxy.InsecureSkipVerify,
			)
		default: // 不支持的代理类型

		}
	}

	// 创建 Dialer 实例
	dialer := &net.Dialer{}

	// 使用上下文进行连接
	return dialer.DialContext(ctx, "tcp", m.rdpJson.TargetAddr)
}
