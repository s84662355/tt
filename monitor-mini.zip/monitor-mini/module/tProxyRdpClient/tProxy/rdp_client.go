package tProxy

import (
	"context"

	//"go.uber.org/zap"

	//"monitor/log"

	"monitor/module/tProxyRdpClient/rdp_client"
)

// runRdpClient 启动并管理RDP客户端连接
// ctx: 上下文对象，用于控制协程生命周期和取消信号
func (m *manager) runRdpClient(ctx context.Context) {
	errChan := make(chan error, 1)
	// 确保在函数退出时清空错误通道，防止goroutine泄漏
	defer func() {
		for range errChan { // 持续读取通道直到关闭
		}
	}()
	go func() {
		defer close(errChan)
		// 启动RDP客户端，返回一个错误通道用于接收运行状态
		errChan <- rdp_client.Run(
			ctx,
			m.rdpJson.TargetAddr,           // 目标RDP服务器地址
			m.rdpJson.RdpUserName,          // RDP用户名
			m.rdpJson.RdpPassword,          // RDP密码
			int8(m.rdpJson.EnableMultimon), // 是否启用多显示器支持
			int8(m.rdpJson.Audiocapturemode),
			2, //	int8(m.rdpJson.Audioqualitymode),
			int8(m.rdpJson.RdpConnection),
			0,
		)
	}()
	select {
	case err := <-errChan: // 情况1：RDP客户端返回错误
		// if err != nil {
		// 	log.Error("RDP客户端运行失败", zap.Any("error", err))
		// }
		m.exitChanPutOnce(err)
		///m.exitChan <- err
		// // 通知应用程序关闭
		// m.exitChanCloseFunc()
	case <-ctx.Done():
	}
}
