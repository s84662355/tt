package tProxy

import (
	"fmt"
	"testing"
	"time"

	"monitor/module/message"
)

// go test  -run TestRunRdp -tags "dev" -v
func TestRunRdp(t *testing.T) {
	rdpC := NewManager(&message.TProxyRdpClientJson{
		ProxyUrl: "http://test985:test985@8.219.163.116:7777",
		//	ProxyType:      "http",
		RdpUserName:    "Administrator",
		TargetAddr:     "47.250.84.127:3389",
		RdpPassword:    "cloud123123@",
		EnableMultimon: 1,
	})

	errChan, err := rdpC.Start()
	if err != nil {
		fmt.Println(err)
		return
	}
	defer rdpC.Stop()
	select {
	case <-time.After(100 * time.Second):
	case <-errChan:
	}
}

// go test   -run TestRunTProxy -v   -tags "dev"
func TestRunTProxy(t *testing.T) {
	rdpC := NewManager(&message.TProxyRdpClientJson{
		ProxyType:      "trojan",
		RdpUserName:    "Administrator",
		TargetAddr:     "47.250.84.127:3389",
		RdpPassword:    "cloud123123@",
		EnableMultimon: 1,
		TrojanProxy: struct {
			// Trojan服务器地址 (格式: ip:port 或 domain:port)
			Server string

			// WebSocket路径 (用于WebSocket传输模式)
			Path string

			// Trojan连接密码
			Password string

			// 传输协议 (如: "ws", "tls" 等)
			Transport string

			// 域名 (用于TLS SNI和HTTP Host头)
			Domain string

			InsecureSkipVerify bool
		}{
			Server:             "microsoft-snjx1zn6iz3ad3j-hk.xjnode.com:50303",
			Password:           "ff0656ab-05d0-41aa-9c81-18924069c61a",
			InsecureSkipVerify: true,
		},
	})

	errChan, err := rdpC.Start()
	if err != nil {
		fmt.Println(err)
		return
	}
	defer rdpC.Stop()
	select {
	case <-time.After(10 * time.Second):
	case <-errChan:
	}
}
