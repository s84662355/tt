package tProxyRdpClient

import (
	"bufio"
	"context"
	"fmt"
	"os/exec"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/robfig/cron/v3"

	"monitor/controlCenter/common"
	"monitor/log"
	"monitor/module/message"
	"monitor/module/tProxyRdpClient/tProxy"
	"monitor/protobuf"
	. "monitor/protocol"

	"monitor/module/tProxyRdpClient/utils"
)

type manager struct {
	ctx                        context.Context
	moduleApi                  common.ModuleApi
	tProxyManagerWaitGroup     sync.WaitGroup
	rdpContainer               sync.Map
	cronT                      *cron.Cron
	rdpServerStatus            atomic.Bool
	rdpServerStatusMu          sync.Mutex
	rdpServerLocalStatusMu     sync.Mutex
	isHasReportRdpServerStatus bool
}

func (m *manager) Start(cc common.ModuleApi) error {
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	m.moduleApi = cc

	defer func() {
		m.rdpContainer.Clear()
		m.tProxyManagerWaitGroup.Wait()

		ctx := m.cronT.Stop()
		// 等待定时任务完全结束
		<-ctx.Done()
	}()

	// 初始化定时任务调度器
	m.cronT = cron.New(cron.WithSeconds())
	m.cronT.Start()

	m.cronT.Schedule(cron.Every(15*time.Second), cron.FuncJob(func() {
		m.reportRdpServerStatus()
	}))

	m.cronT.Schedule(cron.Every(3*time.Second), cron.FuncJob(func() {
		m.pushRdpClientStatus()
	}))

	defer cancel()
	for {
		select {
		case <-cc.GetContext().Done():
			return nil
		case moduleMsg, ok := <-m.moduleApi.GetModuleMsg(): // 模块之间的消息

			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			case ModuleMsgIdRunTProxyRdpClient:
				if moduleMsg.Data != nil {
					if tProxyRdpClientJson, ok := moduleMsg.Data.(*message.TProxyRdpClientJson); ok && tProxyRdpClientJson != nil {
						m.openRdpClient(tProxyRdpClientJson)
					}
				}
			case ModuleMsgIdCloseTProxyRdpClient:
				if moduleMsg.Data != nil {
					if tProxyRdpClientJson, ok := moduleMsg.Data.(*message.TProxyRdpClientJson); ok && tProxyRdpClientJson != nil {
						m.closeRdpClient(tProxyRdpClientJson.Id)
					}
				}

			}
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}
			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorRdpPushQuitReq: // 36 网关推送监控Rdp退出
				// 关闭全部连接
				m.closeRdpClient("")
			default:
			}
		}
	}
}

func (m *manager) pushRdpClientStatus() {
	if !m.rdpServerLocalStatusMu.TryLock() {
		return
	}
	defer m.rdpServerLocalStatusMu.Unlock()

	s := make([]string, 0, 0)
	m.rdpContainer.Range(func(k, _ any) bool {
		s = append(s, k.(string))
		return true
	})

	m.moduleApi.WriteModuleMessage(
		ModuleMsgIdPushRdpClientStatus,
		&message.RdpClientStatus{
			Status: slices.Compact(s),
		},
	)
}

func (m *manager) closeRdpClient(id string) {
	if id == "" {
		m.rdpContainer.Range(func(_, actual any) bool {
			if tProxyManager, ok := actual.(tProxy.Manager); !ok {
				return true
			} else {
				tProxyManager.Stop()
			}

			return true
		})
		return
	}

	actual, loaded := m.rdpContainer.LoadAndDelete(id)
	if !loaded {
		return
	}

	if tProxyManager, ok := actual.(tProxy.Manager); !ok {
		return
	} else {
		tProxyManager.Stop()
	}
}

func (m *manager) openRdpClient(tProxyRdpClientJson *message.TProxyRdpClientJson) {
	Account, _ := utils.DecryptString(tProxyRdpClientJson.ProxyData.Account, utils.AES_KEY)
	Password, _ := utils.DecryptString(tProxyRdpClientJson.ProxyData.Password, utils.AES_KEY)
	Host, _ := utils.DecryptString(tProxyRdpClientJson.ProxyData.Host, utils.AES_KEY)
	Port, _ := utils.DecryptString(tProxyRdpClientJson.ProxyData.Port, utils.AES_KEY)
	UseType := tProxyRdpClientJson.ProxyData.UseType

	if UseType == 1 {
		tProxyRdpClientJson.ProxyType = "trojan"
		tProxyRdpClientJson.TrojanProxy.Server = fmt.Sprintf("%s:%s", Host, Port)
		tProxyRdpClientJson.TrojanProxy.Password = Password
		tProxyRdpClientJson.TrojanProxy.InsecureSkipVerify = true
	} else if UseType == 2 { // http
		tProxyRdpClientJson.ProxyType = "http"
		tProxyRdpClientJson.ProxyUrl = fmt.Sprintf("http://%s:%s@%s:%s", Account, Password, Host, Port)
	} else if UseType == 3 { // socks
		tProxyRdpClientJson.ProxyType = "socks"
		tProxyRdpClientJson.ProxyUrl = fmt.Sprintf("socks://%s:%s@%s:%s", Account, Password, Host, Port)
	}

	/////log.Infof("[tProxyRdpClient] rdp代理%+v", tProxyRdpClientJson)

	log.Infof("[tProxyRdpClient] 准备启动id:%s address:%s rdp客户端", tProxyRdpClientJson.Id, tProxyRdpClientJson.TargetAddr)

	actual, loaded := m.rdpContainer.LoadOrStore(tProxyRdpClientJson.Id, tProxy.NewManager(tProxyRdpClientJson))
	if loaded {
		log.Infof("[tProxyRdpClient] id:%s  address:%s rdp客户端已经启动", tProxyRdpClientJson.Id, tProxyRdpClientJson.TargetAddr)
		return
	}
	m.tProxyManagerWaitGroup.Add(1)
	go func() {
		defer m.tProxyManagerWaitGroup.Done()
		defer m.rdpContainer.CompareAndDelete(tProxyRdpClientJson.Id, actual)

		if tProxyManager, ok := actual.(tProxy.Manager); !ok {
			return
		} else {
			errChan, err := tProxyManager.Start()
			if err != nil {
				log.Errorf("[tProxyRdpClient] 启动id:%s  address:%s rdp客户端失败 error:%+v", tProxyRdpClientJson.Id, tProxyRdpClientJson.TargetAddr, err)
				return
			}
			defer func() {
				tProxyManager.Stop()
				log.Infof("[tProxyRdpClient] 关闭id:%s  address:%s rdp客户端完成", tProxyRdpClientJson.Id, tProxyRdpClientJson.TargetAddr)
				m.pushRdpClientStatus()
			}()
			log.Infof("[tProxyRdpClient] 启动id:%s address:%s rdp客户端成功", tProxyRdpClientJson.Id, tProxyRdpClientJson.TargetAddr)
			m.pushRdpClientStatus()
			select {
			case <-m.ctx.Done():
			case <-errChan:
			}
		}
	}()
}

func (m *manager) reportRdpServerStatus() {
	if !m.rdpServerStatusMu.TryLock() {
		return
	}
	defer m.rdpServerStatusMu.Unlock()

	rdpServerStatus := m.rdpServerStatus.Load()
	m.rdpServerStatus.Store(m.checkRdpServerStatus())

	if rdpServerStatus != m.rdpServerStatus.Load() || !m.isHasReportRdpServerStatus {
		m.isHasReportRdpServerStatus = true
		if m.rdpServerStatus.Load() {
			///上报rdp服务被连接
			m.moduleApi.WriteProtoMessage(MsgIdMonitorReportDeviceRdpLoginStatus, &protobuf.PushDeviceRdpLoginStatsInfo{
				Status: 1,
			})

			return
		} else {
			///上报rdp服务被断开
			m.moduleApi.WriteProtoMessage(MsgIdMonitorReportDeviceRdpLoginStatus, &protobuf.PushDeviceRdpLoginStatsInfo{
				Status: 2,
			})

			return
		}
	}
}

func (m *manager) checkRdpServerStatus() bool {
	cmd := exec.CommandContext(m.ctx, "cmd", "/c", "chcp 65001 && qwinsta")
	// 设置无窗口模式（Windows特有）
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true,
	}

	output, err := cmd.Output()
	if err != nil {
		return false
	}

	scanner := bufio.NewScanner(strings.NewReader(string(output)))
	for scanner.Scan() {
		line := scanner.Text()
		// 检查每一行中是否包含 "rdp-tcp#"，这表示存在一个 RDP 连接
		if strings.Contains(line, "rdp-tcp#") && (strings.Contains(line, "运行中") || strings.Contains(line, "active") || strings.Contains(line, "Active")) {
			return true
		}
	}

	if err := scanner.Err(); err != nil {
		return false
	}

	return false
}
