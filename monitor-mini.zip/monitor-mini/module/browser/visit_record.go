package browser

import (
	"fmt"
	"maps"
	"slices"
	"strings"
	"time"

	"monitor/log"
	"monitor/module/browser/visitRecord/chrome"
	"monitor/module/browser/visitRecord/common"
	"monitor/module/browser/visitRecord/edge"
	"monitor/module/browser/visitRecord/firefox"
	"monitor/protobuf"
	. "monitor/protocol"
	"monitor/utils/process"
	"monitor/utils/taskRunManager"
)

type VisitRecordTaskOptional struct {
	Name     string
	Optional *common.HistoryOptional
	Util     common.Util
}

func (m *manager) getTaskOptionals() []*VisitRecordTaskOptional {
	processList, _ := process.GetProcessList()
	if len(processList) == 0 {
		return nil
	}
	taskOptional := map[string]*VisitRecordTaskOptional{}
	EndTimestamp := time.Now()
	StartTimestamp := EndTimestamp.Add(-m.mvTime)
	for _, p := range processList {
		for _, name := range m.getBrowsers() {
			if strings.Contains(p.FullPath, name) {
				var browserUtil common.Util = nil
				switch name {
				case "chrome.exe":
					browserUtil = chrome.New()
				case "firefox.exe":
					browserUtil = firefox.New()
				case "msedge.exe":
					browserUtil = edge.New()

				default:
					continue
				}
				if browserUtil == nil {
					continue
				}
				fullPath, userData, _ := browserUtil.ParseArgs(p.ProcessID)

				taskOptional[userData] = &VisitRecordTaskOptional{
					Name: browserUtil.Name(),
					Util: browserUtil,
					Optional: &common.HistoryOptional{
						FullPath:       fullPath,
						TempDir:        m.tempDir,
						DataDir:        userData,
						StartTimestamp: StartTimestamp,
						EndTimestamp:   EndTimestamp,
					},
				}
			}
		}
	}

	return slices.SortedFunc(maps.Values(taskOptional), func(a, b *VisitRecordTaskOptional) int {
		return 0
	})
}

func (m *manager) getVisitRecord(visitRecordTaskOptionals []*VisitRecordTaskOptional) []*common.TaskVisitRecorResult {
	res := make([]*common.TaskVisitRecorResult, len(visitRecordTaskOptionals))
	count := len(visitRecordTaskOptionals)
	if count > 5 {
		count = 5
	}

	tManager := taskRunManager.NewChanTask(count)
	for i := range visitRecordTaskOptionals {
		ii := i
		tManager.Run(func() {
			userProfileHistory, err := visitRecordTaskOptionals[ii].Util.ReadHistory(visitRecordTaskOptionals[ii].Optional)
			res[ii] = &common.TaskVisitRecorResult{
				ProcessFullPath: visitRecordTaskOptionals[ii].Optional.FullPath,
				Data:            userProfileHistory,
				Err:             err,
			}
		})
	}
	tManager.Wait()

	return res
}

func (m *manager) runVisitRecordTask() {
	log.Info("[上传浏览器访问记录] start  ")
	visitRecordTaskOptionals := m.getTaskOptionals()

	if len(visitRecordTaskOptionals) == 0 {
		log.Info("[上传浏览器访问记录] 记录为0  ")
		return
	}
	result := m.getVisitRecord(visitRecordTaskOptionals)
	reportMachineBrowserInfos := make([]*protobuf.ReportMachineBrowserInfo, 0, len(result))
	for _, rr := range result {
		if rr.Err != nil {
			log.Errorf("[上传浏览器访问记录] 读取浏览器记录  %s err = %+v", rr.ProcessFullPath, rr.Err)
			continue
		}

		if rr.Data == nil {
			continue
		}

		for _, vvv := range rr.Data {
			for _, ggg := range vvv.History {
				fmt.Println("浏览器记录", ggg)
				reportMachineBrowserInfos = append(reportMachineBrowserInfos, &protobuf.ReportMachineBrowserInfo{
					BrowserName: rr.ProcessFullPath,
					Title:       ggg.Title,
					Url:         ggg.URL,
					Timestamp:   ggg.LastVisitTime.Unix(),
				})
			}
		}
	}

	infoRequest := &protobuf.ReportMachineBrowserInfoRequest{
		BrowserInfo: reportMachineBrowserInfos,
	}

	err := m.moduleApi.WriteProtoMessage(MsgIdMonitorReportMachineBrowserInfo, infoRequest)
	if err != nil {
		log.Error("[上传浏览器访问记录]  ", err)
	}
}
