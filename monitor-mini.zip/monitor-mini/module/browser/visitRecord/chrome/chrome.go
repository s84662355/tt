package chrome

import (
	"crypto/md5"
	"database/sql"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"github.com/otiai10/copy"
	"monitor/log"
	"monitor/module/browser/visitRecord/common"
	uCmdLine "monitor/utils/cmdLine"
	"monitor/utils/process"
	"monitor/utils/shlex"
)

const (
	Name = "chrome.exe"
)

var New = sync.OnceValue(func() common.Util { return &util{} })

type util struct{}

func (h *util) Name() string {
	return Name
}

func (h *util) ParseArgs(ProcessID uint32) (string, string, map[string]string) {
	fullPath, processArgs, _ := process.GetCmdline(ProcessID)
	cmdArgs, _ := shlex.Split(processArgs)
	if len(cmdArgs) > 0 {
		if !strings.HasPrefix(cmdArgs[0], "-") {
			cmdArgs = cmdArgs[1:]
		}
	}
	cmdArgsMap, err := uCmdLine.ChromeParseArgs(cmdArgs)
	if err != nil {
		log.Errorf("[browser] chrome 解析参数 err %+v", err)
	}
	userData := ""
	if cmdArgsMap != nil {
		userData, _ = cmdArgsMap["user-data-dir"]
	}
	if userData == "" {
		// 获取用户的主目录
		homeDir, err := os.UserHomeDir()
		if err != nil {
			return fullPath, "", cmdArgsMap
		}
		// 拼接 AppData\Local 路径
		appDataDir := filepath.Join(homeDir, "AppData", "Local")
		userData = filepath.Join(appDataDir, "Google", "Chrome", "User Data")
	} else {
		userData = filepath.Join(userData)
	}
	userData = filepath.Join(userData)
	return fullPath, userData, cmdArgsMap
}

func (h *util) ReadHistory(optional *common.HistoryOptional) ([]*common.UserProfileHistory, error) {
	userDirs, err := os.ReadDir(optional.DataDir)
	if err != nil {
		return nil, fmt.Errorf("readDirsHistory dirs:%s err = %w", optional.DataDir, err)
	}
	allHistories := []*common.UserProfileHistory{}
	for _, profileDir := range userDirs {
		if !profileDir.IsDir() {
			continue
		}
		historyFile := filepath.Join(optional.DataDir, profileDir.Name(), "History")
		if _, err := os.Stat(historyFile); os.IsNotExist(err) {
			continue
		}

		history, err := h.readHistory(optional.FullPath, historyFile, optional.TempDir, optional.StartTimestamp, optional.EndTimestamp)
		if err == nil {
			allHistories = append(allHistories, history)
		}
	}
	return allHistories, nil
}

func (h *util) readHistory(FullPath, historyFile string, tempDir string, startTimestamp, endTimestamp time.Time) (*common.UserProfileHistory, error) {
	hmd5 := md5.New()

	if _, err := io.WriteString(hmd5, historyFile); err != nil {
		return nil, fmt.Errorf("chrome 浏览器 hmd5 err:%+v", err)
	}

	copyPath := filepath.Join(tempDir, fmt.Sprintf("%x_History", hmd5.Sum(nil)))

	err := copy.Copy(historyFile, copyPath)
	if err != nil {
		return nil, err
	}
	// 删除副本
	defer os.Remove(copyPath)

	db, err := sql.Open("sqlite3", copyPath)
	if err != nil {
		return nil, err
	}
	defer db.Close()

	var history []*common.HistoryEntry

	// 转换为 Chrome 的时间格式（微秒数）
	startTimestampUnix := (startTimestamp.Unix() + 11644473600) * 1000000
	endTimestampUnix := (endTimestamp.Unix() + 11644473600) * 1000000

	///以后加分页
	query := "SELECT url, title, visit_count, last_visit_time FROM urls WHERE last_visit_time BETWEEN ? AND ?"
	rows, err := db.Query(query, startTimestampUnix, endTimestampUnix)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var url, title string
		var visitCount int
		var lastVisitTime int64

		err = rows.Scan(&url, &title, &visitCount, &lastVisitTime)
		if err != nil {
			continue
		}

		epochTime := (lastVisitTime / 1000000) - 11644473600
		date := time.Unix(epochTime, 0)

		history = append(history, &common.HistoryEntry{
			URL:           url,
			Title:         title,
			VisitCount:    visitCount,
			LastVisitTime: date,
		})
	}

	return &common.UserProfileHistory{
		FullPath: FullPath,
		Profile:  historyFile,
		History:  history,
	}, nil
}
