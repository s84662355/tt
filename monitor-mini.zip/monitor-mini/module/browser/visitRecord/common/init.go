package common

import (
	"time"
)

type VisitRecordTask struct {
	FullPath string
	UserData string
}

type HistoryEntry struct {
	URL           string    `json:"url"`
	Title         string    `json:"title"`
	VisitCount    int       `json:"visit_count"`
	LastVisitTime time.Time `json:"last_visit_time"`
}

type UserProfileHistory struct {
	FullPath string
	Profile  string          `json:"profile"`
	History  []*HistoryEntry `json:"history"`
}

type TaskVisitRecorResult struct {
	Data            []*UserProfileHistory
	ProcessFullPath string
	Err             error
}

type HistoryOptional struct {
	FullPath       string
	TempDir        string
	DataDir        string
	StartTimestamp time.Time
	EndTimestamp   time.Time
}

type Util interface {
	ParseArgs(ProcessID uint32) (string, string, map[string]string)
	ReadHistory(optional *HistoryOptional) ([]*UserProfileHistory, error)
	Name() string
}
