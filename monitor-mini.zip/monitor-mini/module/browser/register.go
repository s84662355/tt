package browser

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

const Name = "Browser"

var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorReportMachineBrowserInfo, // 上报浏览器访问信息
	MsgIdMonitorFlushBrowserInfo,         // 刷新浏览器信息
	MsgIdMonitorGetBrowserInfo,           // 获取浏览器信息
	MsgIdMonitorGetMonitorProjectInfo,    // 28 获取当前坐席版本
	MsgIdMonitorPushMonitorProjectInfo,   // 29 推送当前坐席版本

}

func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// /注册模块
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			StartFn: Strat,
			Msgs:    slices.Compact(slices.Clone(handleMsgs)), ///复制并且去重
		})
}
