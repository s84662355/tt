package browser

import (
	"context"
	"slices"
	"sync"
	"time"

	"github.com/robfig/cron/v3"
	"monitor/controlCenter/common"
	"monitor/env"

	. "monitor/protocol"
)

type manager struct {
	ctx                  context.Context
	moduleApi            common.ModuleApi
	mvTime               time.Duration
	browsers             []string
	tempDir              string
	browsersMu           sync.RWMutex
	cronT                *cron.Cron
	runVisitRecordTaskMu sync.Mutex
}

func (m *manager) Start(cc common.ModuleApi) error {
	ctxt, cancel := context.WithCancel(cc.GetContext())
	m.ctx = ctxt
	defer cancel()

	m.moduleApi = cc
	m.mvTime, _ = time.ParseDuration("5m")
	m.browsers = []string{"chrome.exe", "firefox.exe", "msedge.exe"}

	m.tempDir = env.BaseDir

	m.cronT = cron.New(cron.WithSeconds())
	m.cronT.Start()

	defer func() {
		ctx := m.cronT.Stop()
		///等待定时任务完全结束
		<-ctx.Done()
	}()

	// m.cronT.Schedule(cron.Every(10*time.Second), cron.FuncJob(func() {
	// 	if !m.runVisitRecordTaskMu.TryLock() {
	// 		return
	// 	}

	// 	defer m.runVisitRecordTaskMu.Unlock()
	// 	m.runVisitRecordTask()
	// }))

	m.cronT.Schedule(cron.Every(m.mvTime), cron.FuncJob(func() {
		if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportMachineBrowserInfoStrategy) {
			return
		}

		if !m.runVisitRecordTaskMu.TryLock() {
			return
		}

		defer m.runVisitRecordTaskMu.Unlock()
		m.runVisitRecordTask()
	}))

	defer cancel()

	for {
		select {
		case <-cc.GetContext().Done():
			return nil
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorFlushBrowserInfo: // 刷新浏览器信息
				// if moduleMsg.Data != nil {
				// 	if mm, ok := moduleMsg.Data.(*protobuf.MonitorBrowserInfo); ok && mm != nil {
				// 		m.setBrowsers(mm.BrowserNameList)
				// 	}
				// }
			default:
			}
		}
	}
}

func (m *manager) setBrowsers(browsers []string) {
	m.browsersMu.Lock()
	defer m.browsersMu.Unlock()
	m.browsers = slices.Clone(browsers)
}

func (m *manager) GetBrowsers() []string {
	return slices.Clone(m.getBrowsers())
}

func (m *manager) getBrowsers() []string {
	m.browsersMu.RLock()
	defer m.browsersMu.RUnlock()
	return m.browsers
}
