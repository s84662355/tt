package message

import (
	"time"
)

type AppTraffic struct {
	Pid       uint32
	Exe       string
	InFlow    uint64
	OutFlow   uint64
	StartTime time.Time
	EndTime   time.Time
}

// RdpJson RDP连接配置结构体
type TProxyRdpClientJson struct {
	Id string
	// 代理服务器地址 (格式: ip:port 或 domain:port)
	ProxyUrl string

	// 代理类型 (如: "http", "socks5", "trojan" 等)
	ProxyType string

	// 目标RDP服务器地址 (格式: ip:port)
	TargetAddr string

	// RDP登录用户名
	RdpUserName string

	// RDP登录密码
	RdpPassword string

	// 是否启用多显示器支持 (0-禁用 1-启用)
	EnableMultimon uint
	/*
	   audiocapturemode:i:1：启用麦克风（值为 1 表示允许客户端录制并发送到远程）。
	   audioqualitymode:i:2：设置音频质量（0 = 低，1 = 中，2 = 高）。
	*/
	Audiocapturemode uint
	Audioqualitymode uint

	RdpConnection uint8

	ProxyData struct {
		Account  string `json:"account"`
		Password string `json:"password"`
		Host     string `json:"host"`
		Port     string `json:"port"`
		UseType  uint8  `json:"useType"`
	}

	// Trojan代理配置 (当ProxyType为"trojan"时使用)
	TrojanProxy struct {
		// Trojan服务器地址 (格式: ip:port 或 domain:port)
		Server string

		// WebSocket路径 (用于WebSocket传输模式)
		Path string

		// Trojan连接密码
		Password string

		// 传输协议 (如: "ws", "tls" 等)
		Transport string

		// 域名 (用于TLS SNI和HTTP Host头)
		Domain string

		InsecureSkipVerify bool
	}
}

type RdpClientStatus struct {
	Status []string
}
