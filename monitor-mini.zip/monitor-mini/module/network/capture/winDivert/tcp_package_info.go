package winDivert

import (
	"maps"
	"slices"
	"sync"
	"sync/atomic"
	"time"
)

type tcpPackageInfo struct {
	sync.Mutex // 互斥锁，保护结构体内部状态（非原子操作字段）

	// ---------- 原子操作字段（无需 Mutex 保护）----------
	processInfo  atomic.Pointer[tcpPackageProcessInfo] // TCP包处理信息（指针原子操作）
	inFlow       atomic.Uint64                         // 流入数据量统计（单位：字节）
	outFlow      atomic.Uint64                         // 流出数据量统计（单位：字节）
	survivalTime atomic.Pointer[time.Time]             // 存活时间/过期时间（用于超时控制）
	domain       atomic.Pointer[string]                // 动态域名信息（原子指针）
	isClose      atomic.Bool                           // 连接关闭标记（原子布尔值）

	// ---------- 数据存储（需 Mutex 保护）----------
	payLoadMap     map[uint32][]byte   // 本地未收到对端响应前的缓存数据（key: 序列号, value: 载荷数据）
	sequenceNumMap map[uint32]struct{} // 等待本地应答的序列号集合（payload > 0）
	ackNumMap      map[uint32]struct{} // 等待本地应答的确认号集合（payload > 0）

	// ---------- TCP 控制信息 ----------
	remoteAckNum uint32 // 远端最新确认号（对端已接收的序列号）
	localAckNum  uint32 // 本地最新确认号（本端已接收的序列号）
	status       int8   // 状态标记（0: 未收到远端首包, 1: 已收首包, 2: 已处理）

	// ---------- 连接元数据 ----------
	key                string // 唯一标识键（如四元组哈希）
	sourceAddress      string // 源IP地址
	sourcePort         uint16 // 源端口
	destinationAddress string // 目标IP地址
	destinationPort    uint16 // 目标端口
	code               string
}

// GetPayLoadData 获取并合并缓存的TCP负载数据
// 返回值:
//   - []byte: 按序列号排序后合并的Payload数据，无数据时返回nil
//
// 功能说明:
//  1. 仅在状态为1（已接收远端首包）且存在缓存数据时执行
//  2. 自动将状态标记为2（已处理）
//  3. 按序列号升序合并所有缓存数据
//  4. 清空缓存映射（设置为nil释放内存）
//
// 注意:
//   - 需在互斥锁保护下调用（方法内已处理）
func (v *tcpPackageInfo) GetPayLoadData() (r []byte) {
	v.Lock()
	defer v.Unlock()

	// 状态检查：仅当已接收首包(status=1)且存在缓存数据时处理
	if v.status == 1 && len(v.payLoadMap) > 0 {
		v.status = 2 // 更新状态为已处理

		// 获取有序序列号列表并合并数据
		ks := slices.Sorted(maps.Keys(v.payLoadMap))
		for _, seq := range ks {
			r = append(r, v.payLoadMap[seq]...)
		}

		// 清空缓存（注意：map设为nil而非make，触发GC回收）
		v.payLoadMap = nil
	}
	return
}

// 处理本地的包
// 该方法用于处理本地 TCP 包的相关信息，包括序列号、确认号、负载以及更新存活时间等
// 参数:
//   - SequenceNumber: TCP 包的序列号
//   - AckNumber: TCP 包的确认号
//   - Payload: TCP 包的负载数据
//
// 返回值:
//   - bool: 处理成功返回 true
func (v *tcpPackageInfo) localPackageHandle(
	SequenceNumber uint32,
	AckNumber uint32,
	Payload []byte,
) bool {
	// 加锁以保证并发安全，防止多个 goroutine 同时修改 v 的状态
	v.Lock()
	// 函数结束时自动解锁
	defer v.Unlock()

	// 检查负载数据是否存在
	if len(Payload) > 0 {
		// 检查该序列号是否已经记录过
		if _, ok := v.sequenceNumMap[SequenceNumber]; !ok {
			// 若未记录过，将该序列号添加到已记录的序列号映射中
			v.sequenceNumMap[SequenceNumber] = struct{}{}
			// 增加流出流量
			v.outFlow.Add(uint64(len(Payload)))
			// 若状态为 0 且负载映射中的元素数量少于 5
			if v.status == 0 && len(v.payLoadMap) < 5 {
				// 复制负载数据到负载映射中
				v.payLoadMap[SequenceNumber] = append([]byte(nil), Payload...)
			}
		}
	}

	// 处理对端的确认号，移除已确认的确认号
	for n := range v.ackNumMap {
		if n < AckNumber {
			delete(v.ackNumMap, n)
		}
	}

	// 更新本地确认号
	v.localAckNum = AckNumber
	// 获取当前时间
	tT := time.Now()
	// 更新存活时间
	v.survivalTime.Store(&tT)

	return true
}

// 处理远端的包
// 该方法用于处理从远端接收到的 TCP 包，包含序列号、确认号和负载数据
// 参数:
//   - SequenceNumber: TCP 包的序列号
//   - AckNumber: TCP 包的确认号
//   - Payload: TCP 包的负载数据
//
// 返回值:
//   - isFirstPayLoad: 布尔值，表示是否是第一个带有负载的包
//   - handle: 布尔值，表示包是否已处理
func (v *tcpPackageInfo) remotePackageHandle(
	SequenceNumber uint32,
	AckNumber uint32,
	Payload []byte,
) (isFirstPayLoad bool, handle bool) {
	// 加锁以保证并发安全，防止多个 goroutine 同时修改 v 的状态
	v.Lock()
	// 函数结束时自动解锁
	defer v.Unlock()

	// 检查负载数据是否存在
	if len(Payload) > 0 {
		// 检查该序列号是否已经记录过
		if _, ok := v.ackNumMap[SequenceNumber]; !ok {
			// 若状态为 0，说明是首次接收到带负载的包，更新状态为 1
			if v.status == 0 {
				v.status = 1
				isFirstPayLoad = true
			}
			// 将该序列号添加到已记录的确认号映射中
			v.ackNumMap[SequenceNumber] = struct{}{}
			// 增加流入流量
			v.inFlow.Add(uint64(len(Payload)))
		}
	}

	// 处理本地的确认号，移除已确认的序列号
	for n := range v.sequenceNumMap {
		if n < AckNumber {
			delete(v.sequenceNumMap, n)
		}
	}

	// 更新远端确认号
	v.remoteAckNum = AckNumber
	// 获取当前时间
	tT := time.Now()
	// 更新存活时间
	v.survivalTime.Store(&tT)
	// 标记包已处理
	handle = true
	return
}
