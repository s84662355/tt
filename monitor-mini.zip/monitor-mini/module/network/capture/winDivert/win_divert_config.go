package winDivert

// SetSpeedLimit 设置流量速率限制
// 参数:
//
//	f - 速率限制值(字节/秒)，0表示不限速
func (dev *WinDivertDev) SetSpeedLimit(f uint64) {
	dev.flowUpperLimit.Store(int64(f)) // 存储速率限制值
	dev.isSpeedLimit.Store(f != 0)     // 根据是否为0设置限速标志
}

// SetBlackDomainList 设置黑名单域名列表
// 参数:
//
//	blackDomainList - 需要拦截的域名列表
func (dev *WinDivertDev) SetBlackDomainList(blackDomainList []string) {
	dev.tcpPackageInfo.setBlackDomainList(blackDomainList)
}
