package winDivert

import (
	"context"
	"slices"
	"sync"

	"golang.org/x/sync/errgroup"
	"monitor/controlCenter/common"
	"monitor/utils/Queue"
	"monitor/utils/map/concurrentMap"
)

// tcpPackageInfoMap 结构体用于管理 TCP 包信息
type tcpPackageInfoMap struct {
	infoMap              concurrentMap.ConcurrentMap[string, *tcpPackageInfo]
	ctx                  context.Context
	cancel               context.CancelFunc
	tcpFlowParseIPNQueue Queue.Queue[string]
	blackDomainList      []string
	blackDomainListMu    sync.RWMutex
	moduleApi            common.ModuleApi
	ewg                  *errgroup.Group
}

// newTcpPackageInfoMap 创建并初始化一个新的 tcpPackageInfoMap 实例
// 参数:
//   - moduleApi: 模块 API 接口，用于与监控系统交互
//
// 返回值:
//   - *tcpPackageInfoMap: 初始化完成的 tcpPackageInfoMap 实例
func newTcpPackageInfoMap(moduleApi common.ModuleApi) *tcpPackageInfoMap {
	// 创建 tcpPackageInfoMap 实例
	t := &tcpPackageInfoMap{
		moduleApi: moduleApi,
	}

	// 初始化并发安全的 infoMap，用于存储 tcpPackageInfo 指针
	t.infoMap = concurrentMap.New[*tcpPackageInfo]()

	// 创建可取消的上下文，用于控制相关操作的生命周期
	t.ctx, t.cancel = context.WithCancel(context.Background())

	// 初始化 TCP 流解析队列，用于存储字符串类型的数据
	t.tcpFlowParseIPNQueue = Queue.NewNQueue[string]()

	// 初始化错误组，用于管理多个 goroutine 的错误处理
	t.ewg = new(errgroup.Group)

	return t
}

func (t *tcpPackageInfoMap) Get(k string) (*tcpPackageInfo, bool) {
	return t.infoMap.Get(k)
}

func (t *tcpPackageInfoMap) isHasAndisClose(k string) (bool, bool) {
	if vv, ok := t.infoMap.Get(k); ok {
		return ok, vv.isClose.Load()
	}
	return false, false
}

// has 方法用于检查 tcpPackageInfoMap 的 infoMap 中是否存在指定的键。
// 参数 k 是要检查的键，类型为字符串。
// 返回值为布尔类型，若存在则返回 true，不存在则返回 false。
func (t *tcpPackageInfoMap) has(k string) bool {
	// 调用 infoMap 的 Has 方法来检查键是否存在
	return t.infoMap.Has(k)
}

// setBlackDomainList 方法用于设置 tcpPackageInfoMap 的黑名单域名列表。
// 参数 blackDomainList 是要设置的黑名单域名列表，类型为字符串切片。
// 该方法使用互斥锁保证线程安全，避免在设置过程中出现数据竞争。
func (t *tcpPackageInfoMap) setBlackDomainList(blackDomainList []string) {
	// 加锁，确保同一时间只有一个 goroutine 可以修改黑名单域名列表
	t.blackDomainListMu.Lock()
	// 函数结束时解锁，释放锁资源
	defer t.blackDomainListMu.Unlock()
	// 清空原有的黑名单域名列表，并将新的列表复制到其中
	t.blackDomainList = append(t.blackDomainList[:0], blackDomainList...)
}

// getBlackDomainList 方法用于获取 tcpPackageInfoMap 的黑名单域名列表。
// 返回值为字符串切片，包含当前的黑名单域名列表。
// 该方法使用读锁保证线程安全，允许多个 goroutine 同时读取列表。
func (t *tcpPackageInfoMap) getBlackDomainList() []string {
	// 加读锁，允许其他 goroutine 同时进行读操作
	t.blackDomainListMu.RLock()
	// 函数结束时解锁，释放锁资源
	defer t.blackDomainListMu.RUnlock()
	// 返回黑名单域名列表的克隆副本，避免外部修改原始列表
	return slices.Clone(t.blackDomainList)
	// 注释掉的代码是一个示例返回值，实际使用时应使用上面的克隆返回值
	//  return []string{"baidu.com"}
}

// deleteTcpPackageInfo 从 tcpPackageInfoMap 的 infoMap 中删除指定键和代码对应的 TCP 包信息。
// 该方法会根据传入的键 k 和代码 c 来判断是否删除对应的 TCP 包信息。
// 参数 k 是要检查的键，类型为字符串。
// 参数 c 是用于匹配的代码，类型为字符串。
// 返回值为布尔类型，若成功删除则返回 true，否则返回 false。
func (t *tcpPackageInfoMap) deleteTcpPackageInfo(k string, c string) bool {
	// 调用 infoMap 的 RemoveCb 方法，该方法会传入一个回调函数进行删除条件判断
	return t.infoMap.RemoveCb(k, func(
		key string,
		v *tcpPackageInfo,
		exists bool,
	) bool {
		// 如果键不存在，直接返回 false，表示不删除
		if !exists {
			return false
		}

		// 如果存储的代码和传入的代码匹配，则返回 true，表示删除该条目
		if v.code == c {
			v.isClose.Store(true)
			return true
		}

		// 其他情况不删除，返回 false
		return false
	})
}

func (t *tcpPackageInfoMap) deleteTcpPackageInfoOnSyncPackage(k string) bool {
	return t.infoMap.RemoveCb(k, func(
		key string,
		v *tcpPackageInfo,
		exists bool,
	) bool {
		// 如果键不存在，直接返回 false，表示不删除
		if !exists {
			return false
		}

		v.isClose.Store(true)

		// 其他情况不删除，返回 false
		return true
	})
}

// start 方法用于启动 tcpPackageInfoMap 的多个定时任务和处理队列的任务。
// 该方法会启动多个 goroutine 并发执行不同的任务。
func (t *tcpPackageInfoMap) start() {
	// 启动定时超时任务，该任务会在后台定期检查并处理超时的 TCP 包信息
	t.ewg.Go(func() error {
		t.scheduledTimeOuttasks()
		return nil
	})

	// 启动定时黑名单任务，该任务会在后台定期更新和处理黑名单相关信息
	t.ewg.Go(func() error {
		t.scheduledBlackListtasks()
		return nil
	})

	// 启动定时 I/O 计数器信息任务，该任务会在后台定期收集和处理 I/O 计数器信息
	t.ewg.Go(func() error {
		t.scheduledIOCountersInfo()
		return nil
	})

	// 启动 5 个 goroutine 并发处理 TCP 流解析队列
	for i := 0; i < 5; i++ {
		t.ewg.Go(func() error {
			t.handleTcpFlowParseIPNQueue()
			return nil
		})
	}
}

// stop 方法用于停止 tcpPackageInfoMap 相关的操作，并清理资源。
// 该方法会取消上下文，清空信息映射，关闭 TCP 流解析队列，并等待所有任务完成。
func (t *tcpPackageInfoMap) stop() {
	// 调用 cancel 函数，取消与之关联的上下文。
	// 这会通知所有依赖该上下文的 goroutine 停止执行，
	// 通常用于优雅地终止正在进行的任务。
	t.cancel()

	// 清空 infoMap 中的所有键值对。
	// 这会释放 infoMap 占用的内存资源，避免内存泄漏。
	t.infoMap.Clear()

	// 关闭 tcpFlowParseIPNQueue 队列。
	// 关闭队列后，将不再允许向队列中添加新元素，
	// 并且可能会触发队列相关的关闭操作。
	t.tcpFlowParseIPNQueue.Close()

	// 等待 errgroup 中的所有 goroutine 完成执行。
	// 这确保在所有任务完成后才会继续执行后续代码，
	// 保证资源的正确释放和操作的完整性。
	t.ewg.Wait()
}
