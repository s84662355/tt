package winDivert

import (
	"sync/atomic"
	"time"

	"github.com/lysShub/divert-go"
)

// 定义常量部分
// survivalTime 表示 TCP 包信息和拦截信息的存活时长，这里设置为 60 秒
const (
	survivalTime = 60 * time.Second
	// releasePidInfosurvivalTime 表示放行 PID 信息的存活时长，设置为 38 秒
	releasePidInfosurvivalTime = 38 * time.Second
	// shareSize 表示队列共享大小，用于某些队列相关的操作，这里设置为 8
	shareSize = 8
)

// interceptInfo 结构体用于存储拦截信息
type interceptInfo struct {
	// domain 是一个原子指针，指向一个字符串，用于存储拦截的域名信息
	domain atomic.Pointer[string]
	// survivalTime 是一个原子指针，指向一个时间对象，用于记录该拦截信息的存活时间
	survivalTime atomic.Pointer[time.Time]
}

// releasePidInfo 结构体用于存储放行的 PID 信息
type releasePidInfo struct {
	// pid 存储放行的进程 ID
	pid uint32
	// survivalTime 是一个原子指针，指向一个时间对象，用于记录该放行 PID 信息的存活时间
	survivalTime atomic.Pointer[time.Time]
}

// iPPackage 结构体用于表示 IP 数据包
type iPPackage struct {
	// isRun 表示该 IP 数据包是否处于运行状态
	isRun bool
	// data 存储 IP 数据包的原始数据
	data []byte
	// addr 存储该 IP 数据包的地址信息，使用 divert-go 库中的 Address 类型
	addr divert.Address

	tcpPackageInfoData *tcpPackageInfo
}

// packageData 结构体用于定义网络包数据
type packageData struct {
	// isOut 表示该网络包是否为出站流量
	isOut bool
	// data 存储网络包的原始数据
	data []byte
}

// tcpPackageProcessInfo 结构体用于存储 TCP 包的进程信息
type tcpPackageProcessInfo struct {
	// pid 存储 TCP 包对应的进程 ID
	pid uint32
	// ppid 存储 TCP 包对应的父进程 ID
	ppid uint32
	// exePath 存储 TCP 包对应进程的可执行文件路径
	exePath string
	// exeProductName 存储 TCP 包对应进程的可执行文件的产品名称
	exeProductName string
}
