package winDivert

// pushIpPackageSendQueue 将IP数据包推送到指定共享队列中
// 参数:
//
//	share - 队列分片索引
//	d - 待入队的IP数据包
func (dev *WinDivertDev) pushIpPackageSendQueue(share int, d *iPPackage) {
	dev.ipPackageSendQueueSlices[share].Enqueue(d)
}

// pushTcpFlowParseIPNQueue 将TCP数据包推送到指定解析队列中
// 参数:
//
//	share - 队列分片索引
//	d - 待入队的TCP数据包
func (dev *WinDivertDev) pushTcpFlowParseIPNQueue(share int, d *packageData) {
	dev.tcpFlowParseIPNQueueSlices[share].Enqueue(d)
}
