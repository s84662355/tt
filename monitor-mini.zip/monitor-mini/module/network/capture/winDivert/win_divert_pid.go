package winDivert

// AddReleasePid 添加要放行的进程PID到白名单
// 参数:
//
//	pid - 要放行的进程ID
//
// 并发安全: 使用互斥锁保证线程安全
func (dev *WinDivertDev) AddReleasePid(pid uint32) {
	dev.releasePidMapMu.Lock()
	defer dev.releasePidMapMu.Unlock()
	dev.releasePidMap[pid] = struct{}{} // 使用空结构体节省内存
}

// DelReleasePid 从白名单中移除指定的进程PID
// 参数:
//
//	pid - 要移除的进程ID
//
// 并发安全: 使用互斥锁保证线程安全
func (dev *WinDivertDev) DelReleasePid(pid uint32) {
	dev.releasePidMapMu.Lock()
	defer dev.releasePidMapMu.Unlock()
	delete(dev.releasePidMap, pid) // 从map中删除指定PID
}

// ExistsReleasePid 检查指定PID是否在白名单中
// 参数:
//
//	pid - 要检查的进程ID
//
// 返回值:
//
//	bool - true表示存在，false表示不存在
//
// 并发安全: 使用读锁保证线程安全
func (dev *WinDivertDev) ExistsReleasePid(pid uint32) bool {
	dev.releasePidMapMu.RLock()
	defer dev.releasePidMapMu.RUnlock()
	_, exists := dev.releasePidMap[pid]
	return exists
}

// getReleasePids 获取当前所有放行的进程PID列表
// 返回值:
//
//	[]uint32 - 放行的PID切片
//
// 并发安全: 使用读锁保证线程安全
// 性能提示: 返回的切片是副本，修改不会影响原始map
func (dev *WinDivertDev) getReleasePids() []uint32 {
	dev.releasePidMapMu.RLock()
	defer dev.releasePidMapMu.RUnlock()

	// 预分配切片空间优化性能
	pids := make([]uint32, 0, len(dev.releasePidMap))
	for pid := range dev.releasePidMap {
		pids = append(pids, pid)
	}
	return pids
}
