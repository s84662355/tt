package winDivert

import (
	"context"
	"fmt"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/lysShub/divert-go"
	"golang.org/x/sync/errgroup"
	"monitor/controlCenter/common"
	"monitor/log"
	"monitor/utils/Queue"
)

// WinDivertDev 主结构体定义
type WinDivertDev struct {
	// 上下文与生命周期管理
	ctx             context.Context
	cancel          context.CancelFunc
	ewg             *errgroup.Group
	runOnce         sync.Once
	run             atomic.Bool
	isNetworkCanRun atomic.Bool

	// 底层资源句柄
	handle  *divert.Handle
	buf     []byte // 主缓冲区
	tempBuf []byte // 临时缓冲区

	// 并发控制
	readLock  sync.Mutex
	writeLock sync.Mutex

	// 网络接口信息
	ifIdx    uint32 // 接口索引
	subIfIdx uint32 // 子接口索引

	// 数据包处理队列
	ipPackageSendQueueSlices   []Queue.Queue[*iPPackage]   // IP包发送队列
	tcpFlowParseIPNQueueSlices []Queue.Queue[*packageData] // TCP流解析队列

	// PID管理相关
	releasePidMap   map[uint32]struct{} // 放行PID映射表
	releasePidMapMu sync.RWMutex        // PID映射表读写锁

	// TCP状态跟踪
	tcpPackageInfo *tcpPackageInfoMap // TCP包信息映射

	// 模块配置
	moduleApi      common.ModuleApi       // 模块API接口
	sourceAddress  atomic.Pointer[string] // 源地址
	flowUpperLimit atomic.Int64           // 每秒流量上限(字节)
	isSpeedLimit   atomic.Bool            // 是否启用限速

	tTLMap *TTLMap
}

// NewWinDivertDev 创建并初始化一个新的WinDivertDev实例
// 参数:
//
//	moduleApi - 模块API接口，用于与监控系统交互
//
// 返回值:
//
//	*WinDivertDev - 初始化完成的设备实例
//	error - 错误信息，初始化失败时返回
func NewWinDivertDev(moduleApi common.ModuleApi) (*WinDivertDev, error) {
	defer log.Recover("divert MustLoad")
	divert.MustLoad(divert.DLL)

	// 获取网络接口索引和MTU值
	IfIdx, SubIfIdx, mtu, err := GetInterfaceIndex()
	if err != nil {
		return nil, fmt.Errorf("获取网络接口索引失败: %w", err)
	}

	log.Infof("WinDivertDev 参数  IfIdx:%d SubIfIdx:%d mtu:%d", IfIdx, SubIfIdx, mtu)

	// 创建WinDivert句柄，捕获指定接口的IP/TCP非回环流量
	// d, err := divert.Open(
	// 	fmt.Sprintf("ifIdx = %d and ip and tcp and not loopback", IfIdx),
	// 	divert.Network,
	// 	-999, 0,
	// )

	// 创建WinDivert句柄，捕获指定接口的IP/TCP非回环流量
	d, err := divert.Open(
		fmt.Sprintf("ifIdx = %d and ip and tcp and not loopback and (tcp.DstPort != %d and   tcp.SrcPort != %d)", IfIdx, 3389, 3389),
		divert.Network,
		-990, 0,
	)
	if err != nil {
		return nil, fmt.Errorf("打开WinDivert句柄失败: %w", err)
	}

	// 初始化设备结构体
	dev := &WinDivertDev{
		handle:         d,                               // WinDivert句柄
		ifIdx:          IfIdx,                           // 网络接口索引
		subIfIdx:       SubIfIdx,                        // 子接口索引
		moduleApi:      moduleApi,                       // 模块API
		releasePidMap:  make(map[uint32]struct{}),       // PID白名单
		tempBuf:        make([]byte, 2*mtu),             // 临时缓冲区
		tcpPackageInfo: newTcpPackageInfoMap(moduleApi), // TCP包处理器
		ewg:            new(errgroup.Group),             // 协程错误组
	}

	// 初始化原子状态
	dev.isNetworkCanRun.Store(true) // 允许网络运行
	dev.run.Store(true)             // 运行状态
	dev.isSpeedLimit.Store(false)   // 限速状态

	dev.ctx, dev.cancel = context.WithCancel(context.Background())

	// 初始化处理队列
	for i := 0; i < shareSize; i++ {
		dev.ipPackageSendQueueSlices = append(dev.ipPackageSendQueueSlices, Queue.NewNQueue[*iPPackage]())
		dev.tcpFlowParseIPNQueueSlices = append(dev.tcpFlowParseIPNQueueSlices, Queue.NewNQueue[*packageData]())
	}

	return dev, nil
}

// GetInterfaceIndex 函数用于获取网络接口的索引信息
// 返回值:
//
//	uint32 - 网络接口的索引
//	uint32 - 子接口的索引
//	uint32 - 网络接口的最大传输单元（MTU）
//	error  - 如果在操作过程中出现错误，则返回错误信息
//
// GetInterfaceIndex 获取网络接口索引信息
func GetInterfaceIndex() (uint32, uint32, uint32, error) {
	// 1. 定义DNS查询过滤规则
	const filter = "  not loopback and outbound and (ip.DstAddr = 8.8.8.8 or ipv6.DstAddr = 2001:4860:4860::8888) and tcp.DstPort = 53"

	// 2. 打开WinDivert句柄
	hd, err := divert.Open(filter, divert.Network, 0, divert.Sniff)
	if err != nil {
		return 0, 0, 0, fmt.Errorf("打开WinDivert失败: %w", err)
	}
	defer hd.Close()
	defer hd.Shutdown(divert.Both)

	// 3. 启动并发DNS查询
	wg := &sync.WaitGroup{}
	defer wg.Wait()

	startConnection(wg, "tcp4", "8.8.8.8:53")                // IPv4查询
	startConnection(wg, "tcp6", "[2001:4860:4860::8888]:53") // IPv6查询

	// 4. 接收数据包
	addr := divert.Address{}
	buff := make([]byte, 1500)

	errChan := make(chan error, 1)
	defer func() {
		hd.Close()
		hd.Shutdown(divert.Both)

		for range errChan {
		}
	}()
	go func() {
		defer close(errChan)
		_, err = hd.Recv(buff, &addr)
		errChan <- err
	}()

	// 5. 设置超时
	ctxTimeOut, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	select {
	case <-ctxTimeOut.Done():
		return 0, 0, 0, fmt.Errorf("操作超时")
	case err := <-errChan:
		if err != nil {
			return 0, 0, 0, err
		}
	}

	// 6. 获取MTU信息
	nw := addr.Network()
	interfaces, err := net.Interfaces()
	if err != nil {
		return 0, 0, 0, fmt.Errorf("获取网络接口失败: %w", err)
	}

	var mtu uint32
	for _, iface := range interfaces {
		if iface.Index == int(nw.IfIdx) {
			mtu = uint32(iface.MTU)
			break
		}
	}

	if mtu == 0 {
		return 0, 0, 0, fmt.Errorf("获取网络接口mtu失败 nw.IfIdx:%d, nw.SubIfIdx:%d", nw.IfIdx, nw.SubIfIdx)
	}

	return nw.IfIdx, nw.SubIfIdx, mtu, nil
}

// startConnection 是一个辅助函数，用于启动一个 goroutine 进行网络连接
// 参数:
//
//	wg      - 等待组，用于等待 goroutine 完成
//	network - 网络协议类型，如 "tcp4" 或 "tcp6"
//	address - 目标地址和端口
func startConnection(wg *sync.WaitGroup, network, address string) {
	wg.Add(1)
	go func() {
		defer wg.Done()
		// 尝试进行网络连接，设置超时时间为 1 秒
		conn, err := net.DialTimeout(network, address, time.Second)
		if err != nil {
			fmt.Printf("---------------net.DialTimeout(%q, %q, time.Second)-------------------%+v  ", network, address, err)
			return
		}
		// 关闭连接
		conn.Close()
	}()
}
