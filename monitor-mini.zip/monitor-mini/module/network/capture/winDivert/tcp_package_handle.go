package winDivert

import (
	"fmt"
	"time"
)

// synTcp 处理 TCP SYN 包信息，根据源地址、源端口、目标地址和目标端口生成唯一键，
// 并在 infoMap 中更新或插入对应的 TCP 包信息。
// 参数：
//   - SourceAddress: 源 IP 地址
//   - SourcePort: 源端口号
//   - DestinationAddress: 目标 IP 地址
//   - DestinationPort: 目标端口号
//
// 返回值：
//   - bool: 总是返回 true，表示操作成功
func (t *tcpPackageInfoMap) synTcp(
	SourceAddress string,
	SourcePort uint16,
	DestinationAddress string,
	DestinationPort uint16,
) bool {
	// 根据源地址、源端口、目标地址和目标端口生成唯一的键
	// 键的格式为 "源地址:源端口:目标地址:目标端口"
	k := fmt.Sprint(
		SourceAddress,
		":",
		SourcePort,
		":",
		DestinationAddress,
		":",
		DestinationPort,
	)

	// 使用 Upsert 方法更新或插入 infoMap 中的键值对
	// 如果键不存在，则插入新值；如果键已存在，则更新其值
	t.infoMap.Upsert(
		k,
		nil,
		// 该回调函数用于创建或更新 infoMap 中的值
		func(
			exist bool, // 表示键是否已存在于 infoMap 中
			valueInMap *tcpPackageInfo, // infoMap 中已存在的旧值
			newValue *tcpPackageInfo, // 传入的新值
		) *tcpPackageInfo {
			// 创建一个新的 tcpPackageInfo 结构体实例
			tp := &tcpPackageInfo{
				key:                k,                              // 设置键
				code:               fmt.Sprint(k, '-', time.Now()), // 生成唯一的代码，包含键和当前时间
				sequenceNumMap:     make(map[uint32]struct{}, 0),   // 初始化序列号映射
				ackNumMap:          make(map[uint32]struct{}, 0),   // 初始化确认号映射
				payLoadMap:         make(map[uint32][]byte, 0),     // 初始化负载映射
				sourceAddress:      SourceAddress,                  // 设置源地址
				sourcePort:         SourcePort,                     // 设置源端口
				destinationAddress: DestinationAddress,             // 设置目标地址
				destinationPort:    DestinationPort,                // 设置目标端口
			}
			// 获取当前时间
			tT := time.Now()
			// 存储当前时间到生存时间字段
			tp.survivalTime.Store(&tT)
			// 返回新创建的 tcpPackageInfo 实例
			return tp
		})

	// 操作完成，返回 true 表示成功
	return true
}

// localPackageHandle 处理本地 TCP 数据包。
// 该方法根据源地址、源端口、目标地址和目标端口生成唯一键，
// 然后从 infoMap 中查找对应的 TCP 包信息。
// 如果找到对应的信息，则调用该信息的 localPackageHandle 方法处理数据包的序列号、确认号和负载。
// 参数：
//   - SourceAddress: 源 IP 地址
//   - SourcePort: 源端口号
//   - DestinationAddress: 目标 IP 地址
//   - DestinationPort: 目标端口号
//   - SequenceNumber: TCP 数据包的序列号
//   - AckNumber: TCP 数据包的确认号
//   - Payload: TCP 数据包的负载数据
//
// 返回值：
//   - bool: 如果成功找到对应的 TCP 包信息并处理，返回 true；否则返回 false
func (t *tcpPackageInfoMap) localPackageHandle(
	SourceAddress string,
	SourcePort uint16,
	DestinationAddress string,
	DestinationPort uint16,
	SequenceNumber uint32,
	AckNumber uint32,
	Payload []byte,
) bool {
	// 根据源地址、源端口、目标地址和目标端口生成唯一的键
	// 键的格式为 "源地址:源端口:目标地址:目标端口"
	k := fmt.Sprint(
		SourceAddress,
		":",
		SourcePort,
		":",
		DestinationAddress,
		":",
		DestinationPort,
	)

	// 从 infoMap 中获取与键 k 对应的 TCP 包信息
	// v 是获取到的 TCP 包信息，ok 表示是否成功获取到信息
	v, ok := t.infoMap.Get(k)
	// 如果未找到对应的 TCP 包信息，则直接返回 false
	if !ok {
		return false
	}

	// 调用获取到的 TCP 包信息的 localPackageHandle 方法处理序列号、确认号和负载
	// 并返回该方法的处理结果
	return v.localPackageHandle(
		SequenceNumber,
		AckNumber,
		Payload,
	)
}

// remotePackageHandle 处理来自远端的 TCP 数据包。
// 此方法根据源地址、源端口、目标地址和目标端口生成唯一键，
// 从 infoMap 中查找对应的 TCP 包信息，若找到则调用其 remotePackageHandle 方法处理数据包，
// 并根据处理结果决定是否将键加入 TCP 流解析队列。
// 参数：
//   - SourceAddress: 源 IP 地址
//   - SourcePort: 源端口号
//   - DestinationAddress: 目标 IP 地址
//   - DestinationPort: 目标端口号
//   - SequenceNumber: TCP 数据包的序列号
//   - AckNumber: TCP 数据包的确认号
//   - Payload: TCP 数据包的负载数据
//
// 返回值：
//   - bool: 表示数据包是否处理成功
func (t *tcpPackageInfoMap) remotePackageHandle(
	SourceAddress string,
	SourcePort uint16,
	DestinationAddress string,
	DestinationPort uint16,
	SequenceNumber uint32,
	AckNumber uint32,
	Payload []byte,
) bool {
	// 根据源地址、源端口、目标地址和目标端口生成唯一的键
	// 键的格式为 "源地址:源端口:目标地址:目标端口"
	k := fmt.Sprint(
		SourceAddress,
		":",
		SourcePort,
		":",
		DestinationAddress,
		":",
		DestinationPort,
	)

	// 从 infoMap 中获取与键 k 对应的 TCP 包信息
	// v 是获取到的 TCP 包信息，ok 表示是否成功获取到信息
	v, ok := t.infoMap.Get(k)
	// 如果未找到对应的 TCP 包信息，则直接返回 false
	if !ok {
		return false
	}

	// 调用获取到的 TCP 包信息的 remotePackageHandle 方法处理序列号、确认号和负载
	// first 表示是否为首次处理该类型的包，handle 表示处理是否成功
	first, handle := v.remotePackageHandle(
		SequenceNumber,
		AckNumber,
		Payload,
	)

	// 如果是首次处理该类型的包
	if first {
		// 将键 k 加入 TCP 流解析队列
		t.tcpFlowParseIPNQueue.Enqueue(k)
	}

	// 返回数据包的处理结果
	return handle
}
