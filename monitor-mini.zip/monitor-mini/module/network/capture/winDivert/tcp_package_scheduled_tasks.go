package winDivert

import (
	"bufio"
	"bytes"
	"fmt"
	"net/http"
	"regexp"
	"strings"
	"time"

	net2 "github.com/shirou/gopsutil/net"
	"github.com/shirou/gopsutil/process"
	"monitor/controlCenter/common"
	"monitor/module/message"
	"monitor/module/network/sniffing/tls"
	. "monitor/protocol"
)

// scheduledBlackListtasks 是一个定时任务，用于定期检查 TCP 包信息中的域名是否在黑名单中。
// 如果域名在黑名单中，则将对应的连接信息插入到拦截信息映射中。
func (t *tcpPackageInfoMap) scheduledBlackListtasks() {
	// 定义任务的执行间隔为 10 秒
	loopTime := 10 * time.Second
	// 创建一个定时器，用于按照指定的时间间隔触发任务
	ticker := time.NewTicker(loopTime)
	// 使用 defer 确保在函数返回时停止定时器，释放相关资源
	defer ticker.Stop()

	// 进入无限循环，持续执行任务
	for {
		// 重置定时器，确保每次循环都按照指定的时间间隔触发
		ticker.Reset(loopTime)
		// 使用 select 语句处理多个通道事件
		select {
		// 当上下文被取消时，退出循环，结束任务
		case <-t.ctx.Done():
			return
		// 当定时器到期时，执行以下逻辑
		case <-ticker.C:
			// 获取当前的黑名单域名列表
			blackDomainList := t.getBlackDomainList()
			// 如果黑名单为空，跳过本次循环，继续下一次检查
			if len(blackDomainList) == 0 {
				continue
			}
			// 遍历 TCP 包信息映射中的每个元素
			for v := range t.infoMap.Iter() {
				// 从当前 TCP 包信息中获取存储的域名
				domainValue := v.Val.domain.Load()
				// 保存当前 TCP 包信息的引用
				V := v.Val
				// 检查域名是否存在
				if domainValue != nil {
					// 获取域名的值
					domain := *domainValue
					// 检查域名是否为空
					if domain != "" {
						// 遍历黑名单中的每个域名
						for _, blackDomain := range blackDomainList {
							// 检查当前域名是否包含黑名单中的某个域名
							if strings.Contains(domain, blackDomain) {
								V.isClose.Store(true)
								break
								// if valueInMap, ok := t.infoMap.Get(V.key); ok {
								// 	valueInMap.isClose.Store(true)
								// }

								// t.infoMap.Upsert(
								// 	V.key,
								// 	nil,
								// 	// 该回调函数用于创建或更新 infoMap 中的值
								// 	func(
								// 		exist bool, // 表示键是否已存在于 infoMap 中
								// 		valueInMap *tcpPackageInfo, // infoMap 中已存在的旧值
								// 		newValue *tcpPackageInfo, // 传入的新值
								// 	) *tcpPackageInfo {
								// 		if exist {
								// 			valueInMap.isClose.Store(true)
								// 		}
								// 		return valueInMap
								// 	})
							}
						}
					}
				}
			}
		}
	}
}

// scheduledIOCountersInfo 是一个定时任务，用于定期获取 TCP 连接的 I/O 计数器信息，
// 更新 TCP 包信息中的进程信息，并在满足条件时上报应用程序的流量数据。
func (t *tcpPackageInfoMap) scheduledIOCountersInfo() {
	// 定义任务的执行间隔为 5 秒
	loopTime := 5 * time.Second
	// 创建一个定时器，按照指定的时间间隔触发任务
	ticker := time.NewTicker(loopTime)
	// 使用 defer 确保在函数返回时停止定时器，释放相关资源
	defer ticker.Stop()
	// 记录任务开始的时间
	startTime := time.Now()

	// 进入无限循环，持续执行任务
	for {
		// 重置定时器，确保每次循环都按照指定的时间间隔触发
		ticker.Reset(loopTime)
		// 使用 select 语句处理多个通道事件
		select {
		// 当上下文被取消时，退出循环，结束任务
		case <-t.ctx.Done():
			return
		// 当定时器到期时，执行以下逻辑
		case tT := <-ticker.C:
			// 获取所有 TCP4 连接的信息
			IOCountersTcp, _ := net2.Connections("tcp4")
			// 如果没有获取到 TCP 连接信息，跳过本次循环，继续下一次检查
			if len(IOCountersTcp) == 0 {
				continue
			}
			// 遍历 TCP 包信息映射中的每个元素
			for v := range t.infoMap.Iter() {
				// 遍历所有 TCP 连接信息
				for _, ipf := range IOCountersTcp {
					// 检查当前 TCP 包信息的键是否与某个 TCP 连接的本地地址和远程地址组合匹配
					// 考虑两种可能的组合：本地地址 -> 远程地址 和 远程地址 -> 本地地址
					if v.Key == fmt.Sprint(
						ipf.Laddr.IP,
						":",
						ipf.Laddr.Port,
						":",
						ipf.Raddr.IP,
						":",
						ipf.Raddr.Port,
					) || v.Key == fmt.Sprint(
						ipf.Raddr.IP,
						":",
						ipf.Raddr.Port,
						":",
						ipf.Laddr.IP,
						":",
						ipf.Laddr.Port,
					) {
						// 根据 PID 创建一个新的进程对象
						pp, err := process.NewProcessWithContext(t.ctx, int32(ipf.Pid))
						// 如果创建进程对象成功
						if err == nil {
							// 获取进程的可执行文件路径
							exe, err := pp.Exe()
							// 如果获取可执行文件路径失败，跳过当前循环
							if err != nil {
								continue
							}
							// 将进程信息存储到 TCP 包信息中
							v.Val.processInfo.Store(&tcpPackageProcessInfo{
								pid:     uint32(ipf.Pid),
								exePath: exe,
							})
						}
						// 找到匹配的连接后，跳出内层循环
						break
					}
				}
			}

			// 检查是否存在开启的监控项目，该项目用于监控应用程序的流量策略
			if t.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorReportAppTrafficStrategy) {
				// 再次遍历 TCP 包信息映射中的每个元素
				for v := range t.infoMap.Iter() {
					// 获取并重置输入流量计数器
					inFlow := v.Val.inFlow.Swap(0)
					// 获取并重置输出流量计数器
					outFlow := v.Val.outFlow.Swap(0)
					// 如果输入流量和输出流量都为 0，跳过当前循环
					if inFlow == 0 && outFlow == 0 {
						continue
					}
					// 获取存储的进程信息
					einfo := v.Val.processInfo.Load()
					// 如果进程信息为空，跳过当前循环
					if einfo == nil {
						continue
					}
					// 如果模块 API 为空，跳过当前循环
					if t.moduleApi == nil {
						continue
					}
					// 调用模块 API 发送应用程序流量报告消息
					t.moduleApi.WriteModuleMessage(
						ModuleMsgIdReportAppTraffic,
						&message.AppTraffic{
							Pid:       einfo.pid,
							Exe:       einfo.exePath,
							InFlow:    inFlow,
							OutFlow:   outFlow,
							StartTime: startTime,
							EndTime:   tT,
						},
					)
				}
			}
			// 更新开始时间为当前时间，用于下一次流量统计
			startTime = tT
		}
	}
}

// scheduledTimeOuttasks 是一个定时任务，用于定期检查并移除过期的 TCP 包信息和拦截信息。
func (t *tcpPackageInfoMap) scheduledTimeOuttasks() {
	// 定义任务的执行间隔为 10 秒
	loopTime := 10 * time.Second
	// 创建一个定时器，按照指定的时间间隔触发任务
	ticker := time.NewTicker(loopTime)
	// 使用 defer 确保在函数返回时停止定时器，释放相关资源
	defer ticker.Stop()

	// 进入无限循环，持续执行任务
	for {
		// 重置定时器，确保每次循环都按照指定的时间间隔触发
		ticker.Reset(loopTime)
		// 使用 select 语句处理多个通道事件
		select {
		// 当上下文被取消时，退出循环，结束任务
		case <-t.ctx.Done():
			return
		// 当定时器到期时，执行以下逻辑
		case <-ticker.C:
			// 遍历 TCP 包信息映射中的每个元素
			for v := range t.infoMap.Iter() {
				// 调用 RemoveCb 方法尝试移除元素，并根据回调函数的返回值决定是否移除
				t.infoMap.RemoveCb(v.Key, func(
					key string,
					v *tcpPackageInfo,
					exists bool,
				) bool {
					// 如果元素不存在，不需要移除，返回 false
					if !exists {
						return false
					}
					// 计算当前时间与元素生存时间加上指定存活时长后的时间差
					// 如果时间差大于 0，说明元素已过期，需要移除，返回 true
					if time.Now().Sub(v.survivalTime.Load().Add(survivalTime)).Seconds() > 0 {
						v.isClose.Store(true)
						fmt.Println("tcpPackageInfoMap删除", key)
						return true
					}
					// 元素未过期，不需要移除，返回 false
					return false
				})
			}
		}
	}
}

// handleTcpFlowParseIPNQueue 方法用于处理 TCP 流解析 IP 队列中的数据。
// 该方法会从队列中取出数据，尝试解析其中的域名信息，并检查解析出的域名是否在黑名单中。
func (t *tcpPackageInfoMap) handleTcpFlowParseIPNQueue() {
	// 从 tcpFlowParseIPNQueue 队列中出队元素，并对每个元素执行传入的函数
	t.tcpFlowParseIPNQueue.DequeueFunc(func(f string, isClose bool) bool {
		// 如果队列已关闭，则停止处理
		if isClose {
			return false
		}

		// 从 infoMap 中获取与当前元素对应的 tcpPackageInfo 实例
		V, ok := t.infoMap.Get(f)
		// 初始化 ServerName 变量，用于存储解析出的域名
		ServerName := ""

		// 如果成功获取到 tcpPackageInfo 实例且不为空
		if ok && V != nil {
			// 获取该实例的负载数据
			r := V.GetPayLoadData()
			// 如果负载数据长度大于 0
			if len(r) > 0 {
				// 如果数据的第一个字节是 0x16，可能是 TLS 握手的 ClientHello 消息
				if r[0] == 0x16 {
					// 创建一个 ClientHelloMsg 实例
					clientHelloMsg := tls.ClientHelloMsg{}
					// 尝试将负载数据反序列化为 ClientHelloMsg 实例
					clientHelloMsg.UnmarshalByByte(r)
					// 如果反序列化后得到了 ServerName
					if clientHelloMsg.ServerName != "" {
						ServerName = clientHelloMsg.ServerName
					}
				}

				// 如果 ServerName 仍然为空，尝试解析 HTTP 协议
				if ServerName == "" {
					// 解析 HTTP 请求
					hr, err := http.ReadRequest(bufio.NewReader(bytes.NewReader(r)))
					// 如果解析成功
					if err == nil {
						// 从 HTTP 请求头中获取 Host 字段作为 ServerName
						ServerName = hr.Header.Get("Host")
					}
				}

				// 如果 ServerName 还是为空，使用正则表达式匹配域名
				if ServerName == "" {
					ServerName = regexpDomain(string(r))
					// 注释掉的代码，可用于调试输出解析匹配的域名
					// fmt.Println("解析匹配域名:", ServerName)
				}

				// 如果成功解析出 ServerName
				if ServerName != "" {
					// 打印解析出的域名
					fmt.Println(ServerName)
					// 将解析出的域名存储到 tcpPackageInfo 实例的 domain 字段中
					V.domain.Store(&ServerName)

					// 获取黑名单域名列表
					blackDomainList := t.getBlackDomainList()
					// 如果黑名单列表为空，继续处理下一个元素
					if len(blackDomainList) == 0 {
						return true
					}

					// 获取当前解析出的域名
					domain := ServerName
					// 如果域名不为空
					if domain != "" {
						// 遍历黑名单域名列表
						for _, blackDomain := range blackDomainList {
							// 检查当前域名是否包含黑名单中的域名
							if strings.Contains(domain, blackDomain) {
								V.isClose.Store(true)

								// t.infoMap.Upsert(
								// 	fmt.Sprint(
								// 		V.sourceAddress,
								// 		":",
								// 		V.sourcePort,
								// 		":",
								// 		V.destinationAddress,
								// 		":",
								// 		V.destinationPort,
								// 	),
								// 	nil,
								// 	// 该回调函数用于创建或更新 infoMap 中的值
								// 	func(
								// 		exist bool, // 表示键是否已存在于 infoMap 中
								// 		valueInMap *tcpPackageInfo, // infoMap 中已存在的旧值
								// 		newValue *tcpPackageInfo, // 传入的新值
								// 	) *tcpPackageInfo {
								// 		if exist {
								// 			valueInMap.isClose.Store(true)
								// 		}
								// 		return valueInMap
								// 	})
								// 找到匹配的黑名单域名后，跳出循环
								break
							}
						}
					}
				}
			}
		}
		// 继续处理下一个元素
		return true
	})
}

// regexpDomain 函数用于从给定的文本中提取域名。
// 它使用正则表达式匹配域名模式，如果找到匹配项，则返回第一个匹配到的域名；
// 如果没有找到匹配项，则返回空字符串。
// 参数：
//   - text: 待搜索域名的文本字符串
//
// 返回值：
//   - string: 匹配到的第一个域名，如果没有匹配项则返回空字符串
func regexpDomain(text string) string {
	// 编译一个正则表达式，用于匹配域名模式
	// 该正则表达式匹配由字母、数字、点和连字符组成，且以至少两个字母的顶级域名结尾的字符串
	domainRegex := regexp.MustCompile(`([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})`)
	// 在给定的文本中查找所有匹配该正则表达式的字符串，并返回捕获组的信息
	// -1 表示查找所有匹配项
	matches := domainRegex.FindAllStringSubmatch(text, -1)
	// 遍历所有匹配结果
	for _, match := range matches {
		// 遍历每个匹配结果中的捕获组
		for _, v := range match {
			// 返回第一个匹配到的域名
			return v
		}
	}
	// 如果没有找到匹配的域名，返回空字符串
	return ""
}
