package winDivert

import (
	"context"
	"errors"
	"fmt"
	"slices"
	"strings"
	"time"

	"github.com/lysShub/divert-go"
	net2 "github.com/shirou/gopsutil/net"
	"golang.org/x/sys/windows"
	"monitor/gvisor.dev/gvisor/pkg/tcpip/header"
	"monitor/log"
)

// handleIpPackageSendQueue 处理IP包发送队列
// 参数:
//
//	share - 队列分片索引
//
// 功能说明:
//  1. 从指定队列分片中取出IP包
//  2. 如果启用了限速且包不允许运行，则等待5ms
//  3. 通过WinDivert句柄发送数据包
func (dev *WinDivertDev) handleIpPackageSendQueue(share int) {
	queue := dev.ipPackageSendQueueSlices[share]

	// 定义出队处理函数
	processFunc := func(pkg *iPPackage, isClose bool) bool {
		if isClose {
			return false
		}

		if pkg.tcpPackageInfoData.isClose.Load() {
			return true
		}

		// 限速处理：如果启用限速且当前包不允许立即发送
		if dev.isSpeedLimit.Load() && !pkg.isRun {
			ctx, cancel := context.WithTimeout(dev.ctx, 5*time.Millisecond)
			defer cancel() // 确保上下文被取消

			<-ctx.Done() // 等待超时或上下文取消
		}

		if pkg.tcpPackageInfoData.isClose.Load() {
			return true
		}

		// 发送数据包
		_, err := dev.handle.Send(pkg.data, &pkg.addr)
		if err != nil {
			log.Errorf("[win_divert_task]  dev.handle.Send error:%+v", err)
		}

		return true
	}

	// 从队列中取出并处理数据包
	queue.DequeueFunc(processFunc)
}

// handlePackage 处理TCP数据包队列中的网络包
// 参数:
//
//	share - 队列分片索引
//
// 功能说明:
//  1. 从指定队列分片中取出TCP数据包
//  2. 区分出站包和入站包分别处理
//  3. 对SYN包进行特殊处理
//  4. 更新PID地址映射表
func (dev *WinDivertDev) handlePackage(share int) {
	queue := dev.tcpFlowParseIPNQueueSlices[share]

	// 定义包处理回调函数
	queue.DequeueFunc(func(pkg *packageData, isClose bool) bool {
		if isClose {
			return false
		}
		pktData := pkg.data

		// 处理出站包(本地发出的包)
		if pkg.isOut {
			ipHeader := header.IPv4(pktData)
			tcpHeader := header.TCP(ipHeader[ipHeader.HeaderLength():])

			// 提取连接四元组信息
			srcAddr := ipHeader.SourceAddress().String()
			srcPort := tcpHeader.SourcePort()
			dstAddr := ipHeader.DestinationAddress().String()
			dstPort := tcpHeader.DestinationPort()

			// 存储源地址
			dev.sourceAddress.Store(&srcAddr)

			// 处理SYN包
			// if header.TCPFlagSyn.Contains(tcpHeader.Flags()) {
			if tcpHeader.Flags().Contains(header.TCPFlagSyn) && !tcpHeader.Flags().Contains(header.TCPFlagAck) {

				isAllowed := false
				// 检查是否为放行的PID
				pids := dev.getReleasePids()
				if len(pids) > 0 {
					if conns, err := net2.Connections("tcp4"); err == nil && len(conns) > 0 {
						connKey := fmt.Sprintf("%s:%d:%s:%d", srcAddr, srcPort, dstAddr, dstPort)

						for _, conn := range conns {
							if connKey == fmt.Sprintf("%s:%d:%s:%d",
								conn.Laddr.IP, conn.Laddr.Port, conn.Raddr.IP, conn.Raddr.Port) {

								if slices.Contains(pids, uint32(conn.Pid)) {
									isAllowed = true
								}
								break
							}
						}
					}
				}

				// 不是放行的进程则交给TCP处理器处理
				if !isAllowed {
					dev.tcpPackageInfo.synTcp(srcAddr, srcPort, dstAddr, dstPort)
				}
			} else {
				// 处理非SYN包
				if !dev.tcpPackageInfo.localPackageHandle(
					srcAddr, srcPort, dstAddr, dstPort,
					tcpHeader.SequenceNumber(), tcpHeader.AckNumber(), tcpHeader.Payload(),
				) {
					return true
				}
			}
		} else {
			// 处理入站包(接收到的包)
			ipHeader := header.IPv4(pktData)
			tcpHeader := header.TCP(ipHeader[ipHeader.HeaderLength():])

			// tcp syn包 外部连接
			if tcpHeader.Flags().Contains(header.TCPFlagSyn) && !tcpHeader.Flags().Contains(header.TCPFlagAck) {
				connKey := fmt.Sprintf("%s:%d:%s:%d", ipHeader.DestinationAddress().String(), tcpHeader.DestinationPort(), ipHeader.SourceAddress().String(), tcpHeader.SourcePort())
				dev.tTLMap.Set(connKey)
				return true
			}

			if !dev.tcpPackageInfo.remotePackageHandle(
				ipHeader.DestinationAddress().String(),
				tcpHeader.DestinationPort(),
				ipHeader.SourceAddress().String(),
				tcpHeader.SourcePort(),
				tcpHeader.SequenceNumber(),
				tcpHeader.AckNumber(),
				tcpHeader.Payload(),
			) {
				return true
			}
		}

		return true
	})
}

// SetNetworkRunStatus 设置网络运行状态
// 参数:
//
//	s - 要设置的网络运行状态，布尔类型
//
// 返回值:
//
//	bool - 返回之前的网络运行状态
//
// 并发安全: 该方法使用原子操作保证线程安全
func (dev *WinDivertDev) SetNetworkRunStatus(s bool) bool {
	return dev.isNetworkCanRun.Swap(s)
}

// Run 启动 WinDivertDev 的相关任务
// 参数:
//
//	无
//
// 返回值:
//
//	无
//
// 并发安全: 使用 sync.Once 确保任务只执行一次
// 性能提示: 启动多个 goroutine 并发执行任务，可能会占用较多系统资源
func (dev *WinDivertDev) Run() {
	// 使用 sync.Once 确保任务只执行一次
	dev.runOnce.Do(func() {
		dev.tTLMap = NewTTLMap(3 * 30 * time.Second)
		dev.tTLMap.Start()

		// 启动多个 goroutine 处理数据包和 IP 数据包发送队列
		for i := 0; i < shareSize; i++ {
			// 复制索引 i 到局部变量 ii，避免闭包问题
			ii := i
			// 启动 goroutine 处理数据包
			dev.startTask(func() error {
				dev.handlePackage(ii)
				return nil
			})
			// 启动 goroutine 处理 IP 数据包发送队列
			dev.startTask(func() error {
				dev.handleIpPackageSendQueue(ii)
				return nil
			})
		}
		dev.startTask(func() error {
			dev.runFunc()
			return nil
		})
	})
}

// startTask 是一个辅助函数，用于启动任务并添加到错误等待组
// 参数:
//
//	task - 一个返回错误的函数，表示要执行的任务
//
// 返回值:
//
//	无
//
// 并发安全: 依赖传入的 task 函数的并发安全性
// 性能提示: 该函数仅负责启动任务，不影响整体性能
func (dev *WinDivertDev) startTask(task func() error) {
	dev.ewg.Go(task)
}

func (dev *WinDivertDev) runFunc() {
	// 启动 TCP 包信息处理
	dev.tcpPackageInfo.start()
	// 确保在函数结束时停止 TCP 包信息处理
	defer dev.tcpPackageInfo.stop()

	// 记录开始时间
	rTime := time.Now()
	// 获取流量上限
	remainingFlow := dev.flowUpperLimit.Load()
	var addr divert.Address

	for dev.run.Load() {
		// 接收数据包
		n, err := dev.handle.Recv(dev.tempBuf, &addr)
		if err != nil {
			log.Errorf("[win_divert_task] dev.handle.Recv error:%+v n:%d", err, n)
			// 若缓冲区不足，继续接收
			if errors.Is(err, windows.ERROR_INSUFFICIENT_BUFFER) {
				continue
			}
			// 其他错误则退出函数
			// return
		}
		// 若接收到的数据包长度为 0，继续接收
		if n == 0 {
			continue
		}
		// 处理外出的包
		if addr.Outbound() {
			dev.handleOutboundPackage(n, &addr, &rTime, &remainingFlow)
			continue
		}

		// 处理进来的包
		dev.handleInboundPackage(n, &addr, &rTime, &remainingFlow)
	}
}

func (dev *WinDivertDev) handleOutboundPackage(n int, addr *divert.Address, rTime *time.Time, remainingFlow *int64) {
	if n >= header.IPv4MinimumSize+header.TCPMinimumSize {
		// 复制接收到的数据
		dataCopy := append([]byte(nil), dev.tempBuf[:n]...)
		// 解析 IP 头
		iphdr := header.IPv4(dev.tempBuf[:n])
		// 解析 TCP 头
		tcphdr := header.TCP(iphdr[iphdr.HeaderLength():])
		// 获取源端口
		port := tcphdr.SourcePort()
		// 计算共享索引
		share := int(port % shareSize)
		// 生成键用于查找
		key := fmt.Sprintf("%s:%d:%s:%d", iphdr.SourceAddress().String(), port, iphdr.DestinationAddress().String(), tcphdr.DestinationPort())

		if tcphdr.Flags().Contains(header.TCPFlagSyn) && !tcphdr.Flags().Contains(header.TCPFlagAck) {
			dev.tcpPackageInfo.deleteTcpPackageInfoOnSyncPackage(key)
		}

		// 推送 TCP 流解析队列
		dev.pushTcpFlowParseIPNQueue(share, &packageData{
			isOut: true,
			data:  dataCopy,
		})

		tcpPackageInfoData, ok := dev.tcpPackageInfo.Get(key)

		if !ok {
			dev.handle.Send(dataCopy, addr)
			return
		} else {
			if tcpPackageInfoData.isClose.Load() {
				return
			}
		}

		if !dev.isNetworkCanRun.Load() {
			return
		}

		// 处理限速逻辑
		isRun := true
		if dev.isSpeedLimit.Load() {
			if !dev.tcpPackageInfo.has(key) {
				dev.handle.Send(dataCopy, addr)
				return
			}
			payloadLen := len(tcphdr.Payload())
			if payloadLen > 0 {
				isRun = false
				if time.Since(*rTime) > time.Second {
					*rTime = time.Now()
					*remainingFlow = dev.flowUpperLimit.Load()
				}
				*remainingFlow -= int64(payloadLen)
				if *remainingFlow > 0 {
					isRun = true
				}
			}
		}

		// 推送 IP 包发送队列
		dev.pushIpPackageSendQueue(share, &iPPackage{
			isRun: isRun,
			data:  dataCopy,
			addr:  *addr,

			tcpPackageInfoData: tcpPackageInfoData,
		})
	}
}

func (dev *WinDivertDev) handleInboundPackage(n int, addr *divert.Address, rTime *time.Time, remainingFlow *int64) {
	if n >= header.IPv4MinimumSize+header.TCPMinimumSize {
		// 复制接收到的数据
		dataCopy := append([]byte(nil), dev.tempBuf[:n]...)
		// 解析 IP 头
		iphdr := header.IPv4(dev.tempBuf[:n])
		// 解析 TCP 头
		tcphdr := header.TCP(iphdr[iphdr.HeaderLength():])
		// 获取目的端口
		port := tcphdr.DestinationPort()
		// 计算共享索引
		share := int(port % shareSize)
		// 生成键用于查找
		key := fmt.Sprintf("%s:%d:%s:%d", iphdr.DestinationAddress().String(), port, iphdr.SourceAddress().String(), tcphdr.SourcePort())

		// 推送 TCP 流解析队列
		dev.pushTcpFlowParseIPNQueue(share, &packageData{
			isOut: false,
			data:  dataCopy,
		})

		tcpPackageInfoData, ok := dev.tcpPackageInfo.Get(key)

		if !ok {
			if has, isClose := dev.tTLMap.Get(key); has && isClose {
				return
			}
			dev.handle.Send(dataCopy, addr)
			return
		} else {
			if tcpPackageInfoData.isClose.Load() {
				return
			}
		}

		if !dev.isNetworkCanRun.Load() {
			return
		}

		// 处理限速逻辑
		isRun := true
		if dev.isSpeedLimit.Load() {
			if !dev.tcpPackageInfo.has(key) {
				dev.handle.Send(dataCopy, addr)
				return
			}
			payloadLen := len(tcphdr.Payload())
			if payloadLen > 0 {
				isRun = false
				if time.Since(*rTime) > time.Second {
					*rTime = time.Now()
					*remainingFlow = dev.flowUpperLimit.Load()
				}
				*remainingFlow -= int64(payloadLen)
				if *remainingFlow > 0 {
					isRun = true
				}
			}
		}

		// 推送 IP 包发送队列
		dev.pushIpPackageSendQueue(share, &iPPackage{
			isRun: isRun,
			data:  dataCopy,
			addr:  *addr,

			tcpPackageInfoData: tcpPackageInfoData,
		})
	}
}

func (dev *WinDivertDev) CloseLocalPort(port int) {
	dev.tTLMap.TraverseClose(func(key string) bool {
		parts := strings.Split(key, ":")
		if len(parts) == 4 {
			if parts[1] == fmt.Sprint(port) {
				return true
			}
		}

		return false
	})
}

// Close 方法用于关闭 WinDivertDev 相关资源
// 该方法会等待所有 goroutine 完成，取消相关操作，关闭队列，
// 停止运行标志，关闭接口句柄等操作
// 返回值：
//
//	error - 如果在关闭过程中出现错误，则返回错误信息；如果关闭成功，返回 nil
func (dev *WinDivertDev) Close() (error, error) {
	// 等待所有 goroutine 完成任务
	defer func() {
		dev.ewg.Wait()
		fmt.Println("---------------关闭WinDivertDev---------------------")
	}()
	// 取消相关操作
	dev.cancel()

	// 遍历关闭 tcpFlowParseIPNQueueSlices 和 ipPackageSendQueueSlices 中的所有队列
	for i := 0; i < shareSize; i++ {
		dev.tcpFlowParseIPNQueueSlices[i].Close()
		dev.ipPackageSendQueueSlices[i].Close()
	}

	// 将运行标志设置为 false
	dev.run.Swap(false)
	dev.tTLMap.Stop()

	return dev.handle.Shutdown(divert.Both), dev.handle.Close()
}
