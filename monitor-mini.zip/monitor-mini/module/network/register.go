package network

import (
	"slices"

	"monitor/controlCenter/common"
	. "monitor/protocol"
)

// Name 是网络模块的名称
const Name = "Network"

// handleMsgs 定义了该模块需要处理的消息 ID 列表
// 这些消息 ID 涵盖了如网页禁用、启用，网络选项，限速等相关消息
var handleMsgs []MsgId = []MsgId{
	MsgIdMonitorWebDisable,             // 处理网页禁用消息
	MsgIdMonitorWebEnable,              // 处理网页启用消息
	MsgIdMonitorNetworkOpt,             // 处理网络选项消息
	MsgIdMonitorLimitNetSpeed,          // 处理网络限速消息
	MsgIdMonitorGetNetworkOpt,          // 获取网络选项消息
	MsgIdMonitorGetLimitNetSpeed,       // 获取网络限速消息
	MsgIdMonitorGetMonitorProjectInfo,  // 28 获取当前坐席版本消息
	MsgIdMonitorPushMonitorProjectInfo, // 29 推送当前坐席版本消息
	MsgIdMonitorRdpPushQuitReq,         // 36 网关推送监控Rdp退出
}

// Strat 函数用于启动网络模块
// 它创建一个 manager 实例，并调用其 Start 方法启动模块
// 参数 cc 是一个通用的模块 API，用于与其他模块进行交互
// 返回值为错误信息，如果启动过程中出现错误则返回相应的错误，否则返回 nil
func Strat(cc common.ModuleApi) error {
	mm := &manager{}
	return mm.Start(cc)
}

// init 是 Go 语言的初始化函数，在包被导入时自动执行
// 此函数用于注册网络模块，将模块的名称、启动函数和需要处理的消息 ID 列表注册到通用的消息处理模块中
// 这样，当相应的消息到来时，就可以由该模块进行处理
func init() {
	common.RegisterMsgHandlerModule(
		Name,
		&common.ModuleRegister{
			// StartFn 是模块的启动函数，这里指定为 Strat
			StartFn: Strat,
			// Msgs 是模块需要处理的消息 ID 列表
			// 使用 slices.Clone 复制 handleMsgs 列表，避免修改原始列表
			// 使用 slices.Compact 去除列表中的空元素，确保列表的干净和有效
			Msgs: slices.Compact(slices.Clone(handleMsgs)),
		})
}
