package network

import (
	"context"
	"fmt"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/robfig/cron/v3"

	"monitor/controlCenter/common"
	"monitor/env"
	"monitor/log"
	"monitor/module/network/capture/winDivert"
	"monitor/protobuf"
	. "monitor/protocol"
	"monitor/utils/registry"
)

// manager 结构体用于管理网络监控相关的功能
// 包含上下文、模块 API、移动时间、浏览器列表、临时目录和定时任务调度器等信息
type manager struct {
	ctx       context.Context
	moduleApi common.ModuleApi
	mvTime    time.Duration
	browsers  []string
	tempDir   string
	cronT     *cron.Cron
}

// Start 方法用于启动网络监控管理功能
// 该方法会初始化定时任务，启动 WinDivert 设备，并处理模块消息
func (m *manager) Start(cc common.ModuleApi) error {
	// 创建一个可取消的上下文
	ctxt, cancel := context.WithCancel(cc.GetContext())
	// 确保在函数返回时取消上下文
	defer cancel()
	m.ctx = ctxt
	m.moduleApi = cc
	// 用于等待所有 goroutine 完成
	var wg sync.WaitGroup

	// 初始化定时任务调度器
	{
		m.cronT = cron.New(cron.WithSeconds())
		m.cronT.Start()

		// 延迟 发送消息获取禁用地址、网络选项和网络限速
		time.AfterFunc(20*time.Second, func() {
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetDisableDomain, nil) // 15获取禁用地址
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetNetworkOpt, nil)    // 获取实例是否断网
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetLimitNetSpeed, nil) // 获取实例网络限速
		})

		// 每 5 分钟执行一次，发送消息获取禁用地址、网络选项和网络限速
		m.cronT.Schedule(cron.Every(60*5*time.Second), cron.FuncJob(func() {
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetDisableDomain, nil) // 15获取禁用地址
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetNetworkOpt, nil)    // 获取实例是否断网
			m.moduleApi.WriteProtoMessage(MsgIdMonitorGetLimitNetSpeed, nil) // 获取实例网络限速
		}))
	}

	// 确保在函数返回时停止定时任务调度器并等待所有任务完成
	defer func() {
		ctx := m.cronT.Stop()
		// 等待定时任务完全结束
		<-ctx.Done()

		wg.Wait()
		fmt.Println("----------------network关闭------------------")
	}()

	// 创建 WinDivert 设备实例
	winDivertDev, err := winDivert.NewWinDivertDev(
		m.moduleApi,
	)
	if err != nil {
		log.Errorf("NewWinDivertDev err = %s", err)
		return err
	}

	// 添加放行的 PID
	winDivertDev.AddReleasePid(uint32(os.Getpid()))
	winDivertDev.AddReleasePid(env.ParentPid)
	// 启动 WinDivert 设备
	winDivertDev.Run()
	// 确保在函数返回时关闭 WinDivert 设备
	defer winDivertDev.Close()

	// 定义循环时间为 5 秒
	cycleTime := 5 * time.Second
	// 创建一个定时器
	timer := time.NewTimer(cycleTime)
	// 确保在退出时停止定时器
	defer timer.Stop()

	// 确保在函数返回时取消上下文
	defer cancel()
	fmt.Println("----------------network启动------------------")
	for {
		select {
		// 当上下文被取消时，退出循环
		case <-cc.GetContext().Done():
			return nil
		// 从模块 API 获取消息
		case moduleMsg, ok := <-m.moduleApi.GetMsg():
			if !ok {
				return nil
			}

			if moduleMsg == nil {
				continue
			}

			// 根据消息的路由 ID 进行不同的处理
			switch moduleMsg.RouteMsgId {
			case MsgIdMonitorWebDisable: // 地址禁止访问
				if moduleMsg.Data != nil {
					// 检查监控项目是否开启
					if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorWebStrategy) {
						winDivertDev.SetBlackDomainList([]string(nil))
					} else {
						// 类型断言，确保数据类型正确
						if mm, ok := moduleMsg.Data.(*protobuf.DisableWebRequest); ok && mm != nil {
							Address := []string{}
							log.Infof(" [network]  MsgIdMonitorWebDisable Data = %s", mm.Address)
							for _, u := range mm.Address {
								parsedURL, err := url.Parse(u)
								if err == nil && parsedURL.Hostname() != "" {
									Address = append(Address, parsedURL.Hostname())
								} else {
									Address = append(Address, replacePrefix(u, "www.", ""))
								}
							}
							log.Infof(" [network]  MsgIdMonitorWebDisable 处理后的数据  Data = %s", Address)

							winDivertDev.SetBlackDomainList(Address)
						}
					}
				}
			case MsgIdMonitorWebEnable: // 地址允许访问

			case MsgIdMonitorNetworkOpt: // 断网  OptType = 1; // 1:断网；2：联网
				if moduleMsg.Data != nil {
					// 检查监控项目是否开启
					if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorNetWorkStrategy) {
						winDivertDev.SetNetworkRunStatus(true)
					} else {
						// 类型断言，确保数据类型正确
						if mm, ok := moduleMsg.Data.(*protobuf.MonitorNetworkOpt); ok && mm != nil {
							log.Infof(" [network]  MsgIdMonitorNetworkOpt Data = %+v", mm)
							s := true
							if mm.OptType == 1 {
								s = false
							}
							winDivertDev.SetNetworkRunStatus(s)
						}
					}
				}

			case MsgIdMonitorLimitNetSpeed:
				if moduleMsg.Data != nil {
					// 检查监控项目是否开启
					if !m.moduleApi.ExistsMonitorProjectTurnOn(common.MonitorNetWorkStrategy) {
						winDivertDev.SetSpeedLimit(uint64(0))
					} else {
						// 类型断言，确保数据类型正确
						if mm, ok := moduleMsg.Data.(*protobuf.LimitNetSpeed); ok && mm != nil {
							log.Infof(" [network]  MsgIdMonitorLimitNetSpeed Data = %+v", mm)
							winDivertDev.SetSpeedLimit(uint64(mm.NetSpeed))
						}
					}
				}

			case MsgIdMonitorRdpPushQuitReq: // 36 网关推送监控Rdp退出
				port, err := registry.GetRDPPort()
				if err != nil {
					log.Errorf("[network] 获取rdp端口出错:%v", err)
				} else {
					log.Infof("[network] 获取rdp端口成功:%d", port)
					winDivertDev.CloseLocalPort(port)
				}

			default:
			}

		case <-timer.C:
			// 定时器到期，重置定时器
			timer.Reset(cycleTime)
		}
	}
}

func replacePrefix(s, old, new string) string {
	if strings.HasPrefix(s, old) {
		if s[:len(old)] == old {
			return s[len(old):] // 替换开头并拼接剩余部分
		}
	}
	return s // 开头不匹配，直接返回原字符串
}
