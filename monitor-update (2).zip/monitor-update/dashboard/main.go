package dashboard

import (
	"fmt"
	"image/color"
	"image/png"
	"log"
	 "math/rand"
 "time"
	"runtime"
	"sync"
	"sync/atomic"
	"syscall"
	"unsafe"
	//"encoding/json"
	"github.com/jthmath/winapi"
	"os"
	"golang.org/x/sys/windows"
)

const (
	screenWidth  = 1000
	screenHeight = 1000
)

var (
	showText      = ""
	backgroundBmp = ""
)

var (
	dll_gdi                = syscall.NewLazyDLL("gdi32.dll")
	dll_user               = syscall.NewLazyDLL("user32.dll")
	procCreateRoundRectRgn = dll_gdi.NewProc("CreateRoundRectRgn")
	procSetWindowRgn       = dll_user.NewProc("SetWindowRgn")
	procSetBkMode          = dll_gdi.NewProc("SetBkMode")
	procSetTextColor       = dll_gdi.NewProc("SetTextColor")
	procDrawText           = dll_user.NewProc("DrawTextW")
	procGetClientRect      = dll_user.NewProc("GetClientRect")
	procCreatePen          = dll_gdi.NewProc("CreatePen")
	procCreateSolidBrush   = dll_gdi.NewProc("CreateSolidBrush")
	procRoundRect          = dll_gdi.NewProc("RoundRect")
	procSelectObject       = dll_gdi.NewProc("SelectObject")
	procDeleteObject       = dll_gdi.NewProc("DeleteObject")
	procPostMessage        = dll_user.NewProc("PostMessageW")
	procGetSystemMetrics   = dll_user.NewProc("GetSystemMetrics")
	procInvalidateRect     = dll_user.NewProc("InvalidateRect")
	procUpdateWindow       = dll_user.NewProc("UpdateWindow")
	setPixel               = dll_gdi.NewProc("SetPixel") // 绘制单个像素
		CreateBitmap     = dll_gdi.NewProc("CreateBitmap")


	hBitmap winapi.HBITMAP // 全局变量
)
// 24位RGB像素（GDI中存储顺序为BGR）
type RGBPixel struct {
	A byte
	B byte // 蓝色分量
	G byte // 绿色分量
	R byte // 红色分量
}

// 补充缺失的GDI函数绑定
var (
	procGetDC                  = dll_user.NewProc("GetDC")
	procReleaseDC              = dll_user.NewProc("ReleaseDC")
	procCreateCompatibleBitmap = dll_gdi.NewProc("CreateCompatibleBitmap")
	procRectangle              = dll_gdi.NewProc("Rectangle")
)

func getDC(hwnd syscall.Handle) (syscall.Handle, error) {
	ret, _, err := procGetDC.Call(uintptr(hwnd))
	if ret == 0 {
		return 0, err
	}
	return syscall.Handle(ret), nil
}

func releaseDC(hwnd, hdc syscall.Handle) int {
	ret, _, _ := procReleaseDC.Call(uintptr(hwnd), uintptr(hdc))
	return int(ret)
}

func createCompatibleBitmap(hdc syscall.Handle, width, height int) (winapi.HBITMAP, error) {
	ret, _, err := procCreateCompatibleBitmap.Call(
		uintptr(hdc),
		uintptr(width),
		uintptr(height),
	)
	if ret == 0 {
		return 0, err
	}
	return winapi.HBITMAP(ret), nil
}

func rectangle(hdc syscall.Handle, left, top, right, bottom int) bool {
	ret, _, _ := procRectangle.Call(
		uintptr(hdc),
		uintptr(left),
		uintptr(top),
		uintptr(right),
		uintptr(bottom),
	)
	return ret != 0
}

var (
	rwMutex    sync.RWMutex
	windowHWND winapi.HWND
	isClose    atomic.Bool
)

var (
	uncompressedSize atomic.Uint64
	totalSize        atomic.Uint64
)

func CloseWindow() {
	isClose.Store(true)
	rwMutex.RLock()
	windowHWNDTmp := windowHWND
	rwMutex.RUnlock()
	if windowHWNDTmp > 0 {
		PostMessage(syscall.Handle(windowHWNDTmp), winapi.WM_DESTROY, uintptr(0), uintptr(0))
	}
}

func UpdateWindow(a, b uint64) {
	rwMutex.RLock()
	windowHWNDTmp := windowHWND
	rwMutex.RUnlock()
	uncompressedSize.Store(a)
	totalSize.Store(b)
	if windowHWNDTmp > 0 {
		InvalidateRect(syscall.Handle(windowHWNDTmp), nil, true)
		winapi.UpdateWindow(windowHWNDTmp)
	}
}

const (
	DT_CENTER     = 0x00000001
	DT_VCENTER    = 0x00000004
	DT_SINGLELINE = 0x00000020
	SM_CXSCREEN   = 0
	SM_CYSCREEN   = 1
)

func RunMain(b string) (<-chan error, error) {
	backgroundBmp = b
	inst, err := winapi.GetModuleHandle("")
	if err != nil {
		log.Println("获取实例失败")
		return nil, err
	}
	errChan := make(chan error, 1)

	go func() {
		defer close(errChan)
		WinMain(inst, "", 0, errChan)
	}()
	return errChan, nil
}

func WinMain(Inst winapi.HINSTANCE, Cmd string, nCmdShow int32, errChan chan error) int32 {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	var err error

	// 1. 注册窗口类
	atom, err := MyRegisterClass(Inst)
	if err != nil {
		log.Println("注册窗口类失败")
		errChan <- err
		return 0
	}
	log.Println("注册窗口类成功", atom)

	width, err := GetSystemMetrics(SM_CXSCREEN)
	if err != nil {
		log.Printf("Error getting screen width: %s\n", err)
		errChan <- err
		return 0
	}
	height, err := GetSystemMetrics(SM_CYSCREEN)
	if err != nil {
		log.Printf("Error getting screen height: %s\n", err)
		errChan <- err
		return 0
	}

	// 2. 创建窗口
	wnd, err := winapi.CreateWindow("主窗口类", "golang windows 编程",
		winapi.WS_OVERLAPPED|winapi.WS_POPUP|winapi.WS_EX_LAYERED, 0,
		int32((width-screenWidth)/2), int32((height-screenHeight)/2), screenWidth, screenHeight+100,
		0, 0, Inst, 0)
	if err != nil {
		log.Println("创建窗口失败")
		errChan <- err
		return 0
	}
	log.Println("创建窗口成功", wnd)

	rwMutex.Lock()
	windowHWND = wnd
	rwMutex.Unlock()
	///制造圆角
	region, err := CreateRoundRectRgn(0, 0, screenWidth+2, screenHeight+2+100, 20, 20)
	if err != nil {
		log.Println("Error creating region:", err)
		errChan <- err
		return 0
	}
	// true 表示操作后需要重绘
	if err := SetWindowRgn(syscall.Handle(wnd), region, true); err != nil {
		log.Println("SetWindowRgn failed:", err)
		errChan <- err
		return 0
	}
	///制造圆角

	errChan <- nil

	winapi.ShowWindow(wnd, winapi.SW_SHOW)
	winapi.UpdateWindow(wnd)

	// 3. 主消息循环
	var msg winapi.MSG
	msg.Message = winapi.WM_QUIT + 1 // 让它不等于 winapi.WM_QUIT

	for winapi.GetMessage(&msg, 0, 0, 0) > 0 {
		winapi.TranslateMessage(&msg)
		winapi.DispatchMessage(&msg)
	}

	return int32(msg.WParam)
}

var HHhWnd winapi.HWND

func WndProc(hWnd winapi.HWND, message uint32, wParam uintptr, lParam uintptr) uintptr {
	// var hTemp winapi.HANDLE

	switch message {
	case winapi.WM_CREATE:
		// hTemp, _ = winapi.LoadImageByName(
		// 	0, backgroundBmp,
		// 	winapi.IMAGE_BITMAP, 0, 0,
		// 	winapi.LR_LOADFROMFILE,
		// )
		// hBitmap = winapi.HBITMAP(hTemp)

		// 获取窗口客户区大小
		HHhWnd = hWnd
		TTtt(hWnd)

	case winapi.WM_PAINT:
		if totalSize.Load() > 0 {
			proportion := float64(uncompressedSize.Load() / totalSize.Load())
			OnPaint(hWnd, showText, proportion)
		} else {
			OnPaint(hWnd, showText, 0)
		}
	case winapi.WM_CLOSE:
		if isClose.Load() {
			break
		}
		return 0
	case winapi.WM_DESTROY:
		if hBitmap != 0 {
			DeleteObject(syscall.Handle(hBitmap))
		}

		winapi.PostQuitMessage(0)

	case winapi.WM_COMMAND:
		OnCommand(hWnd, wParam, lParam)

	default:

	}
	return winapi.DefWindowProc(hWnd, message, wParam, lParam)
}

func OnPaint(hWnd winapi.HWND, text string, proportion float64) {
	var err error
	var ps winapi.PAINTSTRUCT
	var rect RECT
	GetClientRect(syscall.Handle(hWnd), &rect)

	hdc, err := winapi.BeginPaint(hWnd, &ps)
	if err != nil {
		return
	}
	defer winapi.EndPaint(hWnd, &ps) // defer 终于有用武之地了

	mdc, err := winapi.CreateCompatibleDC(hdc)
	if err != nil {
		return
	}
	defer winapi.DeleteDC(mdc)
	winapi.SelectObject(mdc, winapi.HGDIOBJ(hBitmap))
	// 这个函数的第4、5个参数分别是图片的宽、高
	// 为了简便起见，我直接写在了这里
	// 实际项目中当然要用过程序获取一下
	winapi.BitBlt(hdc, 0, 0, rect.Right-rect.Left, rect.Bottom-rect.Top, mdc, 0, 0, winapi.SRCCOPY)
}

func OnCommand(hWnd winapi.HWND, wParam uintptr, lParam uintptr) {
	// 暂时不需要特殊处理 WM_COMMAND
	winapi.DefWindowProc(hWnd, winapi.WM_COMMAND, wParam, lParam)
}

func MyRegisterClass(hInstance winapi.HINSTANCE) (atom uint16, err error) {
	var wc winapi.WNDCLASS
	wc.Style = winapi.CS_HREDRAW | winapi.CS_VREDRAW
	wc.PfnWndProc = WndProc
	wc.CbClsExtra = 0
	wc.CbWndExtra = 0
	wc.HInstance = hInstance

	// wc.HIcon, err = winapi.LoadIconById(hInstance,IDI_MY_APP_ICON)
	// 	if err != nil {
	// 				log.Println(" winapi.LoadIconByName failed:", err)
	// 	return
	// }
	// wc.HIconSmall,err = winapi.LoadIconById(hInstance,IDI_MY_APP_ICON)
	// 	if err != nil {
	// 				log.Println(" winapi.LoadIconByName failed:", err)
	// 	return
	// }

	wc.HCursor, err = winapi.LoadCursorById(0, winapi.IDC_ARROW)
	if err != nil {
		return
	}
	//   wc.HbrBackground = winapi.COLOR_WINDOW + 1
	// wc.HbrBackground = 0

	wc.Menu = uint16(0)
	wc.PszClassName = "主窗口类"

	return winapi.RegisterClass(&wc)
}

func CreateRoundRectRgn(nLeftRect, nTopRect, nRightRect, nBottomRect, nWidthEllipse, nHeightEllipse int) (syscall.Handle, error) {
	ret, _, err := procCreateRoundRectRgn.Call(
		uintptr(nLeftRect),
		uintptr(nTopRect),
		uintptr(nRightRect),
		uintptr(nBottomRect),
		uintptr(nWidthEllipse),
		uintptr(nHeightEllipse),
	)
	if ret == 0 {
		return 0, err
	}
	return syscall.Handle(ret), nil
}

func SetWindowRgn(hwnd syscall.Handle, hRgn syscall.Handle, bRedraw bool) error {
	redraw := 0
	if bRedraw {
		redraw = 1
	}

	ret, _, err := procSetWindowRgn.Call(
		uintptr(hwnd),
		uintptr(hRgn),
		uintptr(redraw),
	)
	if ret == 0 {
		return err
	}
	return nil
}

func SetTextColor(hdc syscall.Handle, color uint32) (uint32, error) {
	ret, _, err := procSetTextColor.Call(
		uintptr(hdc),
		uintptr(color),
	)
	if int(ret) == -1 {
		return uint32(ret), err
	}
	return uint32(ret), nil
}

func SetBkMode(hdc syscall.Handle, mode int) (int, error) {
	ret, _, err := procSetBkMode.Call(
		uintptr(hdc),
		uintptr(mode),
	)
	if ret == 0 {
		return 0, err
	}
	return int(ret), nil
}

// DrawText draws text in the specified rectangle using the specified device context.
func DrawText(hdc syscall.Handle, text string, rect *RECT, format uint) (int, error) {
	lpText := syscall.StringToUTF16Ptr(text)
	nCount := -1
	ret, _, err := procDrawText.Call(
		uintptr(hdc),
		uintptr(unsafe.Pointer(lpText)),
		uintptr(nCount), // The number of characters in the string. If -1, the string must be null-terminated.
		uintptr(unsafe.Pointer(rect)),
		uintptr(format),
	)
	if ret == 0 {
		return 0, err
	}
	return int(ret), nil
}

// RECT defines the coordinates of the upper-left and lower-right corners of a rectangle.
type RECT struct {
	Left   int32
	Top    int32
	Right  int32
	Bottom int32
}

func GetClientRect(hwnd syscall.Handle, rect *RECT) bool {
	ret, _, _ := procGetClientRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(rect)),
	)
	return ret != 0
}

// CreatePen creates a logical pen that has the specified style, width, and color.
// The pen can subsequently be selected into a device context and used to draw lines and curves.
func CreatePen(style, width int, color uint32) (syscall.Handle, error) {
	ret, _, err := procCreatePen.Call(
		uintptr(style),
		uintptr(width),
		uintptr(color),
	)
	if ret == 0 {
		return 0, err
	}
	return syscall.Handle(ret), nil
}

// CreateSolidBrush creates a logical brush that has the specified solid color.
func CreateSolidBrush(color uint32) (syscall.Handle, error) {
	ret, _, err := procCreateSolidBrush.Call(
		uintptr(color),
	)
	if ret == 0 {
		return 0, err
	}
	return syscall.Handle(ret), nil
}

func RoundRect(hdc syscall.Handle, nLeftRect, nTopRect, nRightRect, nBottomRect, nWidthEllipse, nHeightEllipse int32) bool {
	ret, _, _ := procRoundRect.Call(
		uintptr(hdc),
		uintptr(nLeftRect),
		uintptr(nTopRect),
		uintptr(nRightRect),
		uintptr(nBottomRect),
		uintptr(nWidthEllipse),
		uintptr(nHeightEllipse),
	)
	return ret != 0
}

func DeleteObject(hObject syscall.Handle) error {
	ret, _, err := procDeleteObject.Call(
		uintptr(hObject),
	)
	if ret == 0 {
		return err
	}
	return nil
}

func SelectObject(hdc syscall.Handle, h syscall.Handle) syscall.Handle {
	ret, _, _ := procSelectObject.Call(
		uintptr(hdc),
		uintptr(h),
	)
	return syscall.Handle(ret)
}

func RGB(red, green, blue byte) uint32 {
	return uint32(red) | uint32(green)<<8 | uint32(blue)<<16
}

// that created the specified window and returns without waiting for the thread to process the message.
func PostMessage(hWnd syscall.Handle, Msg uint32, wParam, lParam uintptr) bool {
	ret, _, _ := procPostMessage.Call(
		uintptr(hWnd),
		uintptr(Msg),
		wParam,
		lParam,
	)
	return ret != 0
}

func GetSystemMetrics(nIndex int) (int, error) {
	ret, _, callErr := procGetSystemMetrics.Call(uintptr(nIndex))
	if callErr != nil {
		if callErr.Error() != "The operation completed successfully." {
			return 0, callErr
		}
	}
	return int(ret), nil
}

func InvalidateRect(hwnd syscall.Handle, rect *RECT, bErase bool) bool {
	ret, _, _ := procInvalidateRect.Call(
		uintptr(hwnd),
		uintptr(unsafe.Pointer(rect)),
		uintptr(boolToBOOL(bErase)),
	)
	return ret != 0
}

func boolToBOOL(value bool) uint32 {
	if value {
		return 1
	}
	return 0
}

var pixelspixels [][]color.RGBA

func init() {
	filePath := "./test.png" // 替换为你的图片路径（支持 png/jpg 等）
	pixels, err := getImagePixels(filePath)
	if err != nil {
		fmt.Println("错误:", err)
		return
	}

	pixelspixels = pixels
}

func TTtt(hWnd winapi.HWND) {
	var rect RECT
	GetClientRect(syscall.Handle(hWnd), &rect)
	width := rect.Right - rect.Left
	height := rect.Bottom - rect.Top

	// 获取设备上下文（改用user32.dll的GetDC）
	hdc, err := getDC(syscall.Handle(hWnd))
	if err != nil {
		log.Println("GetDC failed:", err)
		return
	}
	defer releaseDC(syscall.Handle(hWnd), hdc)
	// 创建兼容的内存DC
	// mdc, err := winapi.CreateCompatibleDC(winapi.HDC(hdc))
	// if err != nil {
	// 	log.Println("CreateCompatibleDC failed:", err)
	// 	return
	// }
	// defer winapi.DeleteDC(mdc)
	if hBitmap == 0 {
		// 创建空白位图（改用gdi32.dll的CreateCompatibleBitmap）
		hBitmap, err = createCompatibleBitmap(hdc, int(width), int(height))
		if err != nil {
			log.Println("CreateCompatibleBitmap failed:", err)
			return
		}
pixelCount := int(width * height)
	pixels := make([]RGBQUAD, pixelCount)

	// 填充像素（示例：红色到蓝色的渐变）
	for y := int32(0); y < height; y++ {
		for x := int32(0); x < width; x++ {
			idx := y*width + x
			// 红色分量随 x 增加而增加，蓝色分量随 y 增加而增加
			pixels[idx] = RGBQUAD{
				RgbRed:   byte(255),   // 红：左→右渐变
				RgbGreen: byte(255),  
				RgbBlue:  byte(54),  // 蓝：上→下渐变
				RgbReserved:0,
			}
		}
	}

		// 1. 位图参数（200x200像素，24位RGB）
	//  	width = 1000
	// 		height =500
	// 	bitsPerPixel := uint32(32) // 24位RGB（每个像素3字节）
	// 	planes := uint32(1)


	// 	pixelCount := width * height
	// 	pixels := make([]RGBPixel, pixelCount) // 每个像素3字节（BGR）

	// 	// 生成渐变色：左上角红色 → 右上角绿色 → 左下角蓝色 → 右下角黄色
	// 	for y := int32(0); y < height; y++ {
	// 		for x := int32(0); x < width; x++ {
	// 			idx := y*width + x
	// 			// 红色分量：随y增加减弱
	// 			r := byte(rand.Intn(10))
	// 			// 绿色分量：随x增加增强
	// 			g := byte(rand.Intn(10))
	// 			// 蓝色分量：随y增加增强
	// 			b := byte(rand.Intn(10))
	// 			// 存储为BGR格式（GDI要求）
	// 			pixels[idx] = RGBPixel{B: b, G: g, R: r}
	// 		}
	// 	}


	// // 将RGBPixel切片转换为字节指针
	// 	pixelPtr := uintptr(unsafe.Pointer(&pixels[0]))
	// 	ret, _, err := CreateBitmap.Call(
	// 		uintptr(width),
	// 		uintptr(height),
	// 		uintptr(planes),
	// 		uintptr(bitsPerPixel),
	// 		pixelPtr,
	// 	)
	// 	if ret == 0  {
	// 		fmt.Println(ret)
	// 		panic("CreateBitmap 失败: " + err.Error())
	// 	}
	// 	hBitmap = winapi.HBITMAP(ret)  


	// 4. 构造 BITMAPINFO（描述 32 位无压缩位图）
	bmpInfo := BITMAPINFO{
		BmiHeader: BITMAPINFOHEADER{
			BiSize:        uint32(unsafe.Sizeof(BITMAPINFOHEADER{})),
			BiWidth:       width,
			BiHeight:      -height, // 负号表示像素数据从上到下（与屏幕坐标一致）
			BiPlanes:      1,
			BiBitCount:    32, // 32位色（含 Alpha 通道）
			BiCompression: 0,  // BI_RGB（不压缩）
		},
	}

	// 5. 调用 SetDIBits 将像素数据写入位图
	// 函数原型：int SetDIBits(HDC hdc, HBITMAP hbmp, UINT start, UINT cLines, const void *lpBits, const BITMAPINFO *lpbmi, UINT usage);
	 rr,_,_:= syscall.Syscall9(
		windows.NewLazySystemDLL("gdi32.dll").NewProc("SetDIBits").Addr(),
		7,
		uintptr(hdc),                  // hdc
		uintptr(hBitmap),              // hbmp
		uintptr(0),                             // start（起始扫描线）
		uintptr(height),               // cLines（扫描线总数）
		uintptr(unsafe.Pointer(&pixels[0])), // lpBits（像素数组）
		uintptr(unsafe.Pointer(&bmpInfo)),   // lpbmi（位图信息）
		uintptr(0),                             // usage（DIB_RGB_COLORS = 0）
		uintptr(0),uintptr(0) ,
	)

fmt.Println(rr)


		// // 将位图选入内存DC
		/// winapi.SelectObject(mdc, winapi.HGDIOBJ(hBitmap))

		// // 填充白色背景
		// brush, err := CreateSolidBrush(RGB(32, 100, 145))
		// if err != nil {
		// 	log.Println("CreateSolidBrush failed:", err)
		// 	return
		// }
		// defer DeleteObject(brush)

		// oldBrush := SelectObject(syscall.Handle(mdc), brush)
		// // 绘制填充矩形（改用gdi32.dll的Rectangle）
		// rectangle(syscall.Handle(mdc), 0, 0, int(width), int(height))
		// // 随机颜色（0x00BBGGRR 格式）
		// SelectObject(syscall.Handle(mdc), oldBrush)

 		// pixelsData, _ := os.ReadFile("./data.bin") 
        // pixelsDataArr:=[][][4]uint8{} 
		// json.Unmarshal(pixelsData, &pixelsDataArr) 
		//  height:=len(pixelsDataArr)

        start := time.Now()

		// for y := 0; y < height; y++ {
		// 	width:=len(pixelsDataArr[y]) 
		// 	for x := 0; x < width; x++ {  
		// 		//color := uintptr(uintptr(pixelsDataArr[y][x][2])) | uintptr(pixelsDataArr[y][x][1])<<8 | uintptr(pixelsDataArr[y][x][0])<<16
 		// 	 _=uintptr(uintptr(pixelsDataArr[y][x][2])) | uintptr(pixelsDataArr[y][x][1])<<8 | uintptr(pixelsDataArr[y][x][0])<<16
	

 		// 		// setPixel.Call(
		// 		// 	uintptr(mdc), // 内存 DC（缓存画布）
		// 		// 	uintptr(x),   // X 坐标
		// 		// 	uintptr(y),   // Y 坐标
		// 		// 	color,        // 颜色值
		// 		// )

		// 	}
		// }
		duration := time.Since(start) // 等价于 time.Now().Sub(start)

		// 输出耗时（支持多种时间单位）
		fmt.Printf("运行时间: %v\n", duration)         // 自动选择合适单位
		fmt.Printf("毫秒: %d ms\n", duration.Milliseconds()) // 毫秒
		fmt.Printf("微秒: %d µs\n", duration.Microseconds()) // 微秒
		fmt.Printf("纳秒: %d ns\n", duration.Nanoseconds())   // 纳秒



 

 
		// for y := 0; y < len(pixelspixels); y++ {
		// 	for x := 0; x < len(pixelspixels[y]); x++ {
		// 		p := pixelspixels[y][x] 
		// 		color := uintptr(p.B) | uintptr(p.G)<<8 | uintptr(p.R)<<16
		// 		// 绘制像素到内存缓存（保留上一帧内容）
		// 		setPixel.Call(
		// 			uintptr(mdc), // 内存 DC（缓存画布）
		// 			uintptr(x),   // X 坐标
		// 			uintptr(y),   // Y 坐标
		// 			color,        // 颜色值
		// 		)

		// 	}
		// }

	} else {
		// 将位图选入内存DC
		//winapi.SelectObject(mdc, winapi.HGDIOBJ(hBitmap))
	}

	for i := 0; i < 10000; i++ {
		r := rand.Intn(256)
		g := rand.Intn(256)
		b := rand.Intn(256)
		//color := uintptr(b) | uintptr(g)<<8 | uintptr(r)<<16
		_ = uintptr(b) | uintptr(g)<<8 | uintptr(r)<<16
		// 绘制像素到内存缓存（保留上一帧内容）
		// setPixel.Call(
		// 	uintptr(mdc),              // 内存 DC（缓存画布）
		// 	uintptr(rand.Intn(int(100))+1), // X 坐标
		// 	uintptr(rand.Intn(int(100))+1), // Y 坐标
		// 	color,                     // 颜色值
		// )

	}
}

// 获取图片所有像素数据，返回 [y][x]color.RGBA 格式（行优先）
func getImagePixels(filePath string) ([][]color.RGBA, error) {
	// 1. 打开图片文件
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("打开文件失败: %v", err)
	}
	defer file.Close()

	// 2. 解码图片（自动识别格式，也可指定格式如 png.Decode）
	img, err := png.Decode(file)
	if err != nil {
		return nil, fmt.Errorf("解码图片失败: %v", err)
	}

	// 3. 获取图片尺寸（边界）
	bounds := img.Bounds()
	width := bounds.Max.X - bounds.Min.X  // 宽度（像素数）
	height := bounds.Max.Y - bounds.Min.Y // 高度（像素数）

	// 4. 遍历所有像素，提取 RGBA 值
	pixels := make([][]color.RGBA, height)
	for y := 0; y < height; y++ {
		pixels[y] = make([]color.RGBA, width)
		for x := 0; x < width; x++ {
			// At(x, y) 返回 color.Color 接口，转换为 RGBA 格式
			r, g, b, a := img.At(x+bounds.Min.X, y+bounds.Min.Y).RGBA()

			// RGBA() 返回的是 16 位值（0-65535），转换为 8 位（0-255）
			pixels[y][x] = color.RGBA{
				R: uint8(r >> 8),
				G: uint8(g >> 8),
				B: uint8(b >> 8),
				A: uint8(a >> 8),
			}
		}
	}

	return pixels, nil
}



// 定义 Windows API 所需的结构体（与 C 语言结构体对齐）
type BITMAPINFOHEADER struct {
	BiSize          uint32
	BiWidth         int32
	BiHeight        int32
	BiPlanes        uint16
	BiBitCount      uint16
	BiCompression   uint32
	BiSizeImage     uint32
	BiXPelsPerMeter int32
	BiYPelsPerMeter int32
	BiClrUsed       uint32
	BiClrImportant  uint32
}

type RGBQUAD struct {
	RgbBlue     byte
	RgbGreen    byte
	RgbRed      byte
	RgbReserved byte // 通常为 0（Alpha 通道可在此处使用）
}

type BITMAPINFO struct {
	BmiHeader BITMAPINFOHEADER
	BmiColors [1]RGBQUAD // 简化处理，仅支持 1 个颜色表（32位色无需颜色表）
}
