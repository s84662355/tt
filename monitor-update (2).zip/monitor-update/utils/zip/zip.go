package zip

import (
	"archive/zip"
	"io"
	"os"
	"path/filepath"
	"strings"

	. "monitor-update/utils/file"
)

func UnZip(dst, src string) (err error) {
	zipFile, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	targetDir := dst
	if err := os.MkdirAll(targetDir, 0o777); err != nil {
		return err
	}

	for _, file := range zipFile.Reader.File {
		// 忽略 __MACOSX 文件夹
		if strings.HasPrefix(file.Name, "__MACOSX/") {
			continue
		}
		zipped, err := file.Open()
		if err != nil {
			return err
		}

		extractedPath := filepath.Join(targetDir, file.Name)

		if file.FileInfo().IsDir() {
			os.MkdirAll(extractedPath, 0o777)
		} else {
			// if !IsDirExists(filepath.Dir(extractedPath)) {
			os.MkdirAll(filepath.Dir(extractedPath), file.Mode())
			//}
			extracted, err := os.OpenFile(extractedPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode())
			if err != nil {
				zipped.Close()
				return err
			}
			_, err = io.Copy(extracted, zipped)
			extracted.Close()
			if err != nil {
				zipped.Close()
				return err
			}

		}

		zipped.Close()
	}

	return nil
}

// Compress a directory to a zip file
func ZipDir(dirPath, zipFilePath string) error {
	zipFile, err := os.Create(zipFilePath)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	archive := zip.NewWriter(zipFile)
	defer archive.Close()

	return filepath.Walk(dirPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		header, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}

		header.Name = strings.Replace(path, dirPath, "", -1)
		if len(header.Name) > 1 {
			if string(header.Name[0]) == "\\" {
				header.Name = strings.Replace(header.Name, "\\", "", 1)
			} else if string(header.Name[0]) == "/" {
				header.Name = strings.Replace(header.Name, "/", "", 1)
			}
		}

		if info.IsDir() {
			header.Name += "/"
		} else {
			header.Method = zip.Deflate
		}

		writer, err := archive.CreateHeader(header)
		if err != nil {
			return err
		}

		if !info.IsDir() {
			file, err := os.Open(path)
			if err != nil {
				return err
			}
			defer file.Close()
			_, err = io.Copy(writer, file)
		}
		return err
	})
}

func UnZipCallBack(dst, src string, callback func(uint64, uint64)) (err error) {
	zipFile, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	targetDir := dst
	if err := os.MkdirAll(targetDir, 0o755); err != nil {
		return err
	}

	var fileSize uint64 = 0
	for _, file := range zipFile.Reader.File {
		// 累加未压缩的文件大小
		fileSize += file.UncompressedSize64
	}

	var copySize uint64 = 0
	buffer := make([]byte, 1024*32) //
	for _, file := range zipFile.Reader.File {
		zipped, err := file.Open()
		if err != nil {
			return err
		}

		extractedPath := filepath.Join(targetDir, file.Name)

		if file.FileInfo().IsDir() {
			os.MkdirAll(extractedPath, file.Mode())
		} else {
			if !IsDirExists(filepath.Dir(extractedPath)) {
				os.MkdirAll(filepath.Dir(extractedPath), file.Mode())
			}
			extracted, err := os.OpenFile(extractedPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, file.Mode())
			if err != nil {
				zipped.Close()
				return err
			}
			if callback != nil {
				for {
					n, errt := zipped.Read(buffer)
					if errt == io.EOF && n <= 0 { // 文件末尾
						err = nil
						break
					}
					if err != nil {
						break
					}
					_, err = extracted.Write(buffer[:n])
					if err != nil {
						break
					}
					copySize += uint64(n)

					callback(fileSize, copySize)
				}
			} else {
				_, err = io.Copy(extracted, zipped)
			}

			extracted.Close()
			if err != nil {
				zipped.Close()
				return err
			}

		}

		zipped.Close()
	}

	return nil
}
