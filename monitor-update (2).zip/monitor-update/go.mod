module monitor-update

go 1.24.0

toolchain go1.24.9

require (
	github.com/jthmath/winapi v0.0.0-20220924150906-a0bf4d56a80d
	golang.org/x/sys v0.37.0
)

require (
	github.com/go-ole/go-ole v1.3.0 // indirect
	github.com/kirides/go-d3d v1.0.1 // indirect
	github.com/klauspost/compress v1.18.1 // indirect
	github.com/lxn/walk v0.0.0-20210112085537-c389da54e794 // indirect
	github.com/lxn/win v0.0.0-20210218163916-a377121e959e // indirect
	github.com/shahfarhadreza/go-gdiplus v0.0.0-20210421180137-228a132a1edf // indirect
	github.com/zzl/go-win32api/v2 v2.2.0 // indirect
	gopkg.in/Knetic/govaluate.v3 v3.0.0 // indirect
)
