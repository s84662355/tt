package main

import (
	//"encoding/json"
	"fmt"
	"math"
	//"os"
	"runtime"
	"syscall"
	"time"
	"unsafe"
	"encoding/binary"
	"github.com/klauspost/compress/zstd"
	"io"
	"github.com/lxn/win"
	"bytes"
 
	"sync"
	"net"

)

const (
	// 窗口类名（自定义，用于注册窗口类）
	windowClassName = "MyFirstWin32Window"
	// 窗口标题
	windowTitle = "Golang + Win32 GDI 窗口示例"
	// 窗口初始大小
	windowWidth  = 1000
	windowHeight = 800
)

var hbitMAP win.HBITMAP

type ControlWindow struct {
	hwnd            win.HWND
	hinstance       win.HINSTANCE
	windowClassName string
	windowWidth     int32
	windowHeight    int32
	hBITMAP         *HBITMAP
    mutex sync.Mutex 

}

func NewControlWindow(
	hinstance win.HINSTANCE,
	phwnd win.HWND,
	windowWidth int32,
	windowHeight int32,
) (*ControlWindow, error) {
	hBITMAP, err := NewHBITMAP(windowWidth, windowHeight)
	if err != nil {
		return nil, err
	}
	c := &ControlWindow{
		hinstance:       hinstance,
		hBITMAP:         hBITMAP,
		windowClassName: fmt.Sprint("ControlWindow-", time.Now()),
		windowWidth:     windowWidth,
		windowHeight:    windowHeight,
	}

	// 1. 注册窗口类（Win32 必须步骤：告诉系统窗口的“模板”）
	var wc win.WNDCLASSEX
	wc.CbSize = uint32(unsafe.Sizeof(wc))                          // 结构体大小（固定写法）
	wc.LpfnWndProc = syscall.NewCallback(c.wndProc)                // 绑定窗口过程函数
	wc.HInstance = hinstance                                       // 进程实例句柄
	wc.LpszClassName = syscall.StringToUTF16Ptr(c.windowClassName) // 窗口类名
	wc.HbrBackground = win.COLOR_WINDOW + 1                        // 窗口背景色（系统默认白色）
	wc.HCursor = 0                                                 // 鼠标光标（默认箭头）

	// 注册窗口类，失败则 panic
	if atom := win.RegisterClassEx(&wc); atom == 0 {
		defer hBITMAP.DeleteObject()
		return nil, fmt.Errorf("注册窗口类失败")
	}

	//

	// 2. 创建窗口（基于已注册的窗口类）
	hwnd := win.CreateWindowEx(
		0, // 扩展风格（0 为默认）
		syscall.StringToUTF16Ptr(c.windowClassName),    // 窗口类名（与注册时一致）
		syscall.StringToUTF16Ptr(""),                   // 窗口标题
		win.WS_POPUP|win.WS_SYSMENU|win.WS_MINIMIZEBOX, // 窗口风格（带标题栏、最小化/最大化按钮）
		0, 0, // 窗口初始位置（系统默认）
		windowWidth/2, windowHeight/2, // 窗口宽高
		phwnd,     // 父窗口
		0,         //  菜单句柄（均为 0）
		hinstance, // 进程实例句柄
		nil,       // 额外参数（nil 即可）
	)
	if hwnd == 0 {
		defer win.UnregisterClass(syscall.StringToUTF16Ptr(c.windowClassName))
		defer hBITMAP.DeleteObject()
		return nil, fmt.Errorf("创建窗口失败")
	}
	c.hwnd = hwnd

	return c, nil
}

func (c *ControlWindow) ShowWindow() {
	win.ShowWindow(c.hwnd, win.SW_SHOWNORMAL)
}

func (c *ControlWindow) UpdateWindow() {
	win.UpdateWindow(c.hwnd)
}

func (c *ControlWindow) CopyBitmap(data []byte) {
	c.mutex.Lock()
	defer  c.mutex.Unlock()
	copy(c.hBITMAP.GetBitmapArray(),data)  
}



func (c *ControlWindow) GetBitmapArray() []byte {
	return c.hBITMAP.GetBitmapArray()
}

func (c *ControlWindow) Close() {
	win.DestroyWindow(c.hwnd)
	win.PostMessage(c.hwnd, win.WM_CLOSE, 0, 0)
}

func (c *ControlWindow) wndProc(hwnd win.HWND, msg uint32, wParam uintptr, lParam uintptr) uintptr {
	switch msg {
	// 窗口创建时触发（可初始化资源）
	case win.WM_CREATE:
		return 0
	// 窗口需要绘制时触发（这里用 GDI 画一个矩形和文字）
	case win.WM_PAINT:
		var ps win.PAINTSTRUCT
		hdc := win.BeginPaint(c.hwnd, &ps)
		defer win.EndPaint(c.hwnd, &ps)
		hdcMem := win.CreateCompatibleDC(hdc)
		if hdcMem == 0 {
			return 0
		}
		defer win.DeleteDC(hdcMem)
		c.mutex.Lock()
		defer  c.mutex.Unlock()
		hOldBitmap := win.SelectObject(hdcMem, win.HGDIOBJ(c.hBITMAP.GetHBITMAP()))
		win.BitBlt(hdc, 0, 0, c.windowWidth, c.windowHeight, hdcMem, 0, 0, win.SRCCOPY)
		win.SelectObject(hdcMem, win.HGDIOBJ(hOldBitmap))

		return 0

	// 点击窗口关闭按钮时触发
	case win.WM_CLOSE:
		// 发送“销毁窗口”消息
		win.DestroyWindow(hwnd)
		return 0

	// 窗口销毁时触发（释放资源，退出程序）
	case win.WM_DESTROY:
		// 发送“退出消息循环”信号
		///win.PostQuitMessage(0)
		c.hBITMAP.DeleteObject()
		win.UnregisterClass(syscall.StringToUTF16Ptr(c.windowClassName))
		return 0

	// 其他未处理的消息，交给系统默认处理
	default:
		return win.DefWindowProc(hwnd, msg, wParam, lParam)
	}
}

func main() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
 
 
	// 获取当前进程实例句柄
	hInstance := win.GetModuleHandle(nil)
	if hInstance == 0 {
		panic("GetModuleHandle failed")
	} 

	serverAddr := "172.16.23.60:23080" 
	// 建立TCP连接，设置超时时间（5秒）
	conn, err := net.DialTimeout("tcp", serverAddr, 5*time.Second)
	longBuf:=make([]byte,8)
	if _, err := io.ReadFull(conn, longBuf); err != nil {
		fmt.Println("error:", err)
		return
	}

// 1. 大端序（BigEndian）解析
	width := binary.BigEndian.Uint32(longBuf[:4])
    height:=binary.BigEndian.Uint32(longBuf[4 : ])
   fmt.Println(width,height)
    ccc, err := NewControlWindow(hInstance, 0, int32(width) , int32(height) )
	fmt.Println(err)
 
 

	go func() {

		data:=make([]byte,4*width*height)
		dataCopy:=make([]byte,4*width*height)
        dataLen:=make([]byte,4)
		for J := 0; J < 200; J++ {
			fmt.Println(J)
		 
			if _, err := io.ReadFull(conn, dataLen); err != nil {
				fmt.Println(1)
				fmt.Println("error:", err)
				ccc.Close()
				break
			}
	 
			dataLenUint32:= binary.BigEndian.Uint32(dataLen)


			pixData:=make([]byte,int(dataLenUint32))
			if _, err := io.ReadFull(conn, pixData); err != nil {
				fmt.Println("error:", err)
				return
			}
    
            i:=0
			for i < int(dataLenUint32)   { 
				imgStart:=int(binary.BigEndian.Uint32(pixData[i:i+4]))  
				i=i+4
				pixdataLen:=int(binary.BigEndian.Uint32(pixData[i:i+4]))  
				i=i+4

				copy(data[imgStart:], pixData[i:i+pixdataLen])
				i=i+pixdataLen 
			}


			copy(dataCopy,data)
			 

			ccc.CopyBitmap(dataCopy)
             ccc.ShowWindow()
			ccc.UpdateWindow()

 
			// start  = time.Now()
 
		 
		  
			// elapsed  = time.Since(start) // 等价于 time.Now().Sub(start)

			// fmt.Printf("代码执行耗时: %v\n", elapsed) // 输出：代码执行耗时: 200ms左右
            // ccc.ShowWindow()
			// ccc.UpdateWindow()

		}

  
		 
		ccc.Close()





	}()

	// 4. 消息循环（程序核心：持续接收并处理系统消息）
	var msg win.MSG
	for {
		// 从消息队列中获取消息，0 表示“无消息时阻塞等待”
		ret := win.GetMessage(&msg, 0, 0, 0)
		if ret == 0 || ret == -1 {
			break // 收到 WM_QUIT 消息（ret=0）或错误（ret=-1），退出循环
		}
		// 翻译消息（如键盘输入）
		win.TranslateMessage(&msg)
		// 分发消息到窗口过程函数（wndProc）
		win.DispatchMessage(&msg)
	}
}

type HBITMAP struct {
	dx          int32
	dy          int32
	hBITMAP     win.HBITMAP
	bitmapArray []byte
}

func NewHBITMAP(dx, dy int32) (*HBITMAP, error) {
	hBITMAP, bitmapArray, err := createHBitmap(dx, dy)
	if err != nil {
		return nil, err
	}
	h := &HBITMAP{
		dx:          dx,
		dy:          dy,
		hBITMAP:     hBITMAP,
		bitmapArray: bitmapArray,
	}
	return h, nil
}

func (h *HBITMAP) DeleteObject() {
	win.DeleteObject(win.HGDIOBJ(h.hBITMAP))
}

func (h *HBITMAP) GetBitmapArray() []byte {
	return h.bitmapArray
}

func (h *HBITMAP) GetHBITMAP() win.HBITMAP {
	return h.hBITMAP
}

func (h *HBITMAP) Dx() int32 {
	return h.dx
}

func (h *HBITMAP) Dy() int32 {
	return h.dy
}

const inchesPerMeter float64 = 39.37007874

func createHBitmap(dx int32, dy int32) (win.HBITMAP, []byte, error) {
	var bi win.BITMAPV5HEADER
	bi.BiSize = uint32(unsafe.Sizeof(bi))
	bi.BiWidth = dx
	bi.BiHeight = -dy
	bi.BiPlanes = 1
	bi.BiBitCount = 32
	bi.BiCompression = win.BI_BITFIELDS
	dpm := int32(math.Round(float64(1) * inchesPerMeter))
	bi.BiXPelsPerMeter = dpm
	bi.BiYPelsPerMeter = dpm
	// The following mask specification specifies a supported 32 BPP
	// alpha format for Windows XP.
	bi.BV4RedMask = 0x00FF0000
	bi.BV4GreenMask = 0x0000FF00
	bi.BV4BlueMask = 0x000000FF
	bi.BV4AlphaMask = 0xFF000000

	hdc := win.GetDC(0)
	defer win.ReleaseDC(0, hdc)
	var lpBits unsafe.Pointer

	// Create the DIB section with an alpha channel.
	hBitmap := win.CreateDIBSection(hdc, &bi.BITMAPINFOHEADER, win.DIB_RGB_COLORS, &lpBits, 0, 0)
	switch hBitmap {
	case 0, win.ERROR_INVALID_PARAMETER:
		return 0, nil, fmt.Errorf("CreateDIBSection failed")
	}

	// 计算总字节数（假设是 32 位位图，每个像素 4 字节：R/G/B/A 各 1 字节）
	totalBytes := 4 * int(dx) * int(dy)

	// bitmap_array := (*[totalBytes]byte)(unsafe.Pointer(lpBits))
	bitmap_array := unsafe.Slice((*byte)(lpBits), totalBytes)

	return hBitmap, bitmap_array, nil
}

// zstdDecompress 解压缩 Zstd 数据
func zstdDecompress(data []byte) ([]byte, error) {
	// 创建 Zstd 读取器
	decoder, err := zstd.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer decoder.Close() // 确保关闭

	// 读取解压缩后的数据
	return io.ReadAll(decoder)
}