### 打包的工工具

```shell
go install github.com/akavel/rsrc
go install github.com/josephspurrier/goversioninfo/cmd/goversioninfo@latest
```
 

### 编译

#### 生产环境

```shell
go build -ldflags=" -H windowsgui "  -o bin/CloudSevenUpdate.exe

```

# 权限
```shell
rsrc -manifest nac.mainfest -o nac.syso -ico   tubiao.ico

```
  

## 代码格式化

```shell
gofumpt -l -w .
```