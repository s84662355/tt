package main

import (
	"embed"
	"fmt"
	"io/fs"
	"io/ioutil"
	"os"
	"path/filepath"
)

//go:embed resources/*
var resources embed.FS

func initResources(tmpDir string) error {
	// 遍历嵌入的资源并复制到临时目录
	err := fs.WalkDir(resources, "resources", func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// 跳过目录
		if d.IsDir() {
			return nil
		}

		// 读取嵌入的文件内容
		data, err := resources.ReadFile(path)
		if err != nil {
			return err
		}

		// 创建目标文件路径
		relPath, err := filepath.Rel("resources", path)
		if err != nil {
			return err
		}
		targetPath := filepath.Join(tmpDir, relPath)

		// 创建父目录
		if err := os.MkdirAll(filepath.Dir(targetPath), 0o755); err != nil {
			return err
		}

		// 写入文件
		if err := ioutil.WriteFile(targetPath, data, 0o644); err != nil {
			return err
		}

		return nil
	})
	if err != nil {
		return fmt.Errorf("复制资源失败: %v", err)
	}

	return nil
}
