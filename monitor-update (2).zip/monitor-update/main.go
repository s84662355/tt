package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"golang.org/x/sys/windows" // 导入新包

	. "monitor-update/dashboard"
	"monitor-update/utils/zip"
)

var (
	uncompressedSize atomic.Uint64
	totalSize        atomic.Uint64
	AppBaseDir       string
)

func init() {
	log.SetFlags(log.Ldate | log.Ltime)

	if AppBaseDirTemp, err := os.Executable(); err != nil {
		panic(err)
	} else {
		AppBaseDir = filepath.Dir(AppBaseDirTemp)
	}

	// 创建日志文件
	f, err := os.OpenFile(filepath.Join(AppBaseDir, "update-log"), os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0o666)
	if err != nil {
		panic(err)
	}

	log.SetOutput(f)
}

func main() {
	// 定义参数
	compressPath := flag.String("compress_path", "", "压缩包路径")
	extractionPath := flag.String("extraction_path", "", "解压路径")
	launchCommand := flag.String("launch_command", "", "启动命令")
	// 解析命令行参数
	flag.Parse()

	log.Println(fmt.Sprintf("compress_path:%s", *compressPath))
	log.Println(fmt.Sprintf("extraction_path:%s", *extractionPath))
	log.Println(fmt.Sprintf("launch_command:%s", *launchCommand))

	resourcesDir := filepath.Join(AppBaseDir, "resourcesTmp")
	os.RemoveAll(resourcesDir)
	os.MkdirAll(resourcesDir, 0o755)
	defer os.RemoveAll(resourcesDir)

	initResources(resourcesDir)

	wg := &sync.WaitGroup{}
	defer wg.Wait()
	wg.Add(2)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	go func() {
		defer cancel()
		defer wg.Done()

		errChan, err := RunMain(filepath.Join(resourcesDir, "background.bmp"))
		if err != nil {
			log.Println(fmt.Sprintf("启动窗口失败 error:%v", err))
			return
		}

		defer func() {
			CloseWindow()
			for range errChan {
				/* code */
			}
		}()
		if err := <-errChan; err == nil {
			<-ctx.Done()
		}
	}()
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(100 * time.Millisecond)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				TTtt(HHhWnd)
				UpdateWindow(uncompressedSize.Load(), totalSize.Load())
			case <-ctx.Done():

				return
			}
		}
	}()
	time.Sleep(5000 * time.Millisecond)
	for i := 0; true; i++ {
		if err := zip.UnZipCallBack(*extractionPath, *compressPath, func(ts, copySize uint64) {
			totalSize.Store(ts)
			uncompressedSize.Store(copySize)
		}); err != nil {
			log.Println(fmt.Sprintf("解压%s失败 error:%v", *compressPath, err))
			if i > 3 {
				return
			}
			time.Sleep(2000 * time.Millisecond)
		} else {
			break
		}
	}

	log.Println(fmt.Sprintf("解压%s完成 ", *compressPath))

	// 创建命令
	cmd := exec.Command(*launchCommand)

	// 设置 Windows 特定参数
	cmd.SysProcAttr = &syscall.SysProcAttr{
		// 从 windows 包中获取常量
		CreationFlags: windows.CREATE_NEW_PROCESS_GROUP | windows.DETACHED_PROCESS,
		HideWindow:    true,
	}

	if err := cmd.Start(); err != nil {
		log.Println(fmt.Sprintf("启动%s失败 error:%v", *launchCommand, err))
		return
	}
	time.Sleep(1000 * time.Millisecond)
}
